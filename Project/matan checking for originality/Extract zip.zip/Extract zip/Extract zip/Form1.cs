﻿using SharpCompress.Archives;
using SharpCompress.Archives.Rar;
using SharpCompress.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using MessageBox = System.Windows.MessageBox;

namespace Extract_zip
{
    public partial class Form1 : Form
    {
        // Global FileDialog variable
        private OpenFileDialog fdFile;

        // Global FolderBrowserDialog variable
        private FolderBrowserDialog folderBrowser;

        // Store the zip/rar folder path
        string urlToExtract;

        // Store the destination path you want to extract
        string urlExtractDastination;

        // Stores all the folders path afther the first unzip/rar
        string[] files;

        // Temporarily holding each folder path to see if its need to unzip/rar again
        private string[] temp;

        

        public Form1()
        {
            InitializeComponent();
            // Open new FileDialog object
            this.fdFile = new OpenFileDialog();
     
            //Open new FolderBrowserDialog object
            this.folderBrowser= new FolderBrowserDialog();
            this.fdFile.AddExtension = false;
        }

        //  Open winsow to choose the folder you want to unzip/rar
        private void btn_Extract_Click(object sender, EventArgs e)
        {
            try
            {
                if(DialogResult.OK == fdFile.ShowDialog())
                {
                    // Passing the path to the text box 
                    Url1.Text = fdFile.FileName;

                    // Passing the path 
                    urlToExtract = Url1.Text;
                }
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
                this.Close();   
            }
        }

        //Open window to choose the folder you want to extract
        private void btn_ExtractDestination_Click(object sender, EventArgs e)
        {
            try
            {
                if (DialogResult.OK == folderBrowser.ShowDialog())
                {
                    // Passing the path to the text box 
                    Url2.Text = folderBrowser.SelectedPath;

                    // Passing the path 
                    urlExtractDastination = Url2.Text;
                }
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
                this.Close();
            }
        }

        // Strat the extract of each zip/rar/jar in each folder and store it in the folder 
        private void btn_StratExtract_Click(object sender, EventArgs e)
        {
            // Get the original foler and desttination and do the first extract
            try
            {
                ZipFile.ExtractToDirectory(urlToExtract, urlExtractDastination);
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);
                System.Windows.Forms.Application.Exit();

            }

            //Get all the folders path after the first extract
            files = Directory.GetDirectories(urlExtractDastination);

            for(int i = 0;i < files.Length; i++)
            {
                int j = 0;

                //Temporarily holding the path of the files in the folder 
                temp = Directory.GetFiles(files[i]);

                // Checking whether the path contains zip or jar
                if (temp[j].Contains(".zip")|| temp[j].Contains(".jar"))
                {
                    // Extract the zip or jar in the folder that the zip/jar was in it
                    ZipFile.ExtractToDirectory(temp[j], files[i]);   
                }

                // Checking whether the path contains rar
                if (temp[j].Contains(".rar"))
                {
                    // Extract the rar  in the folder that the rar was in it
                    using (var archive = RarArchive.Open(temp[j]))
{
                        foreach (var entry in archive.Entries.Where(entry => !entry.IsDirectory))
                        {
                            entry.WriteToDirectory(files[i], new ExtractionOptions()
                            {

                            });
                        }
                    }
                }

            }
       }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }
    }
}
