﻿namespace Extract_zip
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_StratExtract = new FontAwesome.Sharp.IconButton();
            this.btn_ExtractDestination = new FontAwesome.Sharp.IconButton();
            this.btn_Extract = new FontAwesome.Sharp.IconButton();
            this.Url1 = new System.Windows.Forms.TextBox();
            this.Url2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_StratExtract
            // 
            this.btn_StratExtract.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_StratExtract.BackColor = System.Drawing.Color.Transparent;
            this.btn_StratExtract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_StratExtract.FlatAppearance.BorderSize = 0;
            this.btn_StratExtract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_StratExtract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_StratExtract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_StratExtract.IconChar = FontAwesome.Sharp.IconChar.Golang;
            this.btn_StratExtract.IconColor = System.Drawing.Color.Black;
            this.btn_StratExtract.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_StratExtract.IconSize = 40;
            this.btn_StratExtract.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_StratExtract.Location = new System.Drawing.Point(587, 325);
            this.btn_StratExtract.Name = "btn_StratExtract";
            this.btn_StratExtract.Size = new System.Drawing.Size(183, 38);
            this.btn_StratExtract.TabIndex = 4;
            this.btn_StratExtract.Text = "Strat Extract";
            this.btn_StratExtract.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_StratExtract.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_StratExtract.UseVisualStyleBackColor = false;
            this.btn_StratExtract.Click += new System.EventHandler(this.btn_StratExtract_Click);
            // 
            // btn_ExtractDestination
            // 
            this.btn_ExtractDestination.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ExtractDestination.BackColor = System.Drawing.Color.Transparent;
            this.btn_ExtractDestination.FlatAppearance.BorderSize = 0;
            this.btn_ExtractDestination.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_ExtractDestination.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_ExtractDestination.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ExtractDestination.IconChar = FontAwesome.Sharp.IconChar.FolderOpen;
            this.btn_ExtractDestination.IconColor = System.Drawing.Color.Black;
            this.btn_ExtractDestination.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_ExtractDestination.IconSize = 28;
            this.btn_ExtractDestination.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ExtractDestination.Location = new System.Drawing.Point(545, 125);
            this.btn_ExtractDestination.Name = "btn_ExtractDestination";
            this.btn_ExtractDestination.Size = new System.Drawing.Size(225, 36);
            this.btn_ExtractDestination.TabIndex = 2;
            this.btn_ExtractDestination.Text = "Extract Destination";
            this.btn_ExtractDestination.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ExtractDestination.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_ExtractDestination.UseVisualStyleBackColor = false;
            this.btn_ExtractDestination.Click += new System.EventHandler(this.btn_ExtractDestination_Click);
            // 
            // btn_Extract
            // 
            this.btn_Extract.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Extract.BackColor = System.Drawing.Color.Transparent;
            this.btn_Extract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Extract.FlatAppearance.BorderSize = 0;
            this.btn_Extract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Extract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Extract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Extract.ForeColor = System.Drawing.Color.Black;
            this.btn_Extract.IconChar = FontAwesome.Sharp.IconChar.ArrowUpFromBracket;
            this.btn_Extract.IconColor = System.Drawing.Color.Black;
            this.btn_Extract.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_Extract.IconSize = 28;
            this.btn_Extract.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Extract.Location = new System.Drawing.Point(587, 49);
            this.btn_Extract.Name = "btn_Extract";
            this.btn_Extract.Size = new System.Drawing.Size(197, 39);
            this.btn_Extract.TabIndex = 0;
            this.btn_Extract.Text = "Zip To Extract";
            this.btn_Extract.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Extract.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_Extract.UseVisualStyleBackColor = false;
            this.btn_Extract.Click += new System.EventHandler(this.btn_Extract_Click);
            // 
            // Url1
            // 
            this.Url1.Location = new System.Drawing.Point(362, 57);
            this.Url1.Name = "Url1";
            this.Url1.Size = new System.Drawing.Size(219, 22);
            this.Url1.TabIndex = 7;
            // 
            // Url2
            // 
            this.Url2.Location = new System.Drawing.Point(320, 132);
            this.Url2.Name = "Url2";
            this.Url2.Size = new System.Drawing.Size(219, 22);
            this.Url2.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(796, 382);
            this.Controls.Add(this.Url2);
            this.Controls.Add(this.Url1);
            this.Controls.Add(this.btn_StratExtract);
            this.Controls.Add(this.btn_ExtractDestination);
            this.Controls.Add(this.btn_Extract);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FontAwesome.Sharp.IconButton btn_Extract;
        private FontAwesome.Sharp.IconButton btn_ExtractDestination;
        private FontAwesome.Sharp.IconButton btn_StratExtract;
        private System.Windows.Forms.TextBox Url1;
        private System.Windows.Forms.TextBox Url2;
    }
}

