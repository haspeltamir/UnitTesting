using Microsoft.Office.Interop.Excel;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using static outputandexcel.Program;

namespace outputandexcel
{
    public partial class Form1 : Form
    {

        /*public class Student
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public Boolean doesFileCompile { get; set; }
            public Boolean correctOutput { get; set; }
            public Boolean fileOrginality { get; set; }
            public float documentedFile { get; set; }
            public int finalGrade { get; set; }
        }*/


        //public ref List<Student> pointerToStudentList;

        /*public ref List<Student> pointerToStudentList 
        {
            get{return pointerToStudentList;};
            set{pointerToStudentList = value;}; 
        }*/
        public Form1(ref List<Student> studentList)
        {
            InitializeComponent();
            //ref List<Student> pointerToStudentList1 = ref studentList;
            //(this.StructpointerToStudentList)->pointerToStudentList = studentList;
            dataGridView1.DataSource = studentList;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //not finished/working
            //string filePath = @"C:\MyExcelFile.xlsx";
            //ExportToExcel(dataGridView1, filePath);
            //export_datatable_to_excel();
        }

        //exporting the table to a Microsoft Excel Worksheet (.xlsx) and saving it with the name you chose and the file location you selected and returning a string of the file path
        /*public void export_datatable_to_excel()
        {
            MessageBox.Show("export");
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();          //creating an Application object that represents the Microsoft Excel application.
            excel.Application.Workbooks.Add(Type.Missing); //Represents a missing value in the System.Type information. This field is read-only.         //excel.Application.Workbooks.Add creates a new workbook
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)//FILL column names
            {
                MessageBox.Show("hii");
                excel.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)//fiil rows
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)//fill cells
                {
                    excel.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            excel.Columns.AutoFit();             //fitting the columns automatically to the best fit
            string filePath = string.Empty;      //creating empty string
            SaveFileDialog file = new SaveFileDialog(); //Prompts the user to select a location for saving a file. This class cannot //     inherited.
            file.Filter = "Excel Files (*.xlsx)|*.xlsx";  //filters the file type displayed and the type of file the form exported can be saved as
            file.ShowDialog();
            filePath = file.FileName; //get the path of the file  

            excel.Application.ActiveWorkbook.SaveAs(@path);          //saving the changes to the workbook at the path that was chosen
            excel.Application.ActiveWorkbook.Close();     //closing the workbook object

        }*/
        

    }
}