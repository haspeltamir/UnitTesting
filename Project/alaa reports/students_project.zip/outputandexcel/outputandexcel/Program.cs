using System.Collections.Generic;
using System.IO.Compression;

namespace outputandexcel
{

    public static class Program
    {

        public class Student
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public Boolean doesFileCompile { get; set; }
            public Boolean correctOutput { get; set; }
            public Boolean fileOrginality { get; set; }
            public float documentedFile { get; set; }
            public int finalGrade { get; set; }
        }
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Create an studentList to hold the info and paths of each student file
            List<Student> studentList = new List<Student>();

            string zipFilePath = @"C:\Users\MyLenovo\OneDrive\Desktop\c_projects.zip";
            string destinationDirectory = @"C:\C Projects";

            // Extract the contents of the zip file to the destination directory
            ZipFile.ExtractToDirectory(zipFilePath, destinationDirectory);

            // Get all the files in the project directory
            string[] files = Directory.GetFiles(destinationDirectory);

            foreach (string file in files)
            {
                // Create a studentFileInfo object to hold the student file name and path
                Student studentFileInfo = new Student();

                // Get the student file name and path
                studentFileInfo.Name = Path.GetFileName(file);
                studentFileInfo.Path = Path.GetFullPath(file);

                // Add the studentList object to the arraylist
                studentList.Add(studentFileInfo);
            }
            // Print the file names and paths in the arraylist (for testing only)
            /*foreach (Student file in studentList)
            {
                //MessageBox.Show("Name: +"+file.Name+" Path: "+file.Path);
            }*/
            //Deleting the directory that we created while extracting the zip file
            Directory.Delete(destinationDirectory, true);



            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1(ref studentList));

        }
        



    }
}