﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.IO;
using System.Security.Cryptography.X509Certificates;


//C:\Users\MyLenovo\OneDrive\Desktop\c_projects.zip
namespace ConsoleApp1
{
    internal class main
    {
        // Define a class to hold the file name and path
        public class Student
        {
            public string Name { get; set; }
            public string Path { get; set; }
            public Boolean doesFileCompile { get; set; }
            public Boolean correctOutput { get; set; }
            public Boolean fileOrginality { get; set; }
            public float documentedFile { get; set; }
            public int finalGrade { get; set; }
        }
        static void Main(string[] args)
        {
            // Create an arraylist to hold the file names and paths
            List<Student> studentList = new List<Student>();

            string zipFilePath = @"C:\Users\MyLenovo\OneDrive\Desktop\c_projects.zip";
            string destinationDirectory = @"C:\C Projects";

            // Extract the contents of the zip file to the destination directory
            ZipFile.ExtractToDirectory(zipFilePath, destinationDirectory);

            // Get all the files in the project directory
            string[] files = Directory.GetFiles(destinationDirectory);

            foreach (string file in files)
            {
                // Create a FileInfo object to hold the file name and path
                Student fileInfo = new Student();

                // Get the file name and path
                fileInfo.Name = Path.GetFileName(file);
                fileInfo.Path = Path.GetFullPath(file);

                // Add the FileInfo object to the arraylist
                studentList.Add(fileInfo);
            }

            // Print the file names and paths in the arraylist
            foreach (Student file in studentList)
            {
                Console.WriteLine("Name: {0} Path: {1}", file.Name, file.Path);
            }

            //Deleting the directory that we created while extracting the zip file
            Directory.Delete(destinationDirectory,true);
            Console.ReadKey();
        }
    }
}



