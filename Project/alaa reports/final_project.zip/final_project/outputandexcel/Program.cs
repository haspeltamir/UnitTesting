using System.Collections.Generic;
using System.IO.Compression;
using System.Windows.Forms;

namespace outputandexcel
{

    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Create an studentList to hold the info and paths of each student file
            List<Student> studentList = new List<Student>();
            string zipFilePath = "";//"C:\\Users\\MyLenovo\\OneDrive\\Desktop\\c_projects.zip";
            OpenFileDialog dialog = new OpenFileDialog();
            // Set the properties of the OpenFileDialog
            dialog.Title = "Select a zip file";
            dialog.Filter = "zip files (*.zip)|*.zip|All files (*.*)|*.*";
            
            // Show the dialog and check if the user clicked the OK button
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                // Get the selected file path                
                zipFilePath = dialog.FileName;
                //MessageBox.Show(@zipFilePath);
            }
            string destinationDirectory =  CreateNewFolder("151");

            // Extract the contents of the zip file to the destination directory
            ZipFile.ExtractToDirectory(@zipFilePath, destinationDirectory);

            // Get all the files in the project directory
            string[] files = Directory.GetFiles(destinationDirectory);

            foreach (string file in files)
            {
                // Create a studentFileInfo object to hold the student file name and path
                Student studentFileInfo = new Student();

                // Get the student file name and path
                studentFileInfo.Name = Path.GetFileName(file);
                studentFileInfo.Path = Path.GetFullPath(file);

                // Add the studentList object to the arraylist
                studentList.Add(studentFileInfo);
            }
  
            //Deleting the directory that we created while extracting the zip file
            Directory.Delete(destinationDirectory, true);



            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            //ApplicationConfiguration.Initialize();
            // ApplicationConfiguration.Initialize() will emit the following calls:
            Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Form1 form1 = new Form1(ref studentList);
            Application.Run(form1);
        }

        private static string CreateNewFolder(string folderName)
        {
            string path = "C:\\" + folderName;
            Directory.CreateDirectory(path);
            return path;
        }



    }
}