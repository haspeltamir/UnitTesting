﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outputandexcel
{
    public class Student
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public Boolean doesFileCompile { get; set; }
        public Boolean correctOutput { get; set; }
        public Boolean fileOrginality { get; set; }
        public float documentedFile { get; set; }
        public int finalGrade { get; set; }
    }
}
