using FastMember;
using Microsoft.Office.Interop.Excel;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using static outputandexcel.Program;
using static System.Runtime.InteropServices.JavaScript.JSType;
using DataTable = System.Data.DataTable;

namespace outputandexcel
{
    public partial class Form1 : Form
    {
        DataTable dataTable;
        DataView view;
        
        public Form1(ref List<Student> studentList)
        {
            InitializeComponent();
            //ref List<Student> pointerToStudentList1 = ref studentList;
            //(this.StructpointerToStudentList)->pointerToStudentList = studentList;
            //dataGridView1.DataSource = studentList;
            
            dataTable = new DataTable();
            dataTable.Columns.Add("Name", typeof(string));
            dataTable.Columns.Add("Path", typeof(string));
            dataTable.Columns.Add("doesFileCompile", typeof(bool));
            dataTable.Columns.Add("correctOutput", typeof(bool));
            dataTable.Columns.Add("fileOrginality", typeof(bool));
            dataTable.Columns.Add("documentedFile", typeof(float));
            dataTable.Columns.Add("finalGrade", typeof(int));
            foreach (var item in studentList)
            {
                DataRow row = dataTable.NewRow();
                row["Name"] = item.Name;
                row["Path"] = item.Path;
                row["doesFileCompile"] = item.doesFileCompile;
                row["correctOutput"] = item.correctOutput;
                row["fileOrginality"] = item.fileOrginality;
                row["documentedFile"] = item.documentedFile;
                row["finalGrade"] = item.finalGrade;
                dataTable.Rows.Add(row);
            }

            /*using (var reader = ObjectReader.Create(studentList,"Name","Path","doesFileCompile", "correctOutput",
                "fileOrginality", "documentedFile", "finalGrade"))
            {
                dataTable.Load(reader);
            }*/
            dataGridView1.DataSource = dataTable;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Show();
            this.BringToFront();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            export_datatable_to_excel();
        }

        //exporting the table to a Microsoft Excel Worksheet (.xlsx) and saving it with the name you chose and the file location you selected and returning a string of the file path
        public void export_datatable_to_excel()
        {
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();          //creating an Application object that represents the Microsoft Excel application.
            excel.Application.Workbooks.Add(Type.Missing); //Represents a missing value in the System.Type information. This field is read-only.         //excel.Application.Workbooks.Add creates a new workbook
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)//FILL column names
            {
                excel.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)//fiil rows
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)//fill cells
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        excel.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
            }
            excel.Columns.AutoFit();             //fitting the columns automatically to the best fit
            string filePath = string.Empty;      //creating empty string
            SaveFileDialog file = new SaveFileDialog(); //Prompts the user to select a location for saving a file. This class cannot //     inherited.
            file.Filter = "Excel Files (*.xlsx)|*.xlsx";  //filters the file type displayed and the type of file the form exported can be saved as
            file.ShowDialog();
            filePath = file.FileName; //get the path of the file  

            excel.Application.ActiveWorkbook.SaveAs(@filePath);          //saving the changes to the workbook at the path that was chosen
            excel.Application.ActiveWorkbook.Close();     //closing the workbook object

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create a new DataView object
            view = new DataView(dataTable);
            // Set the RowFilter property to filter the rows based on the search value
            view.RowFilter = "Name" + " like '%" + this.textBox1.Text + "%'";//filter datagridview by every where operator

            // Set the DataGridView's data source to the DataView
            dataGridView1.DataSource = view;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Reset the RowFilter property to an empty string
            view.RowFilter = "";

            // Rebind the DataView to the data source
            dataGridView1.DataSource = view;
        }
    }
}