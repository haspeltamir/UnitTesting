﻿Folder - Description

net2.0 - Contains assemblies to use with .NET Framework 2.0, 3.0, 3.5.
net4.0 - Contains assemblies to use with .NET Framework 4.0 - 4.8.
netstandard2.0 - Contains assemblies to use with .NET Standard 2.0 and above.