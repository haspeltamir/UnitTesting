﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class ReportsForm : Form
    {
        DataTable dataTable;
        DataView view;
        string assignments_full_path;
        public ReportsForm(ref List<Student> studentList, List<string> variableFlagList, string assignments_path)
        {
            InitializeComponent();
            dataTable = new DataTable();
            dataTable.Columns.Add("Id", typeof(string));
            //dataTable.Columns.Add("Path", typeof(string));
            if (variableFlagList.Contains("Compilation Errors"))
                dataTable.Columns.Add("doesFileCompile", typeof(string)); 
            if (variableFlagList.Contains("Similarity to Expected Output"))
                dataTable.Columns.Add("correctOutput", typeof(string));
            if (variableFlagList.Contains("Documentation"))
                dataTable.Columns.Add("documentedFile", typeof(int));
            if (variableFlagList.Contains("Indentation and Spacing"))
                dataTable.Columns.Add("structuredFile", typeof(int));
            dataTable.Columns.Add("finalGrade", typeof(int));
            foreach (var item in studentList)
            {
                DataRow row = dataTable.NewRow();
                row["Id"] = item.Id[0] + " " + item.Id[1];
                if (variableFlagList.Contains("Compilation Errors"))
                    row["doesFileCompile"] = item.doesFileCompile == true ? "True" : "False";
                if (variableFlagList.Contains("Similarity to Expected Output"))
                { 
                    string correctOutput = "";
                    foreach (int correctOutputItem in item.correctOutput)
                    {
                        correctOutput += correctOutputItem + " ";
                    }
                    row["correctOutput"] = correctOutput;
                }
                if (variableFlagList.Contains("Documentation"))
                    row["documentedFile"] = item.documentedFile;
                if (variableFlagList.Contains("Indentation and Spacing"))
                    row["structuredFile"] = item.structuredFile;
                row["finalGrade"] = item.finalGrade;
                dataTable.Rows.Add(row);
            }

            studentsReportsDataGridView.DataSource = dataTable;
            //init assignments_path
            assignments_full_path = assignments_path;
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {

        }

        private void saveAsExcelButton_Click(object sender, EventArgs e)
        {
            export_datatable_to_excel();
        }

        //exporting the table to a Microsoft Excel Worksheet (.xlsx) and saving it with the name you chose and the file location you selected and returning a string of the file path
        public void export_datatable_to_excel()
        {
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();          //creating an Application object that represents the Microsoft Excel application.
            excel.Application.Workbooks.Add(Type.Missing); //Represents a missing value in the System.Type information. This field is read-only.         //excel.Application.Workbooks.Add creates a new workbook
            for (int i = 1; i < studentsReportsDataGridView.Columns.Count + 1; i++)//FILL column names
            {
                excel.Cells[1, i] = studentsReportsDataGridView.Columns[i - 1].HeaderText;
            }

            for (int i = 0; i < studentsReportsDataGridView.Rows.Count; i++)//fiil rows
            {
                for (int j = 0; j < studentsReportsDataGridView.Columns.Count; j++)//fill cells
                {
                    if (studentsReportsDataGridView.Rows[i].Cells[j].Value != null)
                    {
                        excel.Cells[i + 2, j + 1] = studentsReportsDataGridView.Rows[i].Cells[j].Value.ToString();
                    }
                }
            }
            excel.Columns.AutoFit();             //fitting the columns automatically to the best fit
            string filePath = string.Empty;      //creating empty string
            SaveFileDialog file = new SaveFileDialog(); //Prompts the user to select a location for saving a file. This class cannot //     inherited.
            file.Filter = "Excel Files (*.xlsx)|*.xlsx";  //filters the file type displayed and the type of file the form exported can be saved as
            file.ShowDialog();
            filePath = file.FileName; //get the path of the file  

            excel.Application.ActiveWorkbook.SaveAs(@filePath);          //saving the changes to the workbook at the path that was chosen
            excel.Application.ActiveWorkbook.Close();     //closing the workbook object

        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            // Create a new DataView object
            view = new DataView(dataTable);
            // Set the RowFilter property to filter the rows based on the search value
            view.RowFilter = "Id" + " like '%" + this.searchTextBox.Text + "%'";//filter datagridview by every where operator

            // Set the DataGridView's data source to the DataView
            studentsReportsDataGridView.DataSource = view;
        }

        private void showEntireDataButton_Click(object sender, EventArgs e)
        {
            // Reset the RowFilter property to an empty string
            if (view != null)
            {
                view.RowFilter = "";
                // Rebind the DataView to the data source
                studentsReportsDataGridView.DataSource = view;
            }
        }

        private void orginalityButton_Click(object sender, EventArgs e)
        {
            OriginalityForm originalityForm = new OriginalityForm(assignments_full_path);
            originalityForm.ShowDialog();
        }
    }
}
