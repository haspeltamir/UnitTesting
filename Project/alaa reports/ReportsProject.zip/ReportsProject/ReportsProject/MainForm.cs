﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class MainForm : Form
    {   
        List<Student> studentList = new List<Student>();
        List<string> variableFlagList = new List<string>();
        string assignments_path;
        public MainForm()
        {
            InitializeComponent();
            string PathOfDirectoryOfAllFiles = "C:\\Users\\MyLenovo\\OneDrive\\Desktop\\פרויקט אימות ובדיקות תוכנה\\class-update\\27-1\\UnitTesting-main\\Project\\HW to check\\Java Files\\kk";
            var extractZipAndFillStudentList = new ExtractZipAndFillStudentList();
            extractZipAndFillStudentList.extractZipAndFillStudentList(ref studentList, PathOfDirectoryOfAllFiles);
            //init variableFlagList
            variableFlagList.Add("Indentation and Spacing");
            variableFlagList.Add("Compilation Errors");
            variableFlagList.Add("Documentation");
            //variableFlagList.Add("Similarity to Expected Output");
            //init assignments_path -- change this path to the assignments folder path if u need to test matan+oran compare class
            assignments_path = "C:\\Users\\MyLenovo\\OneDrive\\Desktop\\פרויקט אימות ובדיקות תוכנה\\class\\UnitTesting-main\\Project\\HW to check\\Java Files\\kk";
            var doc = new DocumentFiles();
            doc.CheckIndentationOfAllClass(ref studentList);
        }

        private void reportsFormButton_Click(object sender, EventArgs e)
        {
            ReportsForm reportsForm = new ReportsForm(ref studentList,variableFlagList,assignments_path);
            reportsForm.ShowDialog();

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
