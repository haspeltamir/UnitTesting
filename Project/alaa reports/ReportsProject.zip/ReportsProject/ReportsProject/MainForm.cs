﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class MainForm : Form
    {   
        List<Student> studentList = new List<Student>();
        Student student1 = new Student();
        Student student2 = new Student();
        List<string> variableFlagList = new List<string>();
        string assignments_path;
        public MainForm()
        {
            InitializeComponent();
            //init students
            //student 1 info
            student1.Id[0] = "312456798";
            student1.Id[1] = "311111111";
            student1.Path = "c\\student1.c";
            student1.correctOutput = new int[2];
            student1.correctOutput[0] = 1;
            student1.correctOutput[1] = 0;
            student1.documentedFile = 50;
            student1.structuredFile = 100;
            student1.finalGrade = 95;
            //student 2 info
            student2.Id[0] = "322222222";
            student2.Id[1] = "378945987";
            student2.Path = "c\\student2.c";
            student2.correctOutput = new int[3];
            student2.correctOutput[0] = 1;
            student2.correctOutput[1] = 1;
            student2.correctOutput[2] = 1;
            student2.documentedFile = 100;
            student2.structuredFile = 100;
            student2.finalGrade = 100;
            //init student list
            studentList.Add(student1);
            studentList.Add(student2);
            //init variableFlagList
            variableFlagList.Add("Indentation and Spacing");
            variableFlagList.Add("Compilation Errors");
            variableFlagList.Add("Documentation");
            variableFlagList.Add("Similarity to Expected Output");
            //init assignments_path
            assignments_path = "C:\\Users\\MyLenovo\\OneDrive\\Desktop\\aaa\\CFiles";
        }

        private void reportsFormButton_Click(object sender, EventArgs e)
        {
            ReportsForm reportsForm = new ReportsForm(ref studentList,variableFlagList,assignments_path);
            reportsForm.ShowDialog();

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
