﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public class ExtractZipAndFillStudentList
    {
        public void extractZipAndFillStudentList(ref List<Student> studentList,string zipFilesDirectoryPath)
        {
            var extractZip = new ExtractJarOrZip();
            extractZip.extractByJarOrZipFolderPath(zipFilesDirectoryPath);
            string[] subDirectories = Directory.GetDirectories(zipFilesDirectoryPath);
            foreach(string currentSubDirectory in subDirectories)
            {
                Student currentStudent = new Student();
                var extractSubDirectoryZip = new ExtractJarOrZip();
                extractSubDirectoryZip.extractByJarOrZipFolderPath(currentSubDirectory);
                string[] extensions = { ".py", ".c", ".zip", ".jar",".7z" };
                string[] files = Directory.GetFiles(currentSubDirectory);
                //extract jar or zip files
                string filteredFile = files.Where(file => file.EndsWith(".jar") || file.EndsWith(".zip") || file.EndsWith(".c") || file.EndsWith(".py"))
                                        .Where(file => !file.Contains("META-INF")).OrderByDescending(file => file.Length).FirstOrDefault();
                if (filteredFile != null)
                {
                    try
                    {
                        Regex regex = new Regex(@"(?:\D|^)(\d{9})(?:\D.*?)(\d{9})(?:\D|$)");
                        Match match = regex.Match(filteredFile);
                        //Match match = Regex.Match(filteredFile, @"(?:\D|^)(\d{9})(?:\D.*?)(\d{9})(?:\D|$)");
                        if (match.Success)
                        {
                            currentStudent.Id[0] = match.Groups[1].Value;
                            currentStudent.Id[1] = match.Groups[2].Value;
                        }
                        else
                        {
                            currentStudent.Id[0] = Path.GetFileName(Path.GetDirectoryName(filteredFile));
                        }
                    }
                    catch { };
                }
                else
                {
                    currentStudent.Id[0] = Path.GetFileName(currentSubDirectory);
                }
                currentStudent.Path = currentSubDirectory;
                studentList.Add(currentStudent);
            }

        }
    }
}
