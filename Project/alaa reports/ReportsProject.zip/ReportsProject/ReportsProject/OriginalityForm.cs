﻿using compare;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class OriginalityForm : Form
    {
        Compares compares;
        public OriginalityForm(string assignments_path)
        {
            InitializeComponent();
            compares = new Compares();
            if (compares.compares(assignments_path) == false)
                MessageBox.Show("compare program failed");
            orginalityRichTextBox.ScrollBars = RichTextBoxScrollBars.ForcedVertical;
            MessageBox.Show("equal line list length is:" + compares.prervrntage.ToString());
            orginalityRichTextBox.SelectionBullet = true;
            foreach (string item in compares.equalslines)
            {
                orginalityRichTextBox.AppendText(item);
            }
        }

        private void originalityListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OriginalityForm_Load(object sender, EventArgs e)
        {

        }
    }
}
