﻿namespace ReportsProject
{
    partial class OriginalityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalityLabel = new System.Windows.Forms.Label();
            this.orginalityRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // originalityLabel
            // 
            this.originalityLabel.AutoSize = true;
            this.originalityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalityLabel.Location = new System.Drawing.Point(274, 9);
            this.originalityLabel.Name = "originalityLabel";
            this.originalityLabel.Size = new System.Drawing.Size(563, 32);
            this.originalityLabel.TabIndex = 2;
            this.originalityLabel.Text = "Originality of the students\'s assignments";
            // 
            // orginalityRichTextBox
            // 
            this.orginalityRichTextBox.Location = new System.Drawing.Point(-3, 58);
            this.orginalityRichTextBox.Name = "orginalityRichTextBox";
            this.orginalityRichTextBox.Size = new System.Drawing.Size(1159, 676);
            this.orginalityRichTextBox.TabIndex = 3;
            this.orginalityRichTextBox.Text = "";
            // 
            // OriginalityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 730);
            this.Controls.Add(this.orginalityRichTextBox);
            this.Controls.Add(this.originalityLabel);
            this.Name = "OriginalityForm";
            this.Text = "OriginalityForm";
            this.Load += new System.EventHandler(this.OriginalityForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label originalityLabel;
        private System.Windows.Forms.RichTextBox orginalityRichTextBox;
    }
}