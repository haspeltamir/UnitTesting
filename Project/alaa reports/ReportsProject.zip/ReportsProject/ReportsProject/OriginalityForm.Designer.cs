﻿namespace ReportsProject
{
    partial class OriginalityForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originalityLabel = new System.Windows.Forms.Label();
            this.orginalityRichTextBox = new System.Windows.Forms.RichTextBox();
            this.originalityTabControl = new System.Windows.Forms.TabControl();
            this.originalityByLineTabPage = new System.Windows.Forms.TabPage();
            this.originalityByPercentageTabPage = new System.Windows.Forms.TabPage();
            this.percentageOrginalityRichTextBox = new System.Windows.Forms.RichTextBox();
            this.originalityTabControl.SuspendLayout();
            this.originalityByLineTabPage.SuspendLayout();
            this.originalityByPercentageTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // originalityLabel
            // 
            this.originalityLabel.AutoSize = true;
            this.originalityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.originalityLabel.Location = new System.Drawing.Point(274, 9);
            this.originalityLabel.Name = "originalityLabel";
            this.originalityLabel.Size = new System.Drawing.Size(563, 32);
            this.originalityLabel.TabIndex = 2;
            this.originalityLabel.Text = "Originality of the students\'s assignments";
            // 
            // orginalityRichTextBox
            // 
            this.orginalityRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.orginalityRichTextBox.Name = "orginalityRichTextBox";
            this.orginalityRichTextBox.Size = new System.Drawing.Size(1148, 645);
            this.orginalityRichTextBox.TabIndex = 3;
            this.orginalityRichTextBox.Text = "";
            // 
            // originalityTabControl
            // 
            this.originalityTabControl.Controls.Add(this.originalityByLineTabPage);
            this.originalityTabControl.Controls.Add(this.originalityByPercentageTabPage);
            this.originalityTabControl.Location = new System.Drawing.Point(-2, 58);
            this.originalityTabControl.Name = "originalityTabControl";
            this.originalityTabControl.SelectedIndex = 0;
            this.originalityTabControl.Size = new System.Drawing.Size(1156, 674);
            this.originalityTabControl.TabIndex = 4;
            // 
            // originalityByLineTabPage
            // 
            this.originalityByLineTabPage.Controls.Add(this.orginalityRichTextBox);
            this.originalityByLineTabPage.Location = new System.Drawing.Point(4, 25);
            this.originalityByLineTabPage.Name = "originalityByLineTabPage";
            this.originalityByLineTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.originalityByLineTabPage.Size = new System.Drawing.Size(1148, 645);
            this.originalityByLineTabPage.TabIndex = 0;
            this.originalityByLineTabPage.Text = "Originality By Line";
            this.originalityByLineTabPage.UseVisualStyleBackColor = true;
            // 
            // originalityByPercentageTabPage
            // 
            this.originalityByPercentageTabPage.Controls.Add(this.percentageOrginalityRichTextBox);
            this.originalityByPercentageTabPage.Location = new System.Drawing.Point(4, 25);
            this.originalityByPercentageTabPage.Name = "originalityByPercentageTabPage";
            this.originalityByPercentageTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.originalityByPercentageTabPage.Size = new System.Drawing.Size(1148, 645);
            this.originalityByPercentageTabPage.TabIndex = 1;
            this.originalityByPercentageTabPage.Text = "Originality By Percentage";
            this.originalityByPercentageTabPage.UseVisualStyleBackColor = true;
            // 
            // percentageOrginalityRichTextBox
            // 
            this.percentageOrginalityRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.percentageOrginalityRichTextBox.Name = "percentageOrginalityRichTextBox";
            this.percentageOrginalityRichTextBox.Size = new System.Drawing.Size(1145, 642);
            this.percentageOrginalityRichTextBox.TabIndex = 0;
            this.percentageOrginalityRichTextBox.Text = "";
            // 
            // OriginalityForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 730);
            this.Controls.Add(this.originalityTabControl);
            this.Controls.Add(this.originalityLabel);
            this.Name = "OriginalityForm";
            this.Text = "OriginalityForm";
            this.Load += new System.EventHandler(this.OriginalityForm_Load);
            this.originalityTabControl.ResumeLayout(false);
            this.originalityByLineTabPage.ResumeLayout(false);
            this.originalityByPercentageTabPage.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label originalityLabel;
        private System.Windows.Forms.RichTextBox orginalityRichTextBox;
        private System.Windows.Forms.TabControl originalityTabControl;
        private System.Windows.Forms.TabPage originalityByLineTabPage;
        private System.Windows.Forms.TabPage originalityByPercentageTabPage;
        private System.Windows.Forms.RichTextBox percentageOrginalityRichTextBox;
    }
}