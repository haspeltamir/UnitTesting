﻿namespace ReportsProject
{
    partial class ReportsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchLabel = new System.Windows.Forms.Label();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.studentsReportsDataGridView = new System.Windows.Forms.DataGridView();
            this.saveAsExcelButton = new System.Windows.Forms.Button();
            this.showEntireDataButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.orginalityButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.studentsReportsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // searchLabel
            // 
            this.searchLabel.AutoSize = true;
            this.searchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLabel.Location = new System.Drawing.Point(39, 48);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(96, 20);
            this.searchLabel.TabIndex = 0;
            this.searchLabel.Text = "Name filter:";
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(153, 49);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(100, 22);
            this.searchTextBox.TabIndex = 1;
            // 
            // studentsReportsDataGridView
            // 
            this.studentsReportsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.studentsReportsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentsReportsDataGridView.Location = new System.Drawing.Point(0, 105);
            this.studentsReportsDataGridView.Name = "studentsReportsDataGridView";
            this.studentsReportsDataGridView.RowHeadersWidth = 51;
            this.studentsReportsDataGridView.RowTemplate.Height = 24;
            this.studentsReportsDataGridView.Size = new System.Drawing.Size(1130, 542);
            this.studentsReportsDataGridView.TabIndex = 3;
            // 
            // saveAsExcelButton
            // 
            this.saveAsExcelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveAsExcelButton.Image = global::ReportsProject.Properties.Resources.excel;
            this.saveAsExcelButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveAsExcelButton.Location = new System.Drawing.Point(548, 12);
            this.saveAsExcelButton.Name = "saveAsExcelButton";
            this.saveAsExcelButton.Size = new System.Drawing.Size(224, 33);
            this.saveAsExcelButton.TabIndex = 5;
            this.saveAsExcelButton.Text = "Save as excel file";
            this.saveAsExcelButton.UseVisualStyleBackColor = true;
            this.saveAsExcelButton.Click += new System.EventHandler(this.saveAsExcelButton_Click);
            // 
            // showEntireDataButton
            // 
            this.showEntireDataButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showEntireDataButton.Image = global::ReportsProject.Properties.Resources.table_button;
            this.showEntireDataButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.showEntireDataButton.Location = new System.Drawing.Point(548, 67);
            this.showEntireDataButton.Name = "showEntireDataButton";
            this.showEntireDataButton.Size = new System.Drawing.Size(224, 32);
            this.showEntireDataButton.TabIndex = 4;
            this.showEntireDataButton.Text = "Show entire data";
            this.showEntireDataButton.UseVisualStyleBackColor = true;
            this.showEntireDataButton.Click += new System.EventHandler(this.showEntireDataButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Image = global::ReportsProject.Properties.Resources.search_16pixel_button;
            this.searchButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.searchButton.Location = new System.Drawing.Point(273, 44);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(129, 27);
            this.searchButton.TabIndex = 2;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // orginalityButton
            // 
            this.orginalityButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orginalityButton.Location = new System.Drawing.Point(875, 30);
            this.orginalityButton.Name = "orginalityButton";
            this.orginalityButton.Size = new System.Drawing.Size(174, 55);
            this.orginalityButton.TabIndex = 6;
            this.orginalityButton.Text = "Check Originality";
            this.orginalityButton.UseVisualStyleBackColor = true;
            this.orginalityButton.Click += new System.EventHandler(this.orginalityButton_Click);
            // 
            // ReportsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 649);
            this.Controls.Add(this.orginalityButton);
            this.Controls.Add(this.saveAsExcelButton);
            this.Controls.Add(this.showEntireDataButton);
            this.Controls.Add(this.studentsReportsDataGridView);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.searchLabel);
            this.Name = "ReportsForm";
            this.Text = "ReportsForm";
            this.Load += new System.EventHandler(this.ReportsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.studentsReportsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.DataGridView studentsReportsDataGridView;
        private System.Windows.Forms.Button showEntireDataButton;
        private System.Windows.Forms.Button saveAsExcelButton;
        private System.Windows.Forms.Button orginalityButton;
    }
}