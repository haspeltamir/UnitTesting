﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ReportsProject
{
    public class DocumentFiles
    {
        int lineCount = 0;
        public void CheckIndentationOfAllClass(ref List<Student> studentlist)
        {

            foreach (Student student in studentlist)
            {
                student.setStructuredFile(CheckIndentation(student.Path));
            }
        }



        public int CheckIndentation(string dirFilePath)
        {

            float ratio = 0;
            string[] extensions = { ".py", ".c", ".java" };
            string[] files = Directory.GetFiles(dirFilePath);
            //extract jar or zip files
            files = Directory.GetFiles(dirFilePath);
            string[] filteredFiles = Array.FindAll(files, file => extensions.Any(file.EndsWith));
            foreach (string filePath in filteredFiles)
            {
                // Read the file
                List<string> lines = new List<string>(File.ReadAllLines(filePath));
                string pattern = @"\d{9}";

                // Keep track of the current indent level
                int indentLevel = 0;

                lines.RemoveAll(string.IsNullOrWhiteSpace);

                // Store the results in a list of tuples
                List<(string, bool)> results = new List<(string, bool)>();

                // Check the indentation of each line
                foreach (string line in lines)
                {
                    //Console.WriteLine(line);
                    // Count the number of leading spaces
                    int indent = 0;
                    while (indent < line.Length && line[indent] == ' ')
                    {
                        indent++;
                    }

                    //match student ID
                    Match match = Regex.Match(line, pattern);
                    if (match.Success)
                    {
                        string id = match.Value;
                        //Console.WriteLine($"ID :{id}");
                    }


                    // Check if the line is a block opener or closer
                    bool isOpener = line.Trim().EndsWith("{");
                    bool isCloser = line.Trim().EndsWith("}");
                    bool parentheses = line.Contains("(") && !(line.Contains(")")) || line.Contains(")") && !(line.Contains("("));



                    // Check if the indentation is correct
                    bool isCorrect = false;


                    if (isOpener)
                    {
                        // If this is a block opener, the indentation should be one level deeper than the previous line
                        isCorrect = indent == indentLevel * 4 + 4;
                        indentLevel++;
                    }
                    else if (isCloser)
                    {
                        // If this is a block closer, the indentation should be one level shallower than the previous line
                        isCorrect = indent == indentLevel * 4;
                        indentLevel--;
                    }
                    else
                    {
                        // Otherwise, the indentation should be the same as the previous line
                        isCorrect = indent == indentLevel * 4;

                        if (parentheses)
                        {
                            isCorrect = false;
                        }
                    }


                    // Add the result to the list
                    results.Add((line, isCorrect));

                    lineCount++;

                }


                // Count the number of true and false values
                int trueCount = results.Count(x => x.Item2 == true);
                int falseCount = results.Count(x => x.Item2 == false);

                // Calculate the ratio of true to false values
                ratio += ((float)trueCount * 100 / (trueCount + falseCount));
                //Console.WriteLine("ratio=" + ratio);

            }
            ratio = (ratio / filteredFiles.Length);
            return (int)ratio;
        }
    }
}
