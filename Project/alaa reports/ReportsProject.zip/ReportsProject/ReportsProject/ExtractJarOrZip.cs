﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aspose.Zip.SevenZip;
using SharpCompress.Archives;
using SharpCompress.Archives.Rar;

namespace ReportsProject
{
    public class ExtractJarOrZip
    {
        public void extractByJarOrZipPath(string jarPath)
        {

            try
            {
                if (jarPath.Contains(".zip")||jarPath.Contains(".jar"))
                {
                    //MessageBox.Show(jarPath);
                    string targetDirectory = Path.GetDirectoryName(jarPath);
                    ZipFile.ExtractToDirectory(jarPath, targetDirectory);
                    //check if there is no files // if there is none that mean we have a directory
                    string[] files = Directory.GetFiles(targetDirectory);
                    if (files.Length == 0 && targetDirectory != "META-INF")
                    {
                        //checking if a sub directorys exists ,if exits we extract them to main directory
                        extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    else if (files.Length == 1 && targetDirectory != "META-INF")
                    {
                            extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    checkIfThereIsMoreZipOrJarFiles(Path.GetDirectoryName(jarPath),jarPath );
                }
                else if(jarPath.Contains(".rar"))
                {
                    //MessageBox.Show(jarPath);
                    string targetDirectory = Path.GetDirectoryName(jarPath);
                    using (var archive = RarArchive.Open(jarPath))
                    {
                        foreach (var entry in archive.Entries)
                        {
                            if (!entry.IsDirectory)
                            {
                                entry.WriteToDirectory(targetDirectory);
                            }
                        }
                    }
                    //check if there is no files // if there is none that mean we have a directory
                    string[] files = Directory.GetFiles(targetDirectory);
                    if (files.Length == 0 &&  targetDirectory != "META-INF")
                    {
                        //checking if a sub directorys exists ,if exits we extract them to main directory
                        extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    else if (files.Length == 1 && targetDirectory != "META-INF")
                    { 
                            extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    checkIfThereIsMoreZipOrJarFiles(Path.GetDirectoryName(jarPath), jarPath);
                }
                else if (jarPath.Contains(".7z"))
                {
                    //MessageBox.Show(jarPath);
                    string targetDirectory = Path.GetDirectoryName(jarPath);
                    ////SevenZipExtractor extractor = new SevenZipExtractor(jarPath);
                    ////extractor.ExtractArchive(targetDirectory);
                    using (SevenZipArchive archive = new SevenZipArchive(jarPath))
                    {
                        archive.ExtractToDirectory(targetDirectory);
                    }
                    //check if there is no files // if there is none that mean we have a directory
                    string[] files = Directory.GetFiles(targetDirectory);
                    if (files.Length == 0 && targetDirectory != "META-INF")
                    {
                        //checking if a sub directorys exists ,if exits we extract them to main directory
                        extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    else if (files.Length == 1 && targetDirectory != "META-INF")
                    {
                            extreactSubDirectoryToCurrentDirectory(targetDirectory);
                    }
                    checkIfThereIsMoreZipOrJarFiles(Path.GetDirectoryName(jarPath), jarPath);
                }
                
            }
            catch
            {
            }
        }

        public void extractByJarOrZipFolderPath(string jarOrZipFolderPath)
        {

            try
            {
                string[] jarOrZipExtentions = { ".zip", ".jar",".rar" , ".7z" };
                string[] files = Directory.GetFiles(jarOrZipFolderPath);
                //extract jar or zip files
                string[] filteredJarFiles = Array.FindAll(files, file => jarOrZipExtentions.Any(file.EndsWith));
                foreach (string jarFile in filteredJarFiles)
                {
                    extractByJarOrZipPath(jarFile);
                }
            }
            catch
            {
                if (jarOrZipFolderPath.Contains(".zip") || jarOrZipFolderPath.Contains(".rar") || jarOrZipFolderPath.Contains(".jar") || jarOrZipFolderPath.Contains(".7z"))
                    extractByJarOrZipPath(jarOrZipFolderPath);
                else
                    extreactSubDirectoryToCurrentDirectory(jarOrZipFolderPath);
            }
        }

        public void extreactSubDirectoryToCurrentDirectory(string mainDirectoryPath)
        {
            try
            {
                string[] subDirectories = Directory.GetDirectories(mainDirectoryPath);
                string[] files = Directory.GetFiles(mainDirectoryPath);
                if (subDirectories.Length == 1 && files.Length ==1 || subDirectories.Length == 0 && files.Length == 0)
                {   
                    foreach (string subDirectory in subDirectories)
                    {
                        if (subDirectory != "META-INF")
                        {
                            string sourcePath = Path.Combine(mainDirectoryPath, subDirectory);

                            foreach (string file in Directory.GetFiles(sourcePath))
                            {
                                string fileName = Path.GetFileName(file);
                                string destFile = Path.Combine(mainDirectoryPath, fileName);
                                File.Move(file, destFile);
                            }
                        }
                    }
                    extractByJarOrZipFolderPath(mainDirectoryPath);
                }
            }
            catch
            {
                if (mainDirectoryPath.Contains(".zip") || mainDirectoryPath.Contains(".rar") || mainDirectoryPath.Contains(".jar") || mainDirectoryPath.Contains(".7z"))
                    extractByJarOrZipPath(mainDirectoryPath);
            }            
        }
        public void checkIfThereIsMoreZipOrJarFiles(string mainDirectoryPath,string directoryName)
        {
            string[] jarOrZipExtentions = { ".zip", ".jar", ".rar", ".7z" };
            string[] files = Directory.GetFiles(mainDirectoryPath);
            //extract jar or zip files
            string[] filteredJarFiles = Array.FindAll(files, file => jarOrZipExtentions.Any(file.EndsWith));
            foreach (string jarFile in filteredJarFiles)
            {
                if (jarFile != directoryName)
                    extractByJarOrZipPath(jarFile);
            }

        }

    }
}
