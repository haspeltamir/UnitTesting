﻿using Moq;
using NUnit.Framework;
using ReportsProject;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace ReportsProject.Tests
{
    [TestFixture]
    public class ExportDataTableToExcelAndSaveItTests
    {
        DataTable _studentListDataTable;
        DataRow _student1;
        DataRow _student2;
        //We use SetUp method to initiliaze the objects of each test before callling it
        [SetUp]
        public void SetUp()
        {
            _studentListDataTable = new DataTable();
            _studentListDataTable.Columns.Add("Id", typeof(string));
            _studentListDataTable.Columns.Add("doesFileCompile", typeof(string));
            _studentListDataTable.Columns.Add("correctOutput", typeof(string));
            _studentListDataTable.Columns.Add("documentedFile", typeof(int));
            _studentListDataTable.Columns.Add("structuredFile", typeof(int));
            _studentListDataTable.Columns.Add("finalGrade", typeof(int));
            //student 1 info
            _student1 = _studentListDataTable.NewRow();
            _student1["Id"] = "311111111 322222222";
            _student1["doesFileCompile"] = "True";
            _student1["correctOutput"] = "1 0 ";
            _student1["documentedFile"] = 50;
            _student1["structuredFile"] = 100;
            _student1["finalGrade"] = 95;
            //student 2 info
            _student2 = _studentListDataTable.NewRow();
            _student2["Id"] = "333333333 344444444";
            _student2["doesFileCompile"] = "false";
            _student2["correctOutput"] = "1 0 ";
            _student2["documentedFile"] = 100;
            _student2["structuredFile"] = 90;
            _student2["finalGrade"] = 75;

            _studentListDataTable.Rows.Add(_student1);
            _studentListDataTable.Rows.Add(_student2);

        }
        [Test]
        public void ExportDataTableToExcelTest_NotEmptyDataTable_ExportAndSaveTheExcelFile()
        {
            // Arrange
            var mockExcelService = new Mock<IExcelService>();
            mockExcelService.Setup(mEC => mEC.ExportDataTableToExcel(It.IsAny<DataTable>()));

            // Act
            var exportDataTableToExcelAndSaveIt = new ExportDataTableToExcelAndSaveIt();
            exportDataTableToExcelAndSaveIt.ExportDataTableToExcelAndSaveItFun(_studentListDataTable, mockExcelService.Object);

            // Assert
            mockExcelService.Verify(mES => mES.ExportDataTableToExcel(_studentListDataTable), Times.Once);

        }

        [Test]
        public void ExportDataTableToExcelTest_EmptyDataTable_NotExportingNeitherSavingTheExcelFile()
        {
            // Arrange
            var mockExcelService = new Mock<IExcelService>();
            mockExcelService.Setup(mEC => mEC.ExportDataTableToExcel(It.IsAny<DataTable>()));

            // Act
            var exportDataTableToExcelAndSaveIt = new ExportDataTableToExcelAndSaveIt();
            exportDataTableToExcelAndSaveIt.ExportDataTableToExcelAndSaveItFun(new DataTable(), mockExcelService.Object);

            // Assert
            mockExcelService.Verify(mES => mES.ExportDataTableToExcel(new DataTable()), Times.Never);

        }
    }
}