﻿using NUnit.Framework;
using ReportsProject;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportsProject.Tests
{

    [TestFixture]
    public class TransfareListToDataTableTests
    {
        List<Student> _studentList;
        Student _student1;
        Student _student2;
        List<string> _variableFlagList;
        [SetUp]
        public void SetUp()
        {
            _studentList = new List<Student>();
            _student1 = new Student();
            _student2 = new Student();
            //student 1 info
            _student1.Id[0] = "311111111";
            _student1.Id[1] = "322222222";
            _student1.Path = "c\\student1.c";
            _student1.correctOutput = new int[2];
            _student1.correctOutput[0] = 1;
            _student1.correctOutput[1] = 0;
            _student1.documentedFile = 50;
            _student1.structuredFile = 100;
            _student1.finalGrade = 95;
            //student 2 info
            _student2.Id[0] = "333333333";
            _student2.Id[1] = "344444444";
            _student2.Path = "c\\student2.c";
            _student2.correctOutput = new int[3];
            _student2.correctOutput[0] = 1;
            _student2.correctOutput[1] = 1;
            _student2.correctOutput[2] = 1;
            _student2.documentedFile = 100;
            _student2.structuredFile = 100;
            _student2.finalGrade = 100;
            _studentList.Add(_student1);
            _studentList.Add(_student2);
            //init variableFlagList
            _variableFlagList = new List<string>();
            _variableFlagList.Add("Indentation and Spacing");
            _variableFlagList.Add("Compilation Errors");
            _variableFlagList.Add("Documentation");
            _variableFlagList.Add("Similarity to Expected Output");
        }
        [Test]
        public void TransferStudentListDataToDataTableTest_NotEmptyStudentList_ReturnTransferedDataTableOfStudentList()
        {

            //Act
            var transfareListToDataTable = new TransfareListToDataTable();
            var result = transfareListToDataTable.TransferStudentListDataToDataTable(_studentList, _variableFlagList);

            //Assert
            //Assert.AreEqual("Id", result.Columns[0].ColumnName);
            AssertStudentListColumnsNamesAreEqualToExpectedDataBaseColumnsNames(result);
            AssertStudentListRowsDataAreEqualToExpectedDataBaseRowsData(result);
        }
        [Test]
        public void TransferStudentListDataToDataTableTest_EmptyStudentList_ReturnNull()
        {
            //Act
            var transfareListToDataTable = new TransfareListToDataTable();
            var result = transfareListToDataTable.TransferStudentListDataToDataTable(new List<Student>(), _variableFlagList);

            //Assert
            Assert.Null(result);;
        }

        [Test]
        public void TransferStudentListDataToDataTableTest_StudentListIsANull_ReturnNull()
        {
            //Act
            var transfareListToDataTable = new TransfareListToDataTable();
            var result = transfareListToDataTable.TransferStudentListDataToDataTable(null, _variableFlagList);

            //Assert
            Assert.Null(result); ;
        }
        private void AssertStudentListColumnsNamesAreEqualToExpectedDataBaseColumnsNames(DataTable result)
        {
            Assert.AreEqual("Id", result.Columns[0].ColumnName);
            Assert.AreEqual(typeof(string), result.Columns[0].DataType);
            Assert.AreEqual("doesFileCompile", result.Columns[1].ColumnName);
            Assert.AreEqual(typeof(string), result.Columns[1].DataType);
            Assert.AreEqual("correctOutput", result.Columns[2].ColumnName);
            Assert.AreEqual(typeof(string), result.Columns[2].DataType);
            Assert.AreEqual("documentedFile", result.Columns[3].ColumnName);
            Assert.AreEqual(typeof(int), result.Columns[3].DataType);
            Assert.AreEqual("structuredFile", result.Columns[4].ColumnName);
            Assert.AreEqual(typeof(int), result.Columns[4].DataType);
            Assert.AreEqual("finalGrade", result.Columns[5].ColumnName);
            Assert.AreEqual(typeof(int), result.Columns[5].DataType);
        }

        private void AssertStudentListRowsDataAreEqualToExpectedDataBaseRowsData(DataTable result)
        {
            for (int currentRowNumber = 0; currentRowNumber<_studentList.Count; currentRowNumber++)
            {
                DataRow currentDataRow = result.Rows[currentRowNumber];
                Assert.AreEqual(_studentList[currentRowNumber].Id[0]+ " "+ _studentList[currentRowNumber].Id[1]
                    , currentDataRow["Id"].ToString());
                Assert.AreEqual(_studentList[currentRowNumber].doesFileCompile.ToString(), currentDataRow["doesFileCompile"].ToString());
                string correctOutput = "";
                for(int i = 0; i < _studentList[currentRowNumber].correctOutput.Length; i++)
                    correctOutput += _studentList[currentRowNumber].correctOutput[i] + " ";

                Assert.AreEqual(correctOutput,currentDataRow["correctOutput"].ToString());
                Assert.AreEqual(_studentList[currentRowNumber].documentedFile, int.Parse(currentDataRow["documentedFile"].ToString()));
                Assert.AreEqual(_studentList[currentRowNumber].structuredFile, int.Parse(currentDataRow["structuredFile"].ToString()));
                Assert.AreEqual(_studentList[currentRowNumber].finalGrade, int.Parse(currentDataRow["finalGrade"].ToString()));
            }
        }
    }
}