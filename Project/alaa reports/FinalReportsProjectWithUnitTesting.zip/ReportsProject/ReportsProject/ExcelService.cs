﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public interface IExcelService
    {
        void ExportDataTableToExcel(System.Data.DataTable dataTable);
    }
    public class ExcelService : IExcelService
    {
        //exporting the table to a Microsoft Excel Worksheet (.xlsx) and saving it with the name you chose
        //and the file location you selected and returning a string of the file path
        public void ExportDataTableToExcel(System.Data.DataTable studentListDataTable)
        {
            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
            Workbook excelWorkbook = excelApp.Workbooks.Add();
            Worksheet excelWorksheet = excelWorkbook.ActiveSheet;

            for (int i = 1; i < studentListDataTable.Columns.Count + 1; i++)
            {
                excelWorksheet.Cells[1, i] = studentListDataTable.Columns[i - 1].ColumnName;
            }

            for (int i = 0; i < studentListDataTable.Rows.Count; i++)
            {
                for (int j = 0; j < studentListDataTable.Columns.Count; j++)
                {
                    excelWorksheet.Cells[i + 2, j + 1] = studentListDataTable.Rows[i][j].ToString();
                }
            }
            excelApp.Columns.AutoFit();             //fitting the columns automatically to the best fit
            string filePath = string.Empty;      //creating empty string
            SaveFileDialog file = new SaveFileDialog(); //Prompts the user to select a location for saving a file. This class cannot //     inherited.
            file.Filter = "Excel Files (*.xlsx)|*.xlsx";  //filters the file type displayed and the type of file the form exported can be saved as
            file.ShowDialog();
            filePath = file.FileName; //get the path of the file 
            excelWorkbook.SaveAs(filePath, XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing,
            false, false, XlSaveAsAccessMode.xlNoChange, XlSaveConflictResolution.xlUserResolution,
            true, Type.Missing, Type.Missing, Type.Missing);

            excelWorkbook.Close();
            excelApp.Quit();
        }
    }
}
