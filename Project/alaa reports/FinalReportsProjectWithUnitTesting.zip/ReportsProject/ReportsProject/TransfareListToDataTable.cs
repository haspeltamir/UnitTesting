﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportsProject
{
    public class TransfareListToDataTable
    {
        DataTable studentListDataTable;
        public DataTable TransferStudentListDataToDataTable(List<Student> studentList, List<string> variableFlagList)
        {
            if (studentList == null || studentList.Count == 0)
                return null;
            studentListDataTable = new DataTable();
            studentListDataTable.Columns.Add("Id", typeof(string));
            bool finalGradeFlag = false;
            if (variableFlagList.Contains("Compilation Errors"))
            {
                studentListDataTable.Columns.Add("doesFileCompile", typeof(string));
                finalGradeFlag = true;
            }
            if (variableFlagList.Contains("Similarity to Expected Output"))
            {
                studentListDataTable.Columns.Add("correctOutput", typeof(string));
                finalGradeFlag = true;
            }
            if (variableFlagList.Contains("Documentation"))
            {
                studentListDataTable.Columns.Add("documentedFile", typeof(int));
                finalGradeFlag = true;
            }
            if (variableFlagList.Contains("Indentation and Spacing"))
            {
                studentListDataTable.Columns.Add("structuredFile", typeof(int));
                finalGradeFlag = true;
            }
            if (finalGradeFlag)
                studentListDataTable.Columns.Add("finalGrade", typeof(int));

            foreach (var item in studentList)
            {
                DataRow row = studentListDataTable.NewRow();
                row["Id"] = item.Id[0] + " " + item.Id[1];
                if (variableFlagList.Contains("Compilation Errors"))
                    row["doesFileCompile"] = item.doesFileCompile == true ? "True" : "False";
                if (variableFlagList.Contains("Similarity to Expected Output"))
                {
                    string correctOutput = "";
                    foreach (int correctOutputItem in item.correctOutput)
                    {
                        correctOutput += correctOutputItem + " ";
                    }
                    row["correctOutput"] = correctOutput;
                }
                if (variableFlagList.Contains("Documentation"))
                    row["documentedFile"] = item.documentedFile;
                if (variableFlagList.Contains("Indentation and Spacing"))
                    row["structuredFile"] = item.structuredFile;
                if (finalGradeFlag)
                    row["finalGrade"] = item.finalGrade;
                studentListDataTable.Rows.Add(row);
            }

            return studentListDataTable;
        }
    }
}
