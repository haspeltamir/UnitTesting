﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class MainForm : Form
    {
        List<Student> _studentList;
        Student _student1;
        Student _student2;
        List<string> _variableFlagList;
        string _assignments_path;
        public MainForm()
        {
            InitializeComponent();
            //setup _studentList and _variableFlagList
            SetUp();           
        }

        private void reportsFormButton_Click(object sender, EventArgs e)
        {
            ReportsForm reportsForm = new ReportsForm(ref _studentList,_variableFlagList,_assignments_path);
            reportsForm.ShowDialog();

        }
        private void SetUp()
        {
           
            _studentList = new List<Student>();
            _student1 = new Student();
            _student2 = new Student();
            //student 1 info
            _student1.Id[0] = "311111111";
            _student1.Id[1] = "322222222";
            _student1.Path = "c\\student1.c";
            _student1.correctOutput = new int[2];
            _student1.correctOutput[0] = 1;
            _student1.correctOutput[1] = 0;
            _student1.documentedFile = 50;
            _student1.structuredFile = 100;
            _student1.finalGrade = 95;
            //student 2 info
            _student2.Id[0] = "333333333";
            _student2.Id[1] = "344444444";
            _student2.Path = "c\\student2.c";
            _student2.correctOutput = new int[3];
            _student2.correctOutput[0] = 1;
            _student2.correctOutput[1] = 1;
            _student2.correctOutput[2] = 1;
            _student2.documentedFile = 100;
            _student2.structuredFile = 100;
            _student2.finalGrade = 100;
            _studentList.Add(_student1);
            _studentList.Add(_student2);
            //init variableFlagList
            _variableFlagList = new List<string>();
            _variableFlagList.Add("Indentation and Spacing");
            _variableFlagList.Add("Compilation Errors");
            _variableFlagList.Add("Documentation");
            _variableFlagList.Add("Similarity to Expected Output");

            //init assignments_path -- change this path to the assignments folder path if u need to test matan+oran compare class
            _assignments_path = "C:\\Users\\MyLenovo\\OneDrive\\Desktop\\hhh";
            
        }
        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
