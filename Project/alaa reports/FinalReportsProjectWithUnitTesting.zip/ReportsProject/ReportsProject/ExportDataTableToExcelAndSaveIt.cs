﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportsProject
{
    public class ExportDataTableToExcelAndSaveIt
    {
        //exporting the table to a Microsoft Excel Worksheet (.xlsx) and saving it with the name you chose
        //and the file location you selected and returning a string of the file path
        public void ExportDataTableToExcelAndSaveItFun(System.Data.DataTable studentListDataTable, IExcelService excelService)
        {
            if (studentListDataTable == null)
                return;

            excelService.ExportDataTableToExcel(studentListDataTable);
        }
    }
}
