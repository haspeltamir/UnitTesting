﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReportsProject
{
    public partial class ReportsForm : Form
    {
        DataTable _studentListDataTable;
        DataView _studentListDataView;
        string _assignmentsFullPath;
        public ReportsForm(ref List<Student> studentList, List<string> variableFlagList, string assignmentsFullPath)
        {
            InitializeComponent();
            var transfareListToDataTable = new TransfareListToDataTable();
            _studentListDataTable = transfareListToDataTable
                .TransferStudentListDataToDataTable(studentList, variableFlagList);
            if (_studentListDataTable != null)
                studentsReportsDataGridView.DataSource = _studentListDataTable;
            else
                MessageBox.Show("There is No Data in studentList!!!");
            //set up _assignments_path to the given assignmentsFullPath
            _assignmentsFullPath = assignmentsFullPath;
        }
        private void ReportsForm_Load(object sender, EventArgs e)
        {

        }

        private void saveAsExcelButton_Click(object sender, EventArgs e)
        {
            IExcelService exportDataTableToExcelAndSaveIt = new ExcelService();
            exportDataTableToExcelAndSaveIt.ExportDataTableToExcel(_studentListDataTable);
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            // Create a new DataView object of the studentlist datatable
            _studentListDataView = new DataView(_studentListDataTable);
            // Set the RowFilter property to filter the rows based on the search value
            _studentListDataView.RowFilter = "Id" + " like '%" + this.searchTextBox.Text + "%'";//filter datagridview by every where operator

            // Set the DataGridView's data source to the DataView
            studentsReportsDataGridView.DataSource = _studentListDataView;
        }

        private void showEntireDataButton_Click(object sender, EventArgs e)
        {
            // Reset the RowFilter property to an empty string
            if (_studentListDataView != null)
            {
                _studentListDataView.RowFilter = "";
                // Rebind the DataView to the data source
                studentsReportsDataGridView.DataSource = _studentListDataView;
            }
        }

        private void orginalityButton_Click(object sender, EventArgs e)
        {
            OriginalityForm originalityForm = new OriginalityForm(_assignmentsFullPath);
            originalityForm.ShowDialog();
        }
    }
}
