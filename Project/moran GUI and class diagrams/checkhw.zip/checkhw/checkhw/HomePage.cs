﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace checkhw
{
    public partial class HomePage : Form
    {
        public string url_input;
        public string url_output;
        public string fileurl;
        public string lang;
        private List<Student> results = new List<Student>();
        public HomePage()
        {
            InitializeComponent();
            this.MaximizeBox = false;
        }
        private void output_btn_Click(object sender, EventArgs e)
        {
            // Show the dialog that allows user to select a file, the 
            // call will result a value from the DialogResult enum
            // when the dialog is dismissed.
            FolderBrowserDialog output = new FolderBrowserDialog();
            output.ShowDialog();
            output_url.Text = output.SelectedPath;
            url_output = output.SelectedPath;
        }
        private void input_btn_Click(object sender, EventArgs e)
        {
            // Show the dialog that allows user to select a file, the 
            // call will result a value from the DialogResult enum
            // when the dialog is dismissed.
            FolderBrowserDialog input = new FolderBrowserDialog();
            input.ShowDialog();
            input_url.Text = input.SelectedPath;
            url_input = input.SelectedPath;
        }

        private void students_btn_Click(object sender, EventArgs e)
        {
            // Show the dialog that allows user to select a file, the 
            // call will result a value from the DialogResult enum
            // when the dialog is dismissed.
            openFileDialog1.Filter = "Zip files(*.zip)|*.zip";
            DialogResult result = this.openFileDialog1.ShowDialog();
            // if a file is selected
            if (result == DialogResult.OK)
            {
                // Set the selected file URL to the textbox
                this.students_url.Text = this.openFileDialog1.FileName;
            }
        }

        public void next_btn_Click(object sender, EventArgs e)
        {
            string startPath = students_url.Text;
            string inputPath = url_input;
            string outputPath = url_output;
            string extractPath = extract_url.Text;
            var myForm = new Cp(ref results, extractPath, inputPath, outputPath);
            myForm.Show();
            this.Hide();

        }

        private void HomePage_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Pen pen = new Pen(Color.FromArgb(96, 155, 173), 1);
            Rectangle area = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
            LinearGradientBrush brush = new LinearGradientBrush(area, Color.FromArgb(96, 155, 173), Color.FromArgb(245, 251, 251), LinearGradientMode.Vertical);
            graphics.FillRectangle(brush, area);
            graphics.DrawRectangle(pen, area);
        }

        private void input_btn_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, input_btn.ClientRectangle, SystemColors.ControlLightLight, 0, ButtonBorderStyle.Outset,
             SystemColors.ControlLightLight, 0, ButtonBorderStyle.Outset, SystemColors.ControlLightLight, 0, ButtonBorderStyle.Outset,
             SystemColors.ControlLightLight, 0, ButtonBorderStyle.Outset);
        }

        private void exctract_btn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog exctract = new FolderBrowserDialog();
            exctract.RootFolder = Environment.SpecialFolder.MyComputer;
            exctract.ShowDialog();
            extract_url.Text = exctract.SelectedPath;
            fileurl = exctract.SelectedPath;
        }

        private void lang_C_CheckedChanged(object sender, EventArgs e)
        {

            if(lang_C.Checked) 
            {
                lang = "C"; 
            }
        }

        private void lang_J_CheckedChanged(object sender, EventArgs e)
        {
            if (lang_J.Checked)
            {
                lang = "Java";
            }
        }

        private void lang_P_CheckedChanged(object sender, EventArgs e)
        {
            if (lang_P.Checked)
            {
                lang = "Python";
            }

        }
    }
}
