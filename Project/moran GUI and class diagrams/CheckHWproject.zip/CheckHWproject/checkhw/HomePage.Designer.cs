﻿namespace checkhw
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.chooseInput = new System.Windows.Forms.Label();
            this.input_url = new System.Windows.Forms.TextBox();
            this.output_url = new System.Windows.Forms.TextBox();
            this.chooseOutput = new System.Windows.Forms.Label();
            this.students_url = new System.Windows.Forms.TextBox();
            this.chooseStudents = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.chooseLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lang_C = new System.Windows.Forms.RadioButton();
            this.lang_J = new System.Windows.Forms.RadioButton();
            this.lang_P = new System.Windows.Forms.RadioButton();
            this.output_btn = new FontAwesome.Sharp.IconButton();
            this.students_btn = new FontAwesome.Sharp.IconButton();
            this.next_btn = new FontAwesome.Sharp.IconButton();
            this.input_btn = new FontAwesome.Sharp.IconButton();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.exctract_btn = new FontAwesome.Sharp.IconButton();
            this.extract_url = new System.Windows.Forms.TextBox();
            this.zip_exctract = new System.Windows.Forms.Label();
            this.installation_btn = new FontAwesome.Sharp.IconButton();
            this.installation_url = new System.Windows.Forms.TextBox();
            this.installation_lable = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "Input";
            // 
            // chooseInput
            // 
            this.chooseInput.AutoSize = true;
            this.chooseInput.BackColor = System.Drawing.Color.Transparent;
            this.chooseInput.Font = new System.Drawing.Font("Dubai", 12F);
            this.chooseInput.Location = new System.Drawing.Point(343, 131);
            this.chooseInput.Name = "chooseInput";
            this.chooseInput.Size = new System.Drawing.Size(237, 34);
            this.chooseInput.TabIndex = 2;
            this.chooseInput.Text = "Choose testing input folder:";
            // 
            // input_url
            // 
            this.input_url.Cursor = System.Windows.Forms.Cursors.Default;
            this.input_url.Location = new System.Drawing.Point(586, 132);
            this.input_url.Name = "input_url";
            this.input_url.Size = new System.Drawing.Size(125, 27);
            this.input_url.TabIndex = 3;
            // 
            // output_url
            // 
            this.output_url.Cursor = System.Windows.Forms.Cursors.Default;
            this.output_url.Location = new System.Drawing.Point(586, 202);
            this.output_url.Name = "output_url";
            this.output_url.Size = new System.Drawing.Size(125, 27);
            this.output_url.TabIndex = 6;
            // 
            // chooseOutput
            // 
            this.chooseOutput.AutoSize = true;
            this.chooseOutput.BackColor = System.Drawing.Color.Transparent;
            this.chooseOutput.Font = new System.Drawing.Font("Dubai", 12F);
            this.chooseOutput.Location = new System.Drawing.Point(312, 198);
            this.chooseOutput.Name = "chooseOutput";
            this.chooseOutput.Size = new System.Drawing.Size(268, 34);
            this.chooseOutput.TabIndex = 5;
            this.chooseOutput.Text = "Choose predicted output folder:";
            // 
            // students_url
            // 
            this.students_url.Cursor = System.Windows.Forms.Cursors.Default;
            this.students_url.Location = new System.Drawing.Point(586, 273);
            this.students_url.Name = "students_url";
            this.students_url.Size = new System.Drawing.Size(125, 27);
            this.students_url.TabIndex = 9;
            // 
            // chooseStudents
            // 
            this.chooseStudents.AutoSize = true;
            this.chooseStudents.BackColor = System.Drawing.Color.Transparent;
            this.chooseStudents.Font = new System.Drawing.Font("Dubai", 12F);
            this.chooseStudents.Location = new System.Drawing.Point(381, 269);
            this.chooseStudents.Name = "chooseStudents";
            this.chooseStudents.Size = new System.Drawing.Size(199, 34);
            this.chooseStudents.TabIndex = 8;
            this.chooseStudents.Text = "Choose moodle zip file:";
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.Color.Transparent;
            this.title.Font = new System.Drawing.Font("Colonna MT", 48F);
            this.title.Location = new System.Drawing.Point(173, 31);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(437, 85);
            this.title.TabIndex = 11;
            this.title.Text = "HW Testing";
            this.title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chooseLabel
            // 
            this.chooseLabel.AutoSize = true;
            this.chooseLabel.BackColor = System.Drawing.Color.Transparent;
            this.chooseLabel.Font = new System.Drawing.Font("Dubai", 12F);
            this.chooseLabel.Location = new System.Drawing.Point(27, 148);
            this.chooseLabel.Name = "chooseLabel";
            this.chooseLabel.Size = new System.Drawing.Size(272, 34);
            this.chooseLabel.TabIndex = 12;
            this.chooseLabel.Text = "Choose programming language: ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::checkhw.Properties.Resources.c_original_logo_icon_146611;
            this.pictureBox1.Location = new System.Drawing.Point(59, 206);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::checkhw.Properties.Resources.java_original_wordmark_logo_icon_146459;
            this.pictureBox2.Location = new System.Drawing.Point(51, 275);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(57, 49);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::checkhw.Properties.Resources.python_vertical_logo_icon_168039;
            this.pictureBox3.Location = new System.Drawing.Point(59, 359);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(57, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            // 
            // lang_C
            // 
            this.lang_C.AutoSize = true;
            this.lang_C.BackColor = System.Drawing.Color.Transparent;
            this.lang_C.Location = new System.Drawing.Point(35, 219);
            this.lang_C.Name = "lang_C";
            this.lang_C.Size = new System.Drawing.Size(17, 16);
            this.lang_C.TabIndex = 22;
            this.lang_C.TabStop = true;
            this.lang_C.UseVisualStyleBackColor = false;
            this.lang_C.CheckedChanged += new System.EventHandler(this.lang_C_CheckedChanged);
            // 
            // lang_J
            // 
            this.lang_J.AutoSize = true;
            this.lang_J.BackColor = System.Drawing.Color.Transparent;
            this.lang_J.Location = new System.Drawing.Point(34, 290);
            this.lang_J.Name = "lang_J";
            this.lang_J.Size = new System.Drawing.Size(17, 16);
            this.lang_J.TabIndex = 23;
            this.lang_J.TabStop = true;
            this.lang_J.UseVisualStyleBackColor = false;
            this.lang_J.CheckedChanged += new System.EventHandler(this.lang_J_CheckedChanged);
            // 
            // lang_P
            // 
            this.lang_P.AutoSize = true;
            this.lang_P.BackColor = System.Drawing.Color.Transparent;
            this.lang_P.Location = new System.Drawing.Point(35, 370);
            this.lang_P.Name = "lang_P";
            this.lang_P.Size = new System.Drawing.Size(17, 16);
            this.lang_P.TabIndex = 24;
            this.lang_P.TabStop = true;
            this.lang_P.UseVisualStyleBackColor = false;
            this.lang_P.CheckedChanged += new System.EventHandler(this.lang_P_CheckedChanged);
            // 
            // output_btn
            // 
            this.output_btn.BackColor = System.Drawing.Color.Transparent;
            this.output_btn.FlatAppearance.BorderSize = 0;
            this.output_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.output_btn.ForeColor = System.Drawing.Color.Transparent;
            this.output_btn.IconChar = FontAwesome.Sharp.IconChar.CloudArrowUp;
            this.output_btn.IconColor = System.Drawing.Color.Black;
            this.output_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.output_btn.Location = new System.Drawing.Point(721, 196);
            this.output_btn.Name = "output_btn";
            this.output_btn.Size = new System.Drawing.Size(54, 39);
            this.output_btn.TabIndex = 25;
            this.output_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.output_btn.UseVisualStyleBackColor = false;
            this.output_btn.Click += new System.EventHandler(this.output_btn_Click);
            // 
            // students_btn
            // 
            this.students_btn.BackColor = System.Drawing.Color.Transparent;
            this.students_btn.FlatAppearance.BorderSize = 0;
            this.students_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.students_btn.ForeColor = System.Drawing.Color.Transparent;
            this.students_btn.IconChar = FontAwesome.Sharp.IconChar.CloudArrowUp;
            this.students_btn.IconColor = System.Drawing.Color.Black;
            this.students_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.students_btn.Location = new System.Drawing.Point(721, 267);
            this.students_btn.Name = "students_btn";
            this.students_btn.Size = new System.Drawing.Size(54, 39);
            this.students_btn.TabIndex = 26;
            this.students_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.students_btn.UseVisualStyleBackColor = false;
            this.students_btn.Click += new System.EventHandler(this.students_btn_Click);
            // 
            // next_btn
            // 
            this.next_btn.BackColor = System.Drawing.Color.Transparent;
            this.next_btn.FlatAppearance.BorderSize = 0;
            this.next_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.next_btn.ForeColor = System.Drawing.Color.Transparent;
            this.next_btn.IconChar = FontAwesome.Sharp.IconChar.AnglesDown;
            this.next_btn.IconColor = System.Drawing.Color.Black;
            this.next_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.next_btn.Location = new System.Drawing.Point(806, 438);
            this.next_btn.Name = "next_btn";
            this.next_btn.Rotation = 270D;
            this.next_btn.Size = new System.Drawing.Size(61, 39);
            this.next_btn.TabIndex = 27;
            this.next_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.next_btn.UseVisualStyleBackColor = false;
            this.next_btn.Click += new System.EventHandler(this.next_btn_Click);
            // 
            // input_btn
            // 
            this.input_btn.BackColor = System.Drawing.Color.Transparent;
            this.input_btn.FlatAppearance.BorderSize = 0;
            this.input_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.input_btn.ForeColor = System.Drawing.Color.Transparent;
            this.input_btn.IconChar = FontAwesome.Sharp.IconChar.CloudArrowUp;
            this.input_btn.IconColor = System.Drawing.Color.Black;
            this.input_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.input_btn.Location = new System.Drawing.Point(721, 126);
            this.input_btn.Name = "input_btn";
            this.input_btn.Size = new System.Drawing.Size(54, 39);
            this.input_btn.TabIndex = 15;
            this.input_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.input_btn.UseVisualStyleBackColor = false;
            this.input_btn.Click += new System.EventHandler(this.input_btn_Click);
            this.input_btn.Paint += new System.Windows.Forms.PaintEventHandler(this.input_btn_Paint);
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.UserProfile;
            // 
            // exctract_btn
            // 
            this.exctract_btn.BackColor = System.Drawing.Color.Transparent;
            this.exctract_btn.FlatAppearance.BorderSize = 0;
            this.exctract_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exctract_btn.ForeColor = System.Drawing.Color.Transparent;
            this.exctract_btn.IconChar = FontAwesome.Sharp.IconChar.CloudArrowUp;
            this.exctract_btn.IconColor = System.Drawing.Color.Black;
            this.exctract_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.exctract_btn.Location = new System.Drawing.Point(721, 335);
            this.exctract_btn.Name = "exctract_btn";
            this.exctract_btn.Size = new System.Drawing.Size(54, 39);
            this.exctract_btn.TabIndex = 30;
            this.exctract_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.exctract_btn.UseVisualStyleBackColor = false;
            this.exctract_btn.Click += new System.EventHandler(this.exctract_btn_Click);
            // 
            // extract_url
            // 
            this.extract_url.Cursor = System.Windows.Forms.Cursors.Default;
            this.extract_url.Location = new System.Drawing.Point(586, 341);
            this.extract_url.Name = "extract_url";
            this.extract_url.Size = new System.Drawing.Size(125, 27);
            this.extract_url.TabIndex = 29;
            // 
            // zip_exctract
            // 
            this.zip_exctract.AutoSize = true;
            this.zip_exctract.BackColor = System.Drawing.Color.Transparent;
            this.zip_exctract.Font = new System.Drawing.Font("Dubai", 12F);
            this.zip_exctract.Location = new System.Drawing.Point(235, 337);
            this.zip_exctract.Name = "zip_exctract";
            this.zip_exctract.Size = new System.Drawing.Size(345, 34);
            this.zip_exctract.TabIndex = 28;
            this.zip_exctract.Text = "Choose folder to extract the zip students:";
            // 
            // installation_btn
            // 
            this.installation_btn.BackColor = System.Drawing.Color.Transparent;
            this.installation_btn.FlatAppearance.BorderSize = 0;
            this.installation_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.installation_btn.ForeColor = System.Drawing.Color.Transparent;
            this.installation_btn.IconChar = FontAwesome.Sharp.IconChar.CloudArrowUp;
            this.installation_btn.IconColor = System.Drawing.Color.Black;
            this.installation_btn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.installation_btn.Location = new System.Drawing.Point(721, 401);
            this.installation_btn.Name = "installation_btn";
            this.installation_btn.Size = new System.Drawing.Size(54, 39);
            this.installation_btn.TabIndex = 33;
            this.installation_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.installation_btn.UseVisualStyleBackColor = false;
            this.installation_btn.Click += new System.EventHandler(this.installation_btn_Click);
            // 
            // installation_url
            // 
            this.installation_url.Cursor = System.Windows.Forms.Cursors.Default;
            this.installation_url.Location = new System.Drawing.Point(586, 407);
            this.installation_url.Name = "installation_url";
            this.installation_url.Size = new System.Drawing.Size(125, 27);
            this.installation_url.TabIndex = 32;
            // 
            // installation_lable
            // 
            this.installation_lable.AutoSize = true;
            this.installation_lable.BackColor = System.Drawing.Color.Transparent;
            this.installation_lable.Font = new System.Drawing.Font("Dubai", 12F);
            this.installation_lable.Location = new System.Drawing.Point(182, 403);
            this.installation_lable.Name = "installation_lable";
            this.installation_lable.Size = new System.Drawing.Size(397, 34);
            this.installation_lable.TabIndex = 31;
            this.installation_lable.Text = "Choose the installation path for Java or Python:";
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 489);
            this.Controls.Add(this.installation_btn);
            this.Controls.Add(this.installation_url);
            this.Controls.Add(this.installation_lable);
            this.Controls.Add(this.exctract_btn);
            this.Controls.Add(this.extract_url);
            this.Controls.Add(this.zip_exctract);
            this.Controls.Add(this.next_btn);
            this.Controls.Add(this.students_btn);
            this.Controls.Add(this.output_btn);
            this.Controls.Add(this.lang_P);
            this.Controls.Add(this.lang_J);
            this.Controls.Add(this.lang_C);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.input_btn);
            this.Controls.Add(this.chooseLabel);
            this.Controls.Add(this.title);
            this.Controls.Add(this.students_url);
            this.Controls.Add(this.chooseStudents);
            this.Controls.Add(this.output_url);
            this.Controls.Add(this.chooseOutput);
            this.Controls.Add(this.input_url);
            this.Controls.Add(this.chooseInput);
            this.Controls.Add(this.pictureBox2);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "HomePage";
            this.Text = "HomePage";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.HomePage_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label chooseInput;
        private System.Windows.Forms.TextBox input_url;
        private System.Windows.Forms.TextBox output_url;
        private System.Windows.Forms.Label chooseOutput;
        private System.Windows.Forms.TextBox students_url;
        private System.Windows.Forms.Label chooseStudents;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label chooseLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.RadioButton lang_C;
        private System.Windows.Forms.RadioButton lang_J;
        private System.Windows.Forms.RadioButton lang_P;
        private FontAwesome.Sharp.IconButton output_btn;
        private FontAwesome.Sharp.IconButton students_btn;
        private FontAwesome.Sharp.IconButton next_btn;
        private FontAwesome.Sharp.IconButton input_btn;
        private FontAwesome.Sharp.IconButton exctract_btn;
        private System.Windows.Forms.TextBox extract_url;
        private System.Windows.Forms.Label zip_exctract;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private FontAwesome.Sharp.IconButton installation_btn;
        private System.Windows.Forms.TextBox installation_url;
        private System.Windows.Forms.Label installation_lable;
    }
}