//HW2.2.C
/*
DANIEL RAHAMIM
315754499
HW2.2
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int num, r, check;
	do {
		printf("Please enter number : ");
		check = scanf("%d", &num);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check < 1)
		{
			printf("Only numbers***");
		}
	} while (check > 1);
	while (num > 0)
	{
		if (num > 5000)
		{
			printf("Number cannot be higher than 5000");
			num = 0;
		}
		else if (num >= 1000)
		{
			r = num / 1000;
			num = num % 1000;
			while (r > 0)
			{
				r--;
				printf("M");
			}
		}
		else if (num >= 500)
		{
			r = num / 500;
			num = num % 500;
			while (r > 0)
			{
				r--;
				printf("D");
			}

		}
		else if (num >= 100)
		{
			r = num / 100;
			num = num % 100;
			while (r > 0)
			{
				r--;
				printf("C");
			}
		}
		else if (num >= 50)
		{
			r = num / 50;
			num = num % 50;
			while (r > 0)
			{
				r--;
				printf("L");
			}
		}
		else if (num >= 10)
		{
			r = num / 10;
			num = num % 10;
			while (r > 0)
			{
				r--;
				printf("X");
			}
		}
		else if (num >= 5)
		{
			r = num / 5;
			num / num % 5;
			while (r > 0)
			{
				r--;
				printf("V");
			}
		}
		else
		{
			r = num / 1;
			num = num - r;
			while (r > 0)
			{
				r--;
				printf("I");
			}
		}
	}

}
//PELET OUTPOT
/*
Please enter number : AS
Only numbers***
Please enter number : 5600
Number cannot be higher than 5000
Please enter number : 3652
MMMDCLII
*/