// romanian.c --> hw02\ second question
/* Walaa Mruwat
* 325224194
* Home Work 7 ( if , else , check input , while , array)
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
	char roman[7] = { 'I' , 'V' , 'X' , 'L' , 'C' , 'D' , 'M' };
	int check, num, k = 1000, i = 6;
	// k = the value of the roman symbol at place [i] in the array.
	do {
		printf("Please enter a positive number between 0-5000  : \n");
		check = scanf("%d", &num);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check < 1 || num <= 0 || num > 5000)
		{
			printf("\n **** Error , Enter positive number only between 0-5000 **** \n");
		}
	} while (check < 1 || num <= 0 || num > 5000);
	while (k >= 1)
	{
		while ((num / k) > 0)
		{
			printf("%c", roman[i]);
			num -= k;
		}
		if ((i % 2) == 0)
			k = k / 2;
		else k = k / 5;
		i--;
	}
}
/*	case 1 :
Please enter a positive number  :
1078
MLXXVIII

case 2:
Please enter a positive number between 0-5000  :
-100

 **** Error , Enter positive number only between 0-5000 ****
Please enter a positive number between 0-5000  :
1243
MCCXXXXIII

case 3 :
Please enter a positive number between 0-5000  :
5555

 **** Error , Enter positive number only between 0-5000 ****
Please enter a positive number between 0-5000  :
4786
MMMMDCCLXXXVI

*/