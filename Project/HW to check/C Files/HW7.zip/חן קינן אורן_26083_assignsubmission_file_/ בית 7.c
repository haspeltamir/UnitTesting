//����� ��� 7//

/*
Chen Keynan Oren
322392622
HW02 Q2
������
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>


void main()
{
	int i, first_digit, second_digit, third_digit, fourth_digit, j;
	printf("Enter a number between 1 and 5000 to get its equivalent in Roman numerals: ");
	scanf("%d", &i);
	if (i > 0 && i <= 5000)
	{
		first_digit = i % 10;
		second_digit = (i / 10) % 10;
		third_digit = (i / 100) % 10;
		fourth_digit = i / 1000;
		for (j = fourth_digit; j > 0; j--)
		{
			printf("M");
		}
		for (j = third_digit; j > 0; j--)
		{
			if (j == 9)
			{
				printf("CM");
				j -= 9;
			}
			else if (j >= 5)
			{
				printf("D");
				j -= 5;
			}
			else if (j == 4)
			{
				printf("CD");
				j -= 4;
			}
			if (j > 0)
				printf("C");
		}
		for (j = second_digit; j > 0; j--)
		{
			if (j == 9)
			{
				printf("XC");
				j -= 9;
			}
			else if (j >= 5)
			{
				printf("L");
				j -= 5;
			}
			else if (j == 4)
			{
				printf("XL");
				j -= 4;
			}
			if (j > 0)
				printf("X");
		}
		for (j = first_digit; j > 0; j--)
		{
			if (j == 9)
			{
				printf("IX");
				j -= 9;
			}
			else if (j >= 5)
			{
				printf("V");
				j -= 5;
			}
			else if (j == 4)
			{
				printf("IV");
				j -= 4;
			}
			if (j > 0)
				printf("I");
		}
	}
	else printf("Number out of bounds.");
}

/*
Output:

Enter a number between 1 and 5000 to get its equivalent in Roman numerals: 1078
MLXXVIII
D:\Documents\Visual Studio 2022\repos\Project1\x64\Debug\Project1.exe (process 7248) exited with code 0.
Press any key to close this window . . .