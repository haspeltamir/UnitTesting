//HW2.2.c
/*
lidor ben simon
207925330
rotem swisa
207788027
do while
if
else if
else
for
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	//����� ����� ��� 1-5000
	//����� ���� ���� ������ ������ 
	//����� ������ ������� ������ 

	unsigned int num, thousands, five_hundred, hundreds, fifty, tens, fives, ones,check;

	do {
		printf("\nEnter a number between 1 - 5000:  ");

		check=scanf("%u", &num);

		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check<1)
		{
			printf("\nNote you enter only a number!");
		}
		else if (num > 5000 || num <= 0)
		{
			printf("\nNote that you only enter a number between 1-5000!");
		}
		else 
		{
			printf("\nThe number in Roman literaturs is: ");
			thousands = num / 1000;
			num = num - thousands * 1000;

			five_hundred = num / 500;
			num = num - five_hundred * 500;

			hundreds = num / 100;
			num = num - hundreds * 100;

			fifty = num / 50;
			num = num - fifty * 50;

			tens = num / 10;
			num = num - tens * 10;

			fives = num / 5;
			num = num - fives * 5;
			ones = num;

			for (thousands; thousands > 0; thousands--)
			{
				printf("M");
			}
			for (five_hundred; five_hundred > 0; five_hundred--)
			{
				printf("D");
			}
			for (hundreds; hundreds > 0; hundreds--)
			{
				printf("C");
			}
			for (fifty; fifty > 0; fifty--)
			{
				printf("L");
			}
			for (tens; tens > 0; tens--)
			{
				printf("X");
			}
			for (fives; fives > 0; fives--)
			{
				printf("V");
			}
			for (ones; ones > 0; ones--)
			{
				printf("I");
			}
		}
	} while (num > 5000 || num <= 0);
}

/*PELET/OUTPOT
Enter a number between 1 - 5000:  A

Note you enter only a number!
Enter a number between 1 - 5000:  -38

Note that you only enter a number between 1-5000!
Enter a number between 1 - 5000:  0

Note that you only enter a number between 1-5000!
Enter a number between 1 - 5000:  9432

Note that you only enter a number between 1-5000!
Enter a number between 1 - 5000:  3428

The number in Roman literaturs is: MMMCCCCXXVIII
C:\Users\USER\Desktop\������� ��� C\HW2.2\x64\Debug\HW2.2.exe (process 4548) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .*/