/*
* ���� 7
Name:Shahid haj hassan
Id:214073900
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int num;
	printf("please enter a number:");
	do
	{
		scanf("%d", &num);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		while (num != 0)
		{
			if (num >= 1000)
			{
				printf("M");
				num = num - 1000;
			}
			else if (num >= 500)
			{
				printf("D");
				num = num - 500;
			}
			else if (num >= 100)
			{
				printf("C");
				num = num - 100;
			}
			else if (num >= 50)
			{
				printf("L");
				num = num - 50;
			}
			else if (num >= 10)
			{
				printf("X");
				num = num - 10;
			}
			else if (num >= 5)
			{
				printf("V");
				num = num - 5;
			}
			else if (num >= 1)
			{
				printf("I");
				num = num - 1;
			}
		}
	} while (num == 0);
	/*
	please enter a number:1704
    MDCCIIII
	*/
}
