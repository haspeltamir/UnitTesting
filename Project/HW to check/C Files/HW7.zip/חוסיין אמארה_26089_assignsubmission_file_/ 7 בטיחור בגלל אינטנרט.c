﻿/*אמארה חוסיין 
 213020670
 אגבאריה מגד
 21173291
 מטלה 7 
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{

	int n, x = 0;
	do {
		printf("Enter A number from 1 to 5000:");
		scanf("%d", &n);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (n > 5000 || n<0)
		{
			printf("\nError...TRY AGAIN : \n");
		}
	} while (n > 5000 || n<=0);

	while (n>0)
	{
		n = n - x;
		x = 0;
		if (n >= 1000)
		{
			x = 1000;
			printf("M");
			continue;
		}
		if (n >= 500)
		{
			x = 500;
			printf("D");
			
			continue;
		}
		if (n >= 100)
		{
			x = 100;
			printf("C");
			continue;
		}
		if (n >= 50)
		{
			x = 50;
			printf("L");
			continue;
		}
		if (n > 10)
		{
			x = 10;
			printf("X");
			continue;
		}
		if (n >= 5)
		{
			x = 5;
			printf("V");
			continue;
		}
		if (n >= 1)
		{
			x = 1;
			printf("I");
			continue;
		}
	}
}
/*Pelet (output)
Enter A number from 1 to 5000:3455
MMMCCCCLV
C:\Users\house\OneDrive\Desktop\SEM.2022\homewqrk7\x64\Debug\homewqrk7.exe (process 4700) exited with code 0.
Press any key to close this window . . .
*/