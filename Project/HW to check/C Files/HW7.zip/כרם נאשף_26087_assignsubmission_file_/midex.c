/*
Karam nashef
2133444789
hw02
q2
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{
	int num,a,b;
	
	printf("Enter number between 0-5000:\n");

	scanf("%d", &num);
	//2800
	if (num > 0 && num <= 5000)
	{
		if (num >= 1000)
		{
			a = num / 1000;
			for (b = 0;a > b;b++)
			{
				printf("M");
			}
			num = num - (a * 1000);
		}
		 if (num >= 500 && num<1000)
		{
			a = num / 500;
			for (b = 0;a > b;b++)
			{
				printf("D");
			}
			num = num - (a * 500);
		}
		if (num >= 100 &&num<500)
		{
			a = num / 100;
			for (b = 0;a > b;b++)
			{
				printf("C");
			}
			num = num - (a * 100);
		}

		if (num >= 50 && num < 100)
		{
			a = num / 50;
			for (b = 0;a > b;b++)
			{
				printf("L");
			}
			num = num - (a * 50);
		}
		if (num >= 10 && num < 50)
		{
			a = num / 10;
			for (b = 0;a > b;b++)
			{
				printf("X");
			}
			num = num - (a * 10);
		}
		if (num >= 5 && num < 10)
		{
			a = num / 5;
			for(b=0;a>b;b++)
			{
				printf("V");
			}
			num = num - (a * 5);
		}
		if (num >= 1 && num < 5)
		{
			a = num / 1;
			for (b = 0;a > b;b++)
			{
				printf("I");
			}
		}
	}
	else
	{
		printf("ERROR");
	}
}
/*
OUTPUT-PELET
Enter number between 0-5000:
2563
MMDLXIII
C:\Users\WINDOWS 10 PRO\Desktop\karam C\Class Work\midex\x64\Debug\midex.exe (process 14584) exited with code 0.
Press any key to close this window . . .
*/


