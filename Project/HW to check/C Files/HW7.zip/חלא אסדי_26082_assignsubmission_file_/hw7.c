//hw7.c
/*
Hala Assadi
324830967
Taqwa Marwat
212804017
hw7.2
loops
*/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
	int num, n, n1,n2,n3;
	printf("please enter  number:");
	scanf("%d", &num);
	n = num / 1000;
	n1 = (num - n * 1000) /100;
	n2 = (num - n * 1000 - n1 * 100)/10;
	n3 = num - n * 1000 - n1 * 100 - n2 * 10;
	while (num < 5001 && num > 1)
	{
		if (n>0 && n <5)
		{
			for (int i = 0; i < n; i++)
			{
				printf("M");
			}
		}
		if (n1 > 0 && n1 < 5)
		{
			for (int i = 0; i < n1; i++)
			{
				printf("C");
			}
		}
		else if(n1>=5 && n1<10)
		{
		    printf("D");
		    for (int i = 0; i < n1-5; i++)
			{
			 printf("C");
			}
		}
		if (n2 > 0 && n2 < 5)
		{

			for (int i = 0; i < n2; i++)
			{
				printf("X");
			}
		}
		else if (n2 > 4 && n2 < 10)
		{
		  printf("L");
		  for (int i = 0; i < n2 - 5; i++)
		  {
		   printf("X");
		  }
		}
		if (n3 >0 && n3 < 5)
		{
			for (int i = 0; i < n3; i++)
			{
				printf("I");
			}
		}
		else if (n3 >4 && n3<10)
		{
			printf("V");
			for (int i = 0; i < n3 - 5; i++)
			{
				printf("I");
			}
		}
		break;
		
	} 
	if (num < 1 || num>5000)
	{
		printf("ERROR!");
	}
}
/*
please enter  number:0
ERROR!

please enter  number:5001
ERROR!

please enter  number:1078
MLXXVIII

please enter  number:3000
MMM 

please enter  number:756
DCCLVI

please enter  number:200
CC

please enter  number:73
LXXIII

please enter  number:10
X
*/
