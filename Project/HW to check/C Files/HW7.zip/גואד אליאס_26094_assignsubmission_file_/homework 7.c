/*
Jawad Elias
311379689
Room 6201
Homework 7 HW02 Q02
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main() {
	int num,x=0, m=0, d=0, c=0, l=0, v=0, I=0, i;
	
	printf("Please enter number :");
	scanf("%d", &num);
	if ((num>0) && (num < 5000)) {
		if (num >= 1000) {
			m = num / 1000;
			num = num % 1000;
			for(i=0;i<m;i++){
			printf("M");
			}
		}
		if (num >= 500) {
			d = num / 500;
			num = num % 500;
			for (i=0;i<d;i++){
			printf("D");
			}
		}
		if (num >= 100) {
			c = num / 100;
			num = num % 100;
			for(i=0;i<c;i++){
			printf("C");
			}
		}
		if (num >= 50) {
			l = num / 50;
			num = num % 50;
			for(i=0;i<l;i++){
			printf("L");
			}
		}
		if (num >= 10) {
			x = num / 10;
			num = num % 10;
			for (i = 0; i < x; i++) {
				printf("X");
			}
		}
		if (num >= 5) {
			v = num / 5;
			num = num % 5;
			for(i=0;i<v;i++){
			printf("V");
			}
		}
		
			for(i=0;i<num;i++){
			printf("I");
			}

	}
	else { printf("ERROR!!!! number is outside of range"); }
}

/* Pelet/Output
(1)
Please enter number :2867
MMDCCCLXVII
D:\JJE6194\Software Engineering\C-Language\Homework 7\x64\Debug\Homework 7.exe (process 3428) exited with code 0.
Press any key to close this window . . .

(2)
Please enter number :3976
MMMDCCCCLXXVI
D:\JJE6194\Software Engineering\C-Language\Homework 7\x64\Debug\Homework 7.exe (process 13160) exited with code 0.
Press any key to close this window . . .

(3)
Please enter number :48654
ERROR!!!! number is outside of range
D:\JJE6194\Software Engineering\C-Language\Homework 7\x64\Debug\Homework 7.exe (process 7408) exited with code 0.
Press any key to close this window . . .
*/
