/*HW Q2.2
 OREN KATZ
 302839899
 */
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	int number, check, count;
	do
	{
	printf("enter number between 1 to 5000: ");
	 check = scanf("%d", &number);
	{char c; while ((c = getchar()) != '\n' && c != EOF); }
	if (check < 1 || number < 1|| number > 5000)
	{
		printf("the number have to be between 1 to 5000");
	}
	} while (check < 1 || number < 1 || number > 5000);
	
	while (number > 0)
	{
		if (number >= 1000)
		{
			count = number / 1000;
			number = number % 1000;
			while (count >= 0)
			{
				count--;
				printf("M");
			}
		}
		else if (number >= 500)
		{
			count = number / 500;
			number = number % 500;
			while (count > 0)
			{
				count--;
				printf("D");
			}

		}
		else if (number > 100)
		{
			count = number / 100;
			number = number % 100;
			while (count > 0)
			{
				count--;
				printf("C");
			}
		}
		else if (number > 50)
		{
			count = number / 50;
			number = number % 50;
			while (count > 0)
			{
				count--;
				printf("L");
			}
		}
		else if (number > 10)
		{
			count = number / 10;
			number = number % 10;
			while (count > 0)
			{
				count--;
				printf("X");
			}
		}
		else if (number > 5)
		{
			count = number / 5;
			number = number % 5;
			while (count > 0)
			{
				count--;
				printf("V");
			}
		}
		else
		{
			count = number / 1;
			number = number % 1;
			while (count > 0)
			{
				count--;
				printf("I");
			}
		}
		
	}



}
/*
enter number between 1 to 5000: 4821
MMMMDCCCXXI
D:\Users\dell\Desktop\��� C\����� 2.2\x64\Debug\����� 2.2.exe (process 23572) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/
	
	












	




	