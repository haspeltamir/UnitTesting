/*
HW2.2
������
Shahar Shabtay
211667852
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int num, i = 0, x, j;
	
	printf("Please enter a number 1-5000:");
	scanf("%d",&num);

	while (num /1000 !=0)
	{
		num -= 1000;
			printf("M");
	}
	while (num / 500 != 0)
	{
		num -= 500;
			printf("D");
	}
	while (num / 100 != 0)
	{
		num -= 100;
			printf("C");
	}
	while (num / 50 != 0)
	{
		num -= 50;
			printf("L");
	}
	while (num / 10 != 0)
	{
		num -= 10;
			printf("X");
	}
	while (num / 5 != 0)
	{
		num -= 5;
			printf("V");
	}
	while (num / 1 != 0)
	{
		num -= 1;
			printf("I");
	}
	return 0;
}


/*Please enter a number 1 - 5000:2023
MMXXIII
C : \Users\User\Desktop\������\HW2.2\x64\Debug\HW2.2.exe(process 17212) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .*/







