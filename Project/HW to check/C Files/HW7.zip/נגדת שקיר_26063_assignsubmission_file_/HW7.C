/*
HW7.c
Name : Najdat Shkeer
ID : 322925470
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
void main()
{
    int num, test;
    do {
        printf("Enter number:\n");
        test = scanf("%d", &num);
        {char c; while ((c = getchar()) != '\n' && c != EOF); }
        if (test < 1)
        {
            printf("PLEASE ENTER NUMBERS!\n");
            continue;
        }
        else if (num < 1 || num>5000)
            printf("Please enter natural numbers under 5000\n");
    } while (num < 1 || num>5000 || test < 1);

    while (num != 0)
    {
        if (num >= 1000)
        {
            printf("M");
            num -= 1000;
        }

        else if (num >= 900)
        {
            printf("CM");
            num -= 900;
        }

        else if (num >= 500)
        {
            printf("D");
            num -= 500;
        }

        else if (num >= 400)
        {
            printf("CD");
            num -= 400;
        }

        else if (num >= 100)
        {
            printf("C");
            num -= 100;
        }

        else if (num >= 90)
        {
            printf("XC");
            num -= 90;
        }

        else if (num >= 50)
        {
            printf("L");
            num -= 50;
        }

        else if (num >= 40)
        {
            printf("XL");
            num -= 40;
        }

        else if (num >= 10)
        {
            printf("X");
            num -= 10;
        }

        else if (num >= 9)
        {
            printf("VIIII");
            num -= 9;
        }

        else if (num >= 5)
        {
            printf("V");
            num -= 5;
        }

        else if (num >= 1)
        {
            printf("I");
            num -= 1;

        }
    }
}
/* OUTPUT 
Enter number:
hg
PLEASE ENTER NUMBERS!
Enter number:
-345
Please enter natural numbers under 5000
Enter number:
1078
MLXXVIII
C:\Users\Win 10\OneDrive\Desktop\c++\Project3\x64\Debug\Project3.exe (process 26888) exited with code 0.
Press any key to close this window . . .
*/