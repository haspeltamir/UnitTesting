﻿//                                               גולאן דעבוס.......ת"ז מספר:207112137

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#define M 1000
#define D 500
#define C 100
#define L 50
#define X 10
#define V 5
#define I 1

void main() {
	int num, c, i;
	char z[100];
	printf("Please enter a real number up to 5000:");
	fflush(stdout);
	fgets(z, sizeof(z), stdin);
	num = atoi(z);

	while (num > 5 * M || num <= 0 || !isdigit(*z) )
	{
		printf("Please enter a real number up to 5000:");
		fflush(stdout);
		fgets(z, sizeof(z), stdin);
		num = atoi(z);

	} 
		for (num; num > I; num == num) {
			if (num >= M) {
				c = num / M;
				for (i = 0; i < c; i++) {
					printf("M");
				}
				num = num % M;
			}
			else if (num >= D && num < M) {
				c = num / D;
				for (i = 0; i < c; i++) {
					printf("D");
				}
				num = num % D;
			}
			else if (num >= C && num < D) {
				c = num / C;
				for (i = 0; i < c; i++) {
					printf("C");
				}
				num = num % C;
			}
			else if (num >= L && num < C)
			{
				c = num / L;
				for (i = 0; i < c; i++) {
					printf("L");
				}
				num = num % L;
			}
			else if (num >= X && num < L) {
				c = num / X;
				for (i = 0; i < c; i++)
				{
					printf("X");
				}
				num = num % X;
			}
			else if (num >= V && num < X) {
				c = num / V;
				for (i = 0; i < c; i++) {
					printf("V");
				}
				num = num % V;
			}
			else if (num > I && num < V) {
				c = num / I;
				for (i = 0; i < c; i++) {
					printf("I");
				}
				num = num % I;
			}
			
		}
		if (num == I) {
			printf("I");
			}
	
}
//Please enter a real number up to 5000:sdd
//Please enter a real number up to 5000:*//
//Please enter a real number up to 5000 : -75
//Please enter a real number up to 5000 : 7695
//Please enter a real number up to 5000 : 4789
//MMMMDCCLXXXVIIII
//C : \Users\Admin\source\repos\Project2\x64\Debug\Project2.exe(process 14996) exited with code 0.
//Press any key to close this window . . .