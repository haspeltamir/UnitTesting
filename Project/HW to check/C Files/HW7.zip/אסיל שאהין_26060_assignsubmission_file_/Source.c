﻿/*
Homework7
Qustion2
Name: Aseel Shaheen + מוחמד חואלד
ID: 214228009 + 207930892
HW02
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main() {

	int nor, x;

	do {

		printf("Please enter a number from 1 to 5000 :");
		scanf("%d", &x);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }

		if (x < 0 || x > 5000 || x == 0 || x == '\n') {
			printf("***ERROR*** ,only number from 1 to 5000\n\n");
		}
		else {
			nor = x;

			while (nor > 0 && nor <= 5000) {

				if (nor >= 1000) {
					printf("M");
					nor -= 1000;
				}

				else if (nor >= 500) {
					printf("D");
					nor -= 500;
				}

				else if (nor >= 100) {
					printf("C");
					nor -= 100;
				}

				else if (nor >= 50) {
					printf("L");
					nor -= 50;
				}

				else if (nor >= 10) {
					printf("X");
					nor -= 10;
				}

				else if (nor >= 5) {
					printf("V");
					nor -= 5;
				}

				else if (nor >= 1) {
					printf("I");
					nor -= 1;
				}
			}
		}
	} while (x < 0 || x == 0 || x > 5000 || x == '\n');
}
/*
Please enter a number from 1 to 5000 :-123
***ERROR*** ,only number from 1 to 5000

Please enter a number from 1 to 5000 :aa
***ERROR*** ,only number from 1 to 5000

Please enter a number from 1 to 5000 :60023
***ERROR*** ,only number from 1 to 5000

Please enter a number from 1 to 5000 :0
***ERROR*** ,only number from 1 to 5000

Please enter a number from 1 to 5000 :1078
MLXXVIII
C:\Users\ReadShaheen\OneDrive\????? ??????\C++\HomeworkFR2\Homework2\Homework2\FR123\Project1\Q5\Q3\Q3\Romania\romania2\x64\Debug\romania2.exe (process 18776) exited with code 0.
Press any key to close this window . . .
*/