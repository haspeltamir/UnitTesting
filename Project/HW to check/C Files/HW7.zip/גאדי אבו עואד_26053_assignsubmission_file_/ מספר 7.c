/* ����� ���� 7 ���� 2 HW02.C

���� ��� ����
211477468

���� ������
325159804
 
*/
#include<stdio.h>
#define _CRT_SECURE_NO_WARNINGS
void main()
{
	int check, num;
	printf("please enter a number between 1-5000 :\n");
	check = scanf_s("%d", &num);
	{char c; while ((c = getchar()) != '\n' && c != EOF); }
	if (check == 1)
	{
		if (num > 0 && num < 5000)
		{


			do
			{
				if (num >= 1000 && num <= 5000)
				{
					printf("M");
					num = num - 1000;
				}
				else	if (num >= 500 && num <= 999)
				{
					printf("D");
					num = num - 500;
				}
				else if (num >= 100 && num <= 499)
				{
					printf("C");
					num = num - 100;
				}
				else if (num >= 50 && num <= 99)
				{
					printf("L");
					num = num - 50;
				}
				else	if (num >= 10 && num <= 49)
				{
					printf("X");
					num = num - 10;
				}
				else	if (num >= 5 && num <= 9)
				{
					printf("V");
					num = num - 5;
				}
				else	if (num >= 1 && num <= 4)
				{
					printf("I");
					num = num - 1;
				}
			} while (num > 0 && num < 5000);

		}
		else
		{
			printf(" please enter a number between 1 to 5000 only  ");
		}

	}

	else
	{
		printf("please dont enter a letters , you must enter only numbers  !!");

	}
}
/*output
please enter a number between 1-5000 :
600
DC
C:\Users\a\source\repos\Project16\Debug\Project16.exe (process 10508) exited with code 0.
Press any key to close this window . . .



please enter a number between 1-5000 :
a
please dont enter a letters , you must enter only numbers  !!
C:\Users\a\source\repos\Project16\Debug\Project16.exe (process 9620) exited with code 0.
Press any key to close this window . . .



please enter a number between 1-5000 :
6000
 please enter a number between 1 to 5000 only
C:\Users\a\source\repos\Project16\Debug\Project16.exe (process 7356) exited with code 0.
Press any key to close this window . . .



*/