/*
ramiz diab
211404249
Adam Hujerat
211636972
question 2_2
6.c
*/



#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main() {
	
	
	int a;



	do{
		scanf("%d", &a);
		if (a <  0 || a > 5000) printf("eroor");
	}while (a < 0 || a > 5000);
	{	

		while (a >= 1000)
		{
			printf("M");
			a = a - 1000;
		}
	while (a >= 500)
	{
		printf("D");
		a = a - 500;
	}
	while (a >= 100)
	{
		printf("C");
		a = a - 100;
	}
	while (a >= 50)
	{
		printf("L");
		a = a - 50;
	}
	while (a >= 5)
	{
		printf("V");
		a = a - 5;
	}
	while (a >= 1)
	{
		printf("I");
		a = a - 1;
	}
}
}
/*
8888
eroor5555
eroor1234
MCCVVVVVVIIII
*/