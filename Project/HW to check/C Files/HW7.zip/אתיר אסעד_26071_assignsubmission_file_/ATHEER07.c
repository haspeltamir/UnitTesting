/*
ATHEER ASAAD
326448255
CLASS 6201 / HW02
HOMEWORK 7 QUESTION 2
*/

#define _CRT_SECURE_NO_WARNINGS
#define I 1
#define V 5
#define X 10
#define L 50
#define C 100
#define D 500
#define M 1000

#include <stdio.h>
void main() {
    int a;

    scanf("%d", &a);
    while (a >= 1000)
    {
        printf("M");
        a = a - M;
    }
    while (a >= 500)
    {
        printf("D");
        a = a - 500;
    }
    while (a >= 100)
    {
        printf("C");
        a = a - 100;
    }
    while (a >= 50)
    {
        printf("L");
        a = a - 50;
    }
    while (a >= 10)
    {
        printf("X");
        a = a - 10;
    }
    while (a >= 5)
    {
        printf("V");
        a = a - 5;
    }
    while (a >= 1)
    {
        printf("I");
        a = a - 1;
    }
}

/*//PELET/OUTPUT
4523
MMMMDXXIII
C:\Users\ADAM\OneDrive\Documents\Projects\HOMEWORKS\AADAAMM07\x64\Debug\AADAAMM07.exe (process 24820) exited with code 0.
Press any key to close this window . . .*/