//HM7.c

/*netanel shen
207473745
homework  7  exercise 2

*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



int main() {

    int num,check;

    do {
        printf("please enter a number up to 5000: ");

        check = scanf("%d", &num);

        {char c; while ((c = getchar()) != '\n' && c != EOF); };

    } while (num > 5000|| num < 1 || check < 1);



   
    while (num > 0)
    {
        if (num >= 1000)
        {
            printf("M");
            num -= 1000;
        }

        else if (num >= 500)
        {
            printf("D");
            num -= 500;
        }

        else if (num >= 100)
        {
            printf("C");
            num -= 100;
        }

        else if (num >= 50)
        {
            printf("L");
            num -= 50;
        }

        else if (num >= 10)
        {
            printf("X");
            num -= 10;
        }

        else if (num >= 5)
        {
            printf("V");
            num -= 5;
        }

        else if (num >= 1)
        {
            printf("I");
            num -= 1;
        }
    }

    return 0;
}


/*
    OUTPUT:
    please enter a number up to 5000: 3527
    MMMDXXVII

*/