//HW.2.2.c

/*
Ariel Cohen :��
��: 212111405
Homework 7, question 2
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{
	int number, check;
	do {
		printf("please enter a number between 1 and 5000\n");
		check = scanf("%d", &number);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check < 1)
			printf("Error, enter only number\n");
		else if (number < 1 || number > 5000)
			printf("Error, enter the correct number\n");
	} while (number < 1 || number > 5000 || check < 1);
	while (number != 0)
	{
		if (number >= 1000)
		{
			number = number - 1000;
			printf("M");
		}
		else
		{
			if (number >= 500)
			{
				number = number - 500;
				printf("D");
			}
			else
			{
				if (number >= 100)
				{
					number = number - 100;
					printf("C");
				}
				else
				{
					if (number >= 50)
					{
						number = number - 50;
						printf("L");
					}
					else
					{
						if (number >= 10)
						{
							number = number - 10;
							printf("X");
						}
						else
						{
							if (number >= 5)
							{
								number = number - 5;
								printf("V");
							}
							else
							{
								if (number >= 1)
								{
									number = number - 1;
									printf("I");
								}
							}
						}
					}
				}
			}
		}
	}
}
/*
please enter a number between 1 and 5000
10000
Error, enter the correct number
please enter a number between 1 and 5000
4789
MMMMDCCLXXXVIIII
E:\HW.2.2.c\x64\Debug\HW.2.2.c.exe (process 7284) exited with code 0.
Press any key to close this window . . .
*/