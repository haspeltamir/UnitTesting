//H.W,P2,E2
/*
David Ran Cohen
322777921
HW 7 PAGE 2 E 2
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	int nums;
	int thousands; //�����
	int hundreds; //����
	int tens; //�����
	int ones; //�����
	do {
	printf("please enter number 1-5000:");
	scanf("%d", &nums);
	if (nums > 5000 || nums < 1)
	{
		printf("Error\n");
	}
	} while (nums > 5000 || nums < 1);
	thousands = nums / 1000;
	for (thousands; thousands > 0; thousands--)
	{
	if (thousands > 0)
	{
		printf("M");
	}
	}
	hundreds = nums % 1000;
	hundreds = hundreds / 100;
	
	for (hundreds; hundreds > 0; hundreds--)
	{
		if (hundreds > 4)
		{
			printf("D");
			hundreds = hundreds - 5;
		}
		if (hundreds > 0)
		{
			printf("C");
		}
	}
	tens = nums % 100;
		tens = tens / 10;
		for (tens; tens > 0; tens--)
		{
			if (tens > 4)
			{
				printf("L");
				tens = tens - 5;
			}
			if (tens > 0)
			{
				printf("X");
			}
		}
		ones = nums % 10;
		
		for (ones; ones > 0; ones--)
		{
			if (ones > 4)
			{
				printf("V");
				ones = ones - 5;
			}
			if (ones > 0)
			{
				printf("I");
			}
		}	
}
/*
please enter number 1-5000:-50
Error
please enter number 1-5000:0
Error
please enter number 1-5000:5001
Error
please enter number 1-5000:63223
Error
please enter number 1-5000:4999
MMMMDCCCCLXXXXVIIII
C:\Users\��� ��\Desktop\�� 2 ����� 1\HWP2E2\x64\Debug\HWP2E2.exe (process 20552) exited with code 0.
Press any key to close this window . . .
*/