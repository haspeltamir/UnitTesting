//hw02
/*
����� ����
316271048
���� �����
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{

 int num;
 scanf("%d", &num);
        if (num > 0 && num <= 5000)
        {
            while (num >= 1000)
            {
                printf("M");
                num -= 1000;
            }
            while (num >= 500)
            {
                printf("D");
                num -= 500;
            }
            while (num >= 100)
            {
                printf("C");
                num -= 100;
            }
            while (num >= 50)
            {
                printf("L");
                num -= 50;
            }
            while (num >= 10)
            {
                printf("X");
                num -= 10;
            }
            while (num >= 5)
            {
                printf("V");
                num -= 5;
            }
            while (num > 0)
            {
                printf("I");
                num--;
            }
        }
        else
            printf("\nwrong number");
    }
/*pelet/output
4878
MMMMDCCCLXXVIII
C:\Morad\Keneret\YEAR 1 SEM A\Code c\Projects\Project8\x64\Debug\Project8.exe (process 18608) exited with code 0.
Press any key to close this window . . .
*/
	
