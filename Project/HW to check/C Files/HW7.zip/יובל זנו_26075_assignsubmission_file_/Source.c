#include<stdio.h>
/* yovel zano
homework
206878878*/
#define _CRT_SECURE_NO_WARNINGS
void main()
{
	int number;
	int check;
	do {
		printf("pls insert number");
		check = scanf("%d", % number);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check != 1)
		{
			printf("error");
		}
		else if (number < 1 || number>5000)
			printf("error");
	} while (check < 1 || number>5000 || number < 1)
		printf("the number is:");
	while (num >= 1000)
	{
		number -= 1000;
		printf("M");
	}
	while (number >= 500)
	{
		number -= 500;
		printf("D");
	}
	while (number >= 100)
	{
		number -= 100;
		printf("c");
	}
	while (number >= 50)
	{
		number -= 50;
		printf("L");
	}
	while (number >= 10)
	{
		number -= 10;
		printf("x");
	}
	while (number >= 5)
	{
		number -= 5;
		printf("v");
	}
	while (numer >= 1)
	{
		number -= 1;
		printf("I");
	}
}
/*
insert number :1078
The number is:MLXXVIII*/