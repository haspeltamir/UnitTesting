/*
Fares Elias
324932474
Source.c
HW2.2
*/



#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <ctype.h>

void main() {
	int vrbl;
	printf("Please enter a number\n");
	scanf("%d", &vrbl);
	{char c; while ((c = getchar()) != '\n' && c != EOF); }
	//scans vrbl and translate it to asci table for example if u enter 5 it wil translate it to 53 which is 5 in ascii table
	while (!isdigit(vrbl) == 0 || vrbl > 5000)
	{
		printf("ERROR,please enter number lower than 5000 and without characters\n");
		scanf("\n%d", &vrbl);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }

	}

	if (!isdigit(vrbl) || !vrbl > 5000)
	{
		if (vrbl > 1000) {

			while (vrbl > 1000)
			{
				printf("M");
				vrbl = vrbl - 1000;
			}
		}
		if (vrbl >= 500)
		{
			while (vrbl >= 500)
			{
				printf("D");
				vrbl = vrbl - 500;
			}

		}
		if (vrbl >= 100) {
			while (vrbl >= 100)
			{
				printf("C");
				vrbl = vrbl - 100;
			}
		}
		if (vrbl >= 50) {
			while (vrbl >= 50)
			{
				printf("L");
				vrbl = vrbl - 50;
			}
		}

		if (vrbl >= 10) {
			while (vrbl >= 10)
			{
				printf("X");
				vrbl = vrbl - 10;
			}
		}
		if (vrbl >= 5) {
			while (vrbl >= 5)
			{
				printf("V");
				vrbl = vrbl - 5;
			}
		}
		if (vrbl >= 1) {
			while (vrbl >= 1)
			{
				printf("I");
				vrbl = vrbl - 1;
			}
		}


	}
	/* OUTPUT
	Please enter a number
		6500
		ERROR, please enter number lower than 5000 and without characters
		q
		ERROR, please enter number lower than 5000 and without characters

		w
		ERROR, please enter number lower than 5000 and without characters
		w
		ERROR, please enter number lower than 5000 and without characters
		z
		ERROR, please enter number lower than 5000 and without characters
		s
		ERROR, please enter number lower than 5000 and without characters
		4500
		MMMMD
		C : \Users\fares\source\repos\Project12\Release\Project12.exe(process 13512) exited with code 0.
		Press any key to close this window . . .

		*/

}