// question 2
/*
ahmad badran
324830447
����� 2 ���� 2
*/
 
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{
	int i, b, num;
	printf("Enter number 0-5000: ");
	scanf("%d", &num);

	if (num > 0 && num <= 5000)
	{
		b = num;
		if (num >= 1000)
		{
			b = num / 1000;
			for (i = 0; i < b; i++)
			{
				printf("M");
			}
			num = num - (b * 1000);
		}
		if (num > 500 && num <= 1000)
		{
			b = num / 500;
			for (i = 0; i < b; i++)
			{
				printf("D");
			}
			num = num - (b * 500);
		}
		if (num > 100 && num <= 500)
		{
			b = num / 100;
			for (i = 0; i < b; i++)
			{
				printf("C");
			}
			num = num - (b * 100);
		}
		if (num > 50 && num <= 100)
		{
			b = num / 50;
			for (i = 0; i < b; i++)
			{
				printf("L");
			}
			num = num - (b * 50);
		}
		if (num > 10 && num <= 50)
		{
			b = num / 10;
			for (i = 0; i < b; i++)
			{
				printf("X");
			}
			num = num - (b * 10);
		}
		if (num > 5 && num <= 10)
		{
			b = num / 5;
			for (i = 0; i < b; i++)
			{
				printf("V");
			}
			num = num - (b * 5);
		}
		if (num > 1 && num <= 5)
		{
			b = num / 1;
			for (i = 0; i < b; i++)
			{
				printf("I");
			}
			num = num - (b * 1);
		}

	}
	else
	{
		printf("ERROR");
	}
}

/*PELET/OUTPUT
* Enter number 0-5000: 3879
MMMDCCCLXXVIIII
C:\Users\97254\Desktop\ahmmad\Hwww02.c\x64\Debug\Hwww02.c.exe (process 13812) exited with code 0.
Press any key to close this window . . .
*/