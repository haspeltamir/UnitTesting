	/*
NAME: מוראד כעביה \ MORAD KABIYYA

ID; 318485257

NAME:MAYA SAHOURY

ID:213600943

HOMEWORK 7

QUESTION 2 (HW02 WORD FILE)
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<math.h>

void main()
{
	int M, D, C, L,X,V,I,num;
	int M1, D1, C1, L1,X1,V1,I1;
	int test;
	
	printf("please enter a number from 1 to 5000 \n");

	//{char c; while ((c = getchat()) != '\n' && c != EOF); }
	
	scanf("%d",& num);
	

	// {char c; while ((c = getchat()) != '\n' && c != EOF); }



	M = 1000;
	D = 500;
	C = 100;
	L = 50;
	X = 10;
	V = 5;
	I = 1;
	test = num;

	M1=test / M;

	test = (test - M1 * M);

	D1= test / D;
	test = (test - D1 * D);

	C1=test / C;
	test = (test - C1 * C);

	L1=test / L;
	test = (test - L1 * L);

	X1 = test / X;
	test = (test - X1 * X);

	V1 = test / V;
	test = (test - V1 * V);

	I1 = test / I;
	test = (test - I1 * I);


	 
	//   printf("%d  %d  %d %d %d %d %d \n", M1, D1, C1, L1,X1,V1,I1);
	
	if (num < 5000 && num>1)
	{

		if (M1 > 0)
		{
			do
			{
				printf("M");
				M1 = M1 - 1;
			} while (M1 != 0);
		}


		if (D1 > 0)
		{
			do
			{
				printf("D");
				D1 = D1 - 1;
			} while (D1 != 0);
		}


		if (C1 > 0)
		{
			do
			{
				printf("C");
				C1 = C1 - 1;
			} while (C1 != 0);
		}


		if (L1 > 0)
		{
			do
			{
				printf("L");
				L1 = L1 - 1;
			} while (L1 != 0);
		}



		if (X > 0)
		{
			do
			{
				printf("X");
				X1 = X1 - 1;
			} while (X1 != 0);
		}


		if (V > 0)
		{

			do
			{
				printf("V");
				V1 = V1 - 1;
			} while (V1 != 0);
		}



		if (I > 0)
		{
			do
			{
				printf("I");
				I1 = I1 - 1;
			} while (I1 != 0);

		}

	}
	else
	{
		printf("EROORR\n");
	}
	}
	/*
	
Build started...
1>------ Build started: Project: HOMWORK 77, Configuration: Debug x64 ------
1>Source.c
1>HOMWORK 77.vcxproj -> C:\Users\MR.MORNINGSTAR\Desktop\HOMWORK 77\x64\Debug\HOMWORK 77.exe
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========
========== Elapsed 00:02.203 ==========


///////////////////////////////////////////////////////////////////////////////////////////////
	please enter a number from 1 to 5000
4988
MMMMDCCCCLXXXVIII
C:\Users\MR.MORNINGSTAR\Desktop\HOMWORK 77\x64\Debug\HOMWORK 77.exe (process 25660) exited with code 0.
Press any key to close this window . . .

///////////////////////////////////////////////////////////////////////////////////////////
please enter a number from 1 to 5000
6000
EROORR

C:\Users\MR.MORNINGSTAR\Desktop\HOMWORK 77\x64\Debug\HOMWORK 77.exe (process 7432) exited with code 0.
Press any key to close this window . . .
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
please enter a number from 1 to 5000
h
EROORR

C:\Users\MR.MORNINGSTAR\Desktop\HOMWORK 77\x64\Debug\HOMWORK 77.exe (process 6228) exited with code 0.
Press any key to close this window . . .








	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	*/