//HW22.c
/*
����� ��� 7- ������
Shalev Turgeman
211409362
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>	
void main()
{
	int number, thousands, hundreds, tens, units;
	do
	{
		printf("Please enter one number (1-5000): ");
		scanf("%d", &number);
		if (number > 5000 || number < 1)
		{
			printf("Error!\nYour number is out of range.\n");
		}
	} while (number > 5000 || number < 1);
	printf("\nYour number by roman numerals is: ");
	thousands = number / 1000;
	hundreds = number % 1000 / 100;
	tens = number % 1000 % 100 / 10;
	units = number % 1000 % 100 % 10;
	while (thousands >= 1)
	{
		if (thousands >= 1)
		{
			printf("M");
			thousands--;
		}
	}
	while (hundreds >= 1)
	{
		if (hundreds >= 5)
		{
			printf("D");
			hundreds -= 5;
		}
		else if (hundreds >=1)
		{
			printf("C");
			hundreds--;
		}
	}
	while (tens >= 1)
	{
		if (tens >= 5)
		{
			printf("L");
			tens -= 5;
		}
		else if (tens >= 1)
		{
			printf("X");
			tens--;
		}
	}
	while (units >= 1)
	{
		if (units >= 5)
		{
			printf("V");
			units -= 5;
		}
		else if (units >= 1)
		{
			printf("I");
			units--;
		}
	}
}
/*
Please enter one number (1-5000): 1078

Your number by roman numerals is: MLXXVIII
C:\Users\HP\CS C\����� ��� 7- ������\x64\Debug\����� ��� 7- ������.exe (process 13076) exited with code 0.
Press any key to close this window . . .
*/