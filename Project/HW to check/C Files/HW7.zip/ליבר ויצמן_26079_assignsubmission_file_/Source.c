/*
Name: Homework 2 Exercise 2
libar
Vizman
211711205
Homework 2, Exercise 2
(I = 1 , V = 5,  X = 10,  L = 50,  C = 100,  D = 500,  M = 1000)
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main() {

	int num;
	do {
		printf("Please enter a number between 1 - 5000: ");
		scanf("%d", &num);

	} while (num < 1 || num > 5000);

	while (num / 1000 != 0)
	{
		num -= 1000;
		printf("M");
	}
	while (num / 500 != 0)
	{
		num -= 500;
		printf("D");
	}
	while (num / 100 != 0)
	{
		num -= 100;
		printf("C");
	}
	while (num / 50 != 0)
	{
		num -= 50;
		printf("L");
	}
	while (num / 10 != 0)
	{
		num -= 10;
		printf("X");
	}
	while (num / 5 != 0)
	{
		num -= 5;
		printf("V");
	}
	while (num / 1 != 0)
	{
		num -= 1;
		printf("I");
	}
}

/*
Pelet/ Output:
Please enter a number between 1 - 5000: -15
Please enter a number between 1 - 5000: 1078
MLXXVIII
D:\���������\Homework 2 exercise 2\x64\Debug\Homework 2 exercise 2.exe (process 20420) exited with code 0.
Press any key to close this window . . .
*/