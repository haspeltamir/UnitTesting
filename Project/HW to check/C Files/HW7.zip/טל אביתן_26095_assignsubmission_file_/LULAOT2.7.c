/*
Name : HW2.7 LULAOT
Tal Avitan
212891261
Home Work 2.7
Question 2
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void main()
{
    //I = 1 , V = 5,  X = 10,  L = 50,  C = 100,  D = 500,  M = 1000
    int num;
    printf("Enter a number between 1 and 5000: ");
    scanf("%d", &num);
    {char c; while ((c = getchar()) != '\n' && c != EOF); }
  
    if (num < 1 || num > 5000)
    {
        printf("ERROR Choose number 1 to 5000\n");
    }
    else
    {
        while (num)
            if (num / 1000 > 0)
            {
                printf("M");
                num = num - 1000;
            }
            else if (num / 500 > 0)
            {
                printf("D");
                num = num - 500;
            }
            else if (num / 100 && num < 500)
            {
                printf("C");
                num = num - 100;
            }
            else if (num / 50 && num < 100)
            {
                printf("L");
                num = num - 50;
            }
            else if (num / 10 && num < 50)
            {
                printf("X");
                num = num - 10;
            }
            else if (num / 5 && num < 10)
            {
                printf("V");
                num = num - 5;
            }
            else if (num / 1 && num < 5)
            {
                printf("I");
                num = num - 1;
            }

    }
    
}
/*
Enter a number between 1 and 5000: 1078
MLXXVIII
D:\SASON HW\LULAOT\Debug\LULAOT.exe (process 264) exited with code 0.
Press any key to close this window . . .
*/