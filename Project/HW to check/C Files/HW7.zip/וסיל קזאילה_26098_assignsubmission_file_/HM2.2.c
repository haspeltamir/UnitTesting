#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
* Waseel Kazaila
* 322647561
* 
* This program reads a number between 1-5000 from user
* converts and prints the number in ROMI
*/

void main()
{
	int number;
	int check;
	do {
		printf("Enter a number: ");
		check = scanf("%d", &number); // returns the value of scanf function
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check != 1) 
		{
			printf("ERROR! Numbers only\n");
		}
		else if (number < 1 || number>5000)
			printf("Number must be between 1-5000\n");
	} while (check <1 || number <1 || number>5000);
	printf("The given number is ROMI is: ");
	while (number >= 1000) 
	{
		number -= 1000; 
		printf("M");
	}
	while (number >= 500)
	{
		number -= 500;
		printf("D");
	}
	while (number >= 100)
	{
		number -= 100;
		printf("C");
	}
	while (number >= 50)
	{
		number -= 50; 
		printf("L");
	}
	while (number >= 10)
	{
		number -= 10;
		printf("X");
	}
	while (number >= 5)
	{
		number -= 5;
		printf("V");
	}
	while (number >= 1)
	{
		number -= 1;
		printf("I");
	}

}
/*
* Output:
Enter a number: 1078
The given number is ROMI is: MLXXVIII
C:\Users\Wasee\Desktop\����� �����\��� �\����� �\���� ����� �����\HM2.2\x64\Debug\HM2.2.exe (process 19824) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .


*/


