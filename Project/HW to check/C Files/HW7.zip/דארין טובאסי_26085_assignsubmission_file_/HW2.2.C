﻿// hw2q2.c
/*
dareen tobassy
212868947
HW02.2
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
   unsigned int num; int check;
    do {
        printf("Please enter a number from 1 to 5000:\n");
        check = scanf("%u",&num);
        {char c; while ((c = getchar()) != '\n' && c != EOF); }
        if (check < 1)
        {
            printf("Erorr,please enter numbers only.\n");
        }
        else if (num< 1 || num>5000)
        printf("Number is not in range.\n");
    } while (check < 1 || num < 1 || num > 5000);

    while (num != 0)
    {
        if (num >= 1000)    
        {
            putchar('M');
            num -= 1000;
        }
        else if (num >= 500)
        {
            putchar('D');
            num -= 500;
        }
        else if (num >= 100)
        {
            putchar('C');
            num -= 100;
        }
        else if (num >= 50) 
        {
            putchar('L');
            num -= 50;
        }
        else if (num >= 10)
        {
            putchar('X');
            num -= 10;
        }
        else if (num >= 5)
        {
            putchar('V');
            num -= 5;
        }
        else if (num >= 1)
        {
            putchar('I');
            num -= 1;
        }
    }
}
//PELET // OUTPUT // עבור קלט תקין + לא תקין
/*
Please enter a number from 1 to 5000:
80000
Number is not in range.
Please enter a number from 1 to 5000:
h
Erorr,please enter numbers only.
Please enter a number from 1 to 5000:
-90
Number is not in range.
Please enter a number from 1 to 5000:
1078
MLXXVIII
\\Mac\Home\Documents\Project1\x64\Debug\Project1.exe (process 17000) exited with code 0.
Press any key to close this window . . .
*/