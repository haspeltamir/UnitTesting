/*HW2 q2
Adi Dandeker
207734633
������ ������
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	int num, check, remainder;
	do {
		printf("Pls Enter Number:");
		check = scanf("%d", &num);
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		if (check < 1)
		{
			printf("Have to be a number\n");
		}
	} while (check < 1);
	while (num > 0)
	{
		if (num > 5000)
		{
			printf("Number cant be higher than 5000");
			num = 0;
		}
		else if (num >= 1000)
		{
			remainder = num / 1000;
			num = num % 1000;
			while (remainder > 0)
			{
				remainder--;
				printf("M");
			}
		}
		else if (num >= 500)
		{
			remainder = num / 500;
			num = num % 500;
			while (remainder > 0)
			{
				remainder--;
				printf("D");
			}
		}
		else if (num >= 100)
		{
			remainder = num / 100;
			num = num % 100;
			while (remainder > 0)
			{
				remainder--;
				printf("C");
			}
		}
		else if (num >= 50)
		{
			remainder = num / 50;
			num = num % 50;
			while (remainder > 0)
			{
				remainder--;
				printf("L");
			}
		}
		else if (num >= 10)
		{
			remainder = num / 10;
			num = num % 10;
			while (remainder > 0)
			{
				remainder--;
				printf("X");
			}
		}
		else if (num >= 5)
		{
			remainder = num / 5;
			num = num % 5;
			while (remainder > 0)
			{
				remainder--;
				printf("V");
			}
		}
		else
		{
			remainder = num / 1;
			num = num - remainder;
			while (remainder > 0)
			{
				remainder--;
				printf("I");
			}
		}
	}
}

/*OUTPUT:
Pls Enter Number:LK
Have to be a number
Pls Enter Number:55500
Number cant be higher than 5000

Pls Enter Number:4987
MMMMDCCCCLXXXVII
*/