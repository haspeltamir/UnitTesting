// loop
/*
Tair Haham
316560440
HW02 ���� 2
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{
	int num, Input_check, result, i;
	printf("Enter your number: \n");
	Input_check = scanf("%d", &num);


	while (Input_check <= 0 || num <= 0 || num > 5000)
	{
		printf("Error! Enter your number again: \n");
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		Input_check = scanf("%d", &num);
	}

	printf("The Roman numeral is:\n");
	result = num / 1000;
	for (i = 0; i < result; i++)
	{
		printf("M");
	}
	num = num % 1000;

	result = num / 500;
	for (i = 0; i < result; i++)
	{
		printf("D");
	}
	num = num % 500;

	result = num / 100;
	for (i = 0; i < result; i++)
	{
		printf("C");
	}
	num = num % 100;

	result = num / 50;
	for (i = 0; i < result; i++)
	{
		printf("L");
	}
	num = num % 50;

	result = num / 10;
	for (i = 0; i < result; i++)
	{
		printf("X");
	}
	num = num % 10;

	result = num / 5;
	for (i = 0; i < result; i++)
	{
		printf("V");
	}
	num = num % 5;

	result = num;
	for (i = 0; i < result; i++) {
		printf("I");
	}
	printf("\n");

}




/*
Enter your number:
-6
Error! Enter your number again:
0
Error! Enter your number again:
5001
Error! Enter your number again:
1078
The Roman numeral is:
MLXXVIII

C:\Users\HP\Desktop\����\��� � ������� ����\����� �\���� ����� ����� - ��� C ����.� ����\������ ��� 1\HW2\���� 2 �����\x64\Debug\test.exe (process 5540) exited with code 0.
Press any key to close this window . . .


*/