//home work 6
/* 
afnan saleem 
213628829
maria omari
213523616
*/
#define _CRT_SECURE_NO_WARNINGS
#define I 1
#define V 5
#define X 10
#define L 50
#define C 100
#define D 500
#define M 1000
#include <stdio.h>
void main() {
    int a;

    do {
        scanf("%d", &a);
        if (a < 0 || a > 5000)
            printf("please enter number 1 -  5000\n");
    } while (a < 0 || a > 5000);
    {
        while (a >= 1000)
        {
            printf("M");
            a -= M;
        }
        while (a >= 500)
        {
            printf("D");
            a -= D;
        }
        while (a >= 100)
        {
            printf("C");
            a -= C;
        }
        while (a >= 50)
        {
            printf("L");
            a -= L;
        }
        while (a >= 10)
        {
            printf("X");
            a -= X;
        }
        while (a >= 5)
        {
            printf("V");
            a -= V;
        }
        while (a >= 1)
        {
            printf("I");
            a -= I;
        }
    }
}
/*
* 
*/
/*
* 
*/