//IBRAHEEM TAMER
//ID: 314784737
//H.W 2.2

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{

	int num, i, j;
	printf("Please enter a number: ");

	scanf("%d", &num);
	while (num <= 0 || num > 5000)
	{
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		printf("ERROR please enter number between 0 and 5000\n");
		printf("Please enter a number: ");
		scanf("%d", &num);
	}
	while (num >= 0)
	{
		if (num >= 1000)
		{
			for (j = 0; j <= num / 1000; j++)
			{
				printf("M");

				num -= 1000;
			}

		}
		else if (num >= 500)
		{
			for (j = 0; j <= num / 500; j++)
			{
				printf("D");
				num -= 500;
			}

		}
		else if (num >= 100)
		{
			for (j = 0; j <= num / 100; j++)
			{
				printf("C");
				num -= 100;
			}

		}
		else if (num >= 50)
		{
			for (j = 0; j <= num / 50; j++)
			{
				printf("L");
				num -= 50;
			}

		}
		else if (num >= 10)
		{
			for (j = 0; j <= num / 10; j++)
			{
				printf("X");
				num -= 10;
			}

		}
		else if (num >= 5)
		{
			for (j = 0; j < num / 5; j++)
			{
				printf("V");
				num -= 5;
			}

		}
		else if (num >= 1)
		{
			for (j = 0; j <= num; j++)
			{
				printf("I");
				num -= 1;
			}

		}
	}

}

/*
Please enter a number: m
ERROR please enter number between 0 and 5000
Please enter a number: -1
ERROR please enter number between 0 and 5000
Please enter a number: 0
ERROR please enter number between 0 and 5000
Please enter a number: 6000
ERROR please enter number between 0 and 5000
Please enter a number: 1078
MLXXVIII
*/


/*
// another way of solution but without division operations (shorter)
void main()
{
	int num;
	printf("Please enter a number: ");
	char check = scanf("%d", &num);

	if (check > 1 || num < 0 || num > 5000)
	{
		printf("Error");
	}
	else
		while (num > 0)
		{
			if (num >= 1000)
			{
				printf("M");
				num -= 1000;
			}
			else if (num >= 500)
			{
				printf("D");
				num -= 500;
			}
			else if (num >= 100)
			{
				printf("C");
				num -= 100;
			}
			else if (num >= 50)
			{
				printf("L");
				num -= 50;
			}
			else if (num >= 10)
			{
				printf("X");
				num -= 10;
			}
			else if (num >= 5)
			{
				printf("V");
				num -= 5;
			}
			else if (num >= 1)
			{
				printf("I");
				num -= 1;
			}
		}

}
*/