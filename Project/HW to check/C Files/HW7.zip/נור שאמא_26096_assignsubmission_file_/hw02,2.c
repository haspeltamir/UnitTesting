/*hw02,2.c
noor shama
325523751
for
*/

#include<stdio.h>

void main()
{
	int num, i;
	printf("enter number please ");
	scanf_s("%d", &num);
	while (num < 0 || num>5000)
	{
		printf("enter number between 0 and 5000 ");
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		scanf_s("%d", &num);
	}
	for (i = 0;i < num / 1000;i++)
	{
		printf("M");
	}
	num = num % 1000;
	for (i = 0;i < num / 500;i++)
	{
		printf("D");
	}
	num = num % 500;
	for (i = 0;i < num / 100;i++)
	{
		printf("C");
	}
	num = num % 100;
	for (i = 0;i < num / 50;i++)
	{
		printf("L");
	}
	num = num % 50;
	for (i = 0;i < num / 10;i++)
	{
		printf("X");
	}
	num = num % 10;
	for (i = 0;i < num / 5;i++)
	{
		printf("V");
	}
	num = num % 5;
	for (i = 0;i < num / 1;i++)
	{
		printf("I");
	}
}
/*output
enter number please 4987
MMMMDCCCCLXXXVII
C:\Users\Tsofen4\Desktop\kinneret\sason\hw02.2\Debug\hw02.2.exe (process 11280) exited with code 0.
Press any key to close this window . . .
*/