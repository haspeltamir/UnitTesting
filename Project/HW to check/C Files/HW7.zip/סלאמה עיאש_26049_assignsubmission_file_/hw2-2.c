﻿// hw2-2.c

/*
סלאמה עיאש
315869909
homework question 7:
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
	int number, save = 0, i;
	scanf("%d", &number);
	if (number <= 5000 && number > 0)
	{
		if (number >= 1000)
		{
			save = number / 1000;
			for (i = 0; i < save; i++)
			{
				printf("M");
			}
		}
		if (number >= 100)
		{
			save = number / 100;
			save = save % 10;
			if (save < 5)
			{
				for (i = 0; i < save; i++)
				{
					printf("C");
				}
			}
			if (save >= 5)
			{
				printf("D");
				for (i = 0; i < save - 5; i++)
				{
					printf("C");
				}
			}
		}
		if (number >= 10)
		{
			save = number / 10;
			save = save % 10;
			if (save < 5)
			{
				for (i = 0; i < save; i++)
				{
					printf("X");
				}
			}
			if (save >= 5)
			{
				printf("L");
				for (i = 0; i < save - 5; i++)
				{
					printf("X");
				}
			}
		}
		if (number > 0)
		{
			save = number % 10;
			if (save < 5)
			{
				for (i = 0; i < save; i++)
				{
					printf("I");
				}
			}
			if (save >= 5)
			{
				printf("V");
				for (i = 0; i < save - 5; i++)
				{
					printf("I");
				}
			}
		}
	}
	else
	{
		printf("number is more than 5000 or less than 1");
	}
}
/*pelet/output
1078
MLXXVIII
C:\Users\ASUS\source\repos\hw2-2\x64\Debug\hw2-2.exe (process 23604) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/