// hw2-2.c

/*
Saleem Yousef	/ Adam Fraira
213523418		/ 212972897

hw02.docs , Question 2
*/

#define _CRT_SECURE_NO_WARNINGS
#define I 1
#define V 5
#define X 10
#define L 50
#define C 100
#define D 500
#define M 1000


#include <stdio.h>

void main() {

    int a, i, num = 0;
    printf("Enter a number to convert it to romanian language: ");
    scanf("%d", &a);
    num = a;
    if (a < 0 || a > 5000) {
        printf("Error! Input a number between 0 to 5000!");
    }
    else {
        if (a >= M)
        {
            for (i = 0; i < num; i++)
            {
                num = a / M;
                printf("M");
            } a = a % M;
        }if (a >= D)
        {
            for (i = 0; i < num; i++)
            {
                num = a / D;
                printf("D");
            } a = a % D;
        }if(a >= C)
        {
            for (i = 0; i < num; i++)
            {
                num = a / C;
                printf("C");
            }
            a = a % C;
        }if (a >= L)
        {
            for (i = 0; i < num; i++)
            {
                num = a / L;
                printf("L");
            }
            a = a % L;
        } if (a >= X)
        {
            for (i = 0; i < num; i++)
            {
                num = a / X;
                printf("X");
            }
            a = a % X;
        } if (a >= V)
        {
            for (i = 0; i < num; i++)
            {
                num = a / V;
                printf("V");
            }
            a = a % V;
        } if ( a >= I)
        {
            for (i = 0; i < num; i++)
            {
                num = a / I;
                printf("I");
            }
        }
    }
    printf("\n");
}

//Pelet/Output

/*
Enter a number to convert it to romanian language: 4777
MMMMDCCLXXVII

C:\Users\WIN10\Documents\saleem\saleem\saleem2\x64\Debug\saleem2.exe (process 12748) exited with code 0.
Press any key to close this window . . .
*/
