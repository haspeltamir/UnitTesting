//HW0.2.C
/*
AMIT AMSALEM	
322795923
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int number;
	printf("plese enter a number between 1 and 5000\n");
	scanf("%d", &number);
	while (number < 1 || number >5000)
	{
		printf("eror , enter correct umber \n");
		{char c; while ((c = getchar()) != '\n' && c != EOF); }
		scanf("%d", &number);
	}
	while(number != 0)
	{
		if (number >= 1000)
		{
			number = number - 1000;
			printf("M");
		}
		else
		{
			if (number >= 500)
			{
				number = number - 500;
				printf("D");
			}
			else
			{
				if (number >= 100)
				{
					number = number - 100;
					printf("C");
				}
				else
				{
					if (number >= 50)
					{
						number = number - 50;
						printf("L");

					}
					else
					{
						if (number >= 10)
						{
							number = number - 10;
							printf("X");
						}
						else
						{
							if (number >= 5)
							{
								number = number - 5;
								printf("V");
							}
							else
							{
								if (number >= 1)
								{
									number = number - 1;
									printf("|");
								}
							}

						}
					}
				}
			}
		}
	}

	
}
/*
plese enter a number between 1 and 5000
3658
MMMDCLV|||
D:\amitamsalem.c\x64\Debug\amitamsalem.c.exe (process 14092) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/