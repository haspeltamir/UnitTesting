//hw02
/*
����� ����
316271048
homework question 1
*/
#include<stdio.h>
void main()
{	
	int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
		{
		printf("%d ", i);
		}
	}
	for (i = 1; i <= 100; i++) //���� �
	{
		{
		if (i % 3 == 0 && i % 7 == 0)
		printf("\n%d", i);
		}
	}
}
/*pelet/output
1 2 3 4 5 6 8 9 10
21
42
63
84
C:\Morad\Keneret\YEAR 1 SEM A\Code c\Projects\Project7\x64\Debug\Project7.exe (process 6104) exited with code 0.
Press any key to close this window . . .

*/