/*
Jawad Elias
311379689
HW02 Q01
Room 6201
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main() {
	int i;
	printf("all the numbers from 1 to 10 ecluding 7 :\n");
	for (i = 1; i <= 10; i++) {
		if (i != 7) {
			printf("%-5d", i);
		}
		
	}
	printf("\n the numbers from 1 to 100 that deivide by both 3 and 7 :\n");
	for (i = 1; i <= 100; i++) {
		if ((i % 3 == 0)&&(i%7==0))  {
			printf("%-5d", i);
		}
	}
}
/* Pellet/Output
all the numbers from 1 to 10 ecluding 7 :
1    2    3    4    5    6    8    9    10
 the numbers from 1 to 100 that deivide by both 3 and 7 :
21   42   63   84
D:\JJE6194\Software Engineering\Projects\homework 6\x64\Debug\homework 6.exe (process 14368) exited with code 0.
Press any key to close this window . . .
*/