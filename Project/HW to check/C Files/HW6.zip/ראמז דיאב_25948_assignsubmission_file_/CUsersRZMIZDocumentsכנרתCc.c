
/*
ramiz diab
211404249
question 2_1
positive.c
*/
#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS


void main() {
	printf("hw02 - question 1 / 1: \n");
	for (int i = 1; i <= 10; i++)
	{
		if (i == 7) i++;
		printf("%d\t", i);
	}
	printf("\n----------------\n");
	printf("Question 1 / 2: \n");
	for (int i = 3; i <= 100; i++)
	{
		if (i % 3 == 0 || i % 7 == 0)
		{
			printf("%d\t ", i);
		}
	}
}
/*hw02 - question 1 / 1:
1       2       3       4       5       6       8       9       10
----------------
Question 1 / 2:
3        6       7       9       12      14      15      18      21      24      27      28      30      33      35     36       39      42      45      48      49      51      54      56      57      60      63      66      69      70     72       75      77      78      81      84      87      90      91      93      96      98      99*/