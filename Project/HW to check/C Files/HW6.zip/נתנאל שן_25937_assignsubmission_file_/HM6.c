//HM6.c

/*  
    netanel shen
    207473745
    homework  6  exercise 1

*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {

    for (int i = 1; i <= 10; i++)
    {
        if (i == 7)
        {
            continue;
        }
        printf("%d\n", i);
    }

    printf("\n\n");

    for (int i = 1; i <= 100; i++)
    {
        if (i % 3 == 0 && i % 7 == 0)
        {
            printf("%d\n", i);
        }
    }

    return 0;
}


/*
    OUTPUT:
    1
    2
    3
    4
    5
    6
    8
    9
    10



    21
    42
    63
    84

*/