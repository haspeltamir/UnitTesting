// hw2q1.c
/*
dareen tobassy
212868947
HW02.1
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
			printf("%d  ", i);
	}
	printf("\n");
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
			printf("%d  ", i);
	}
}
/* PELET//OUTPUT 
1  2  3  4  5  6  8  9  10
21  42  63  84
\\Mac\Home\Documents\Project1\x64\Debug\Project1.exe (process 3328) exited with code 0.
Press any key to close this window . . .
*/