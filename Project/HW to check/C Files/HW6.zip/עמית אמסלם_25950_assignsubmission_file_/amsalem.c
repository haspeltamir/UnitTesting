/*
amit amsalem 
322795923
HW2.6
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int i;
	int y;
	for (i = 1; i <= 10; i++)
		
	{
		if (i != 7)
		{
			printf("%-5d", i);
		}

	}
	printf("\n");
	for (y = 1; y <= 100; y++)
	{
		if (y % 3 == 0 && y % 7 == 0)
		{
			printf("%-5d", y);
		}
	}
}

/* output
1    2    3    4    5    6    8    9    10
21   42   63   84
D:\amsalem.c\x64\Debug\amsalem.c.exe (process 6712) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/