//322732470
//reemabbas
#include <stdio.h>
//���� �
void main()
{
	int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
		{
			printf("%d \n", i);
		}
	}
}
//���
/*
1
2
3
4
5
6
8
9
10

C:\Users\Reema\source\repos\hw.21\x64\Debug\hw.21.exe (process 1868) exited with code 0.
Press any key to close this window . . .
*/


// ���� �

#include <stdio.h>

void main()
{
	int i;
	for (i = 1; i <= 100; i++)
	{
		if (i % 21 == 0)
		{
			printf("%d \n", i);
		}
	}
}
/*
21
42
63
84

C:\Users\Reema\source\repos\hw.21\x64\Debug\hw.21.exe (process 1392) exited with code 0.
Press any key to close this window . . .
*/