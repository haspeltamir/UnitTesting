#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

/*
* Waseel Kazaila
*
* 322647561
*
*This program prints the numbers from 1 to 10 except 7
* This program prints all the numbers from 1 to 100 that can be divided by 3 and by 7.
*/

void main()
{
	for (int i=1; i <= 10; i++) // FOR LOOP
	{
		if (i != 7) 
			printf("%d ",i);
	}
	printf("\n");
	for (int i = 1; i <= 100; i++) // FOR LOOP
	{
		if (i % 7 == 0 && i % 3 == 0)
			printf("%d ", i);
	}
}
/*
* OUTPUT:
 1 2 3 4 5 6 8 9 10
21 42 63 84
C:\Users\Wasee\Desktop\����� �����\��� �\����� �\���� ����� �����\Projects\x64\Debug\Projects.exe (process 612) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .

*/