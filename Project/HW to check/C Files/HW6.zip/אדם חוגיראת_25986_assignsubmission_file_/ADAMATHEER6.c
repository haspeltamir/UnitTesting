﻿/*
ADAM HUJERAT  &  ATHEER ASAAD
211636972         326448255
CLASS 6201 / HW02
HOMEWORK 6 QUESTION 1
*/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main()
{
	int i;
	for (i = 1; i < 11; i++)
	{
		if (i == 7)
			i++;
		printf("%d\n", i);

	}
	printf("\n*******\n");
	for (i = 1; i < 101; i++)
	{
		if (i % 3 == 0)
			printf("%d\n", i);
		if (i % 7 == 0)
			printf("%d\n", i);

	}
}
/* //PELET/OUTPUT
1
2
3
4
5
6
8
9
10

*******
3
6
7
9
12
14
15
18
21
21
24
27
28
30
33
35
36
39
42
42
45
48
49
51
54
56
57
60
63
63
66
69
70
72
75
77
78
81
84
84
87
90
91
93
96
98
99

C:\Users\ADAM\OneDrive\Documents\Projects\HOMEWORKS\AADAAMM6\Debug\AADAAMM6.exe (process 22564) exited with code 0.
Press any key to close this window . . .
*/