/*
HW2.1
shahar shabtay 
211667852
������
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int num, a;
	
	for (num = 1; num <=10; num++)
	{
		if (num == 7)
		{
			num =num + 1;
		}
     printf("\n%d", num);
	}
	{
		for (a = 1; a <= 100; a++)
		{
			if (a % 7 == 0 && a % 3 == 0)
			{
				printf("\n%d", a);
			}
		}


	}

}
/*
1
2
3
4
5
6
8
9
10
21
42
63
84
C:\Users\User\Desktop\������\HW2.1\x64\Debug\HW2.1.exe (process 21144) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/