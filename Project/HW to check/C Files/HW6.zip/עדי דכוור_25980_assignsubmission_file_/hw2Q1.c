/*adi dakwar
323888420
basel amara
323031484*/
#include <stdio.h>

void main()
{
	int i = 0;
	for (i = 1; i < 11; i++) {
		if (i == 7)
		{
			continue;
		}
		else
		printf("%-3d", i);
	}
	printf("\nthe second part of the question is:\n");
	for (i = 1; i < 101; i++)
	{
		if (i % 7 == 0 && i % 3 == 0)
		{
			printf("%-3d", i);
		}
	}

}
/*1  2  3  4  5  6  8  9  10
the second part of the question is:
21 42 63 84
C:\Users\adid1\source\repos\Project1\x64\Debug\Project1.exe (process 10380) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/