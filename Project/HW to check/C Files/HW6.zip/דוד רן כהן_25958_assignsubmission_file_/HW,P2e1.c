//h.w2.1
/*
David Ran Cohen
322777921
1.print 1234568910 
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	int i;
	int j;
	//1.print 1234568910
	for (i = 1; i < 11; i++ )
	{
		if (i == 7)
		{
			i++;
	    }
		printf("%d", i);
	}
	printf("\n");
	//2.print (1...100)/7&3
	for (j = 1; j < 101; j++)
	{
		if (j % 3 == 0 && j % 7 == 0)
		{
			printf("%d ", j);
		}
	}
}
/*
1234568910
21 42 63 84
C:\Users\��� ��\Desktop\�� 2 ����� 1\2h.w1\x64\Debug\2h.w1.exe (process 55160) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/