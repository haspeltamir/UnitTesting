#include<stdio.h>
/* yovel zano
homework
206878878*/
#define _CRT_SECURE_NO_WARNINGS
void main()
{
	for (int i=1; i<=10; i++)
	{
		if (i != 7)
			printf("%d", i);
	}
	printf("\n");
	for (int i = 1; i <= 100; i++)
	{
		if (i % 7 == 0 && i % 3 == 0)
			printf("%d \n", i);
	}
}
/* out put
1 2 3 4 5 6 7 8 9 
10
21 42 63 84*/