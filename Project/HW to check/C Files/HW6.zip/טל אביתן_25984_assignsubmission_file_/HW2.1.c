/*
Tal Avitan
212891261
Home Work 2.1
question 6
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main()
{
	int i;
	for (i = 1; i <= 10; i++)
	{
		if(i != 7)
		printf("%-5d", i);
	}
	int i;
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
		{
			printf("%-5d", i);
		}
	}

}
//1    2    3    4    5    6    8    9    10
//D:\SASON HW\HW2.6\x64\Debug\HW2.6.exe(process 10100) exited with code 0.
//Press any key to close this window . . .

//21   42   63   84
//D:\SASON HW\HW2.6\x64\Debug\HW2.6.exe(process 3312) exited with code 0.
//Press any key to close this window . . .