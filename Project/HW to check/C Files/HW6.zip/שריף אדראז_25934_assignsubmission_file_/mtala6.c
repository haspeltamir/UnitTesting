//HW02
/*
Sharif Adraz
325393486
matala 6
*/
#include<stdio.h>
void main()
{
	int i,j;

	printf("there are all the numbs between 1  till 10 exept 7 \n");
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
		{
			printf(" %d ", i);
		}
	}

	printf("\n \n \n");
	printf("there are all the numbs between 1  till 100 that fully devided by 7 and 3 \n");
	for (j = 1; j <= 100; j++)
	{
		if (j%3 == 0 && j%7 == 0)
		{
			printf(" %d ",j);
		}
}

}
/*
there are all the numbs between 1  till 10 exept 7
 1  2  3  4  5  6  8  9  10


there are all the numbs between 1  till 100 that fully devided by 7 and 3
 21  42  63  84
C:\Users\shref\OneDrive\Documents\Project2\x64\Debug\Project2.exe (process 21488) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window*/