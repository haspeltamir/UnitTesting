
/*
NAME: מוראד כעביה \ MORAD KABIYYA

ID; 318485257

HOMEWORK 6

QUESTION 1 (HW02 WORD FILE)

שאלה 1 חלק א 

*/



#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

void main()

{
	 int num;

	printf("here are the number 1 to 10 exluding 7\n");

	for (num = 1; num <= 10; num = num + 1)
	{

		if (num != 7)
		{
			printf("%d ", num);

		}
	}
}
	/*
	///////////////////////////////////////////////////////////
	1 2 3 4 5 6 8 9 10
		C:\Users\MR.MORNINGSTAR\Desktop\HOMEWORK6(Q1)\x64\Debug\HOMEWORK6(Q1).exe(process 9880) exited with code 0.
		Press any key to close this window . . .
/////////////////////////////////////////////////////////////////////////

Build started...
1 > ------Build started : Project: HOMEWORK6(Q1), Configuration : Debug x64------
1 > Source.c
1 > HOMEWORK6(Q1).vcxproj->C:\Users\MR.MORNINGSTAR\Desktop\HOMEWORK6(Q1)\x64\Debug\HOMEWORK6(Q1).exe
========== Build: 1 succeeded, 0 failed, 0 up - to - date, 0 skipped ==========
========== Elapsed 00 : 00.414 ==========
////////////////////////////////////*/









/*
NAME: מוראד כעביה \ MORAD KABIYYA

ID; 318485257

HOMEWORK 6

QUESTION 1 (HW02 WORD FILE)

שאלה 1 חלק ב

למטה

*/
//////////////////////////////////////////////////////////////////////////////
	/*
	{
		double seven = 7, three = 3;
		double x;
		double n3, n7;

		for (x = 1; x <= 100; x++)
		{
			                                               ///////// y = fmod((x / three) * 10, 10); ///////  ((fmod((x / three) * 10, 10)) > 0) < test > 
			n3 = (fmod((x / three) * 10, 10));
			n7 = (fmod((x / seven) * 10, 10));

			if ((n3 == 0 || (n7 == 0)))
			{
				printf("%0.2lf ", x);
			}
		}
	}

	*/

//////////////////////////////////////////////////////////////////////////////////////
/*
Build started...
1 > ------Build started : Project: HOMEWORK6(Q1), Configuration : Debug x64------
1 > Source.c
1 > HOMEWORK6(Q1).vcxproj->C:\Users\MR.MORNINGSTAR\Desktop\HOMEWORK6(Q1)\x64\Debug\HOMEWORK6(Q1).exe
========== Build: 1 succeeded, 0 failed, 0 up - to - date, 0 skipped ==========
========== Elapsed 00 : 00.482 ==========

////////////////////////////////////////////////////////////////////////////////////////////////

3.00 6.00 7.00 9.00 12.00 14.00 15.00 18.00 21.00 24.00 27.00 28.00 30.00 33.00 35.00 36.00 39.00 42.00 45.00 48.00 49.00 51.00 54.00 56.00 57.00 60.00 63.00 66.00 69.00 70.00 72.00 75.00 77.00 78.00 81.00 84.00 87.00 90.00 91.00 93.00 96.00 98.00 99.00
C:\Users\MR.MORNINGSTAR\Desktop\HOMEWORK6(Q1)\x64\Debug\HOMEWORK6(Q1).exe (process 5704) exited with code 0.
Press any key to close this window . . .

*/