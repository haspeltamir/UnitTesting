 /*HW1 Q1
 OREN KATZ
 302839899
 
 
 
 */

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{

	int i;

	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
		{
			printf(" %d ", i);
		}

	}

}

/*
 1  2  3  4  5  6  8  9  10
D:\Users\dell\Desktop\��� C\����� 2.1\x64\Debug\����� 2.1.exe (process 17860) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .

*/

/*

/*HW2 Q1
OREN KATZ
302839899



*/

//#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//void main1()
//{
//
//	int i;
//
//	for (i = 1; i <= 100; i++)
//	{
//		if (i % 7 == 0 && i % 3 == 0)
//		{
//			printf(" %d ", i);
//		}
//
//	}
//
//}
///*
// 21  42  63  84
//D:\Users\dell\Desktop\��� C\����� 2.1\x64\Debug\����� 2.1.exe (process 20748) exited with code 0.
//To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
//Press any key to close this window . . .
//
//*/
