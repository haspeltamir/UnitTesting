﻿/*
Fares Elias
324932474
Source.c
HOMEWORK2.1
*/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void main() {
	int i;
	printf("numbers from 1 to 10 without 7\n");
	for (i = 1; i <= 10; i++) {
		if (i != 7) {
			printf("%-5d", i);
		}

	}
	printf("\n numbers that are divded by both 3 and 7\n");
	for (i = 1; i <= 100; i++) {
		if ((i % 3 == 0) && (i % 7 == 0)) {
			printf("%-5d", i);
		}
	}

	/*OUTPUTTT
	numbers from 1 to 10 without 7
		1    2    3    4    5    6    8    9    10
		numbers that are divded by both 3 and 7
		21   42   63   84
		C:\Users\fares\source\repos\Project11\Debug\Project11.exe(process 13940) exited with code 0.
		Press any key to close this window . . .
		*/



}