/*
HW6.c
Name : Najdat Shkeer
ID : 322925470
*/
#define CRT_SECURE_NO_WARNINGS
#include<stdio.h>

int main() {
	int num;

	printf("Section A :\n");
	for (num = 1; num <= 6; num++)
	{
		printf("%d\t", num);
	}
	for (num = 8; num <= 10; num++)
	{
		printf("%d\t", num);
	}
	printf("\nSection B :\n");
	for (num = 1; num <= 100; num++)
	{
		if (num % 3 == 0 && num % 7 == 0)
		{
			printf("%d\t", num);
		}
	}

}
/*
Output :
Section A :
1       2       3       4       5       6       8       9       10
Section B :
21      42      63      84
C:\Users\Win 10\OneDrive\Desktop\c++\Project2\x64\Debug\Project2.exe (process 26080) exited with code 0.
Press any key to close this window . . .
*/