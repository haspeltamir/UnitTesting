/*HW 2 Q 1
Adi dandeker
207734633
������
*/

#define _CRT_SECURE_NO_WAENINGS
#include<stdio.h>

void main()
{
	/*int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
		{
			printf("\t%d", i);
		}
	}*/
	int i;
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
		{
			printf("\t%d", i);
		}
	}
}
/*
OUTPOT1
		1       2       3       4       5       6       8       9       10


OUTPOT 2:
		21      42      63      84
*/