/*
Homework6
Qustion1
Name: Aseel Shaheen
ID: 214228009
HW02
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

void main() {
	int i;

	for (i = 1; i <= 10; i++) {
		if (i != 7)
			printf("%d  ", i);
	}
	printf("\n");
	for (i = 1; i <= 100; i++) {
		if (i % 7 == 0 && i % 3 == 0)
			printf("%d  ", i);
	}
}
/*
1  2  3  4  5  6  8  9  10
21  42  63  84
C:\Users\ReadShaheen\OneDrive\????? ??????\C++\HomeworkFR2\Homework2\Homework2\FR123\Project1\Q5\Q3\Q7\Project1\x64\Debug\Project1.exe (process 26904) exited with code 0.
Press any key to close this window . . .
*/