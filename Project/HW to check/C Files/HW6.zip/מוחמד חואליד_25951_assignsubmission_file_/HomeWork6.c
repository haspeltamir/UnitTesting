//HomeWork6.c
/*
Mohammad Khwaled 
207930892
Home work 6
qusn 6
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define N 10
#define A 100
void main()
{

	int i;

	printf("you have numbers from 1 - 10 without 7: ");
	printf("\n\n");
	for (i = 1; i <= N; i++)
	{
		if (i != 7)
		{
			printf("*|%d|*   ", i);
		}
	}
	printf("\n");
	int x = 1, y = 1;

	printf("\n");
	printf("numbers that divisible to 3 and 7: ");
	printf("\n\n");

	for (i = 1; i <= A; i++)
	{
		if (i == 3 *7* x)
		{
			printf("*|%d|*   ", i);
			x++;
		}
	}
	printf("\n");

}
/*pelet
you have numbers from 1 - 10 without 7:

*|1|*   *|2|*   *|3|*   *|4|*   *|5|*   *|6|*   *|8|*   *|9|*   *|10|*

numbers that divisible to 3 and 7:

*|21|*   *|42|*   *|63|*   *|84|*

C:\Users\WIN10\source\repos\HomeWork6\x64\Debug\HomeWork6.exe (process 14896) exited with code 0.
Press any key to close this window . . .


*/