// IBRAHEEM TAMER
// ID: 314784737
// H.W 2.1

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>


//question 1 h.w 2 alef
void main()
{
	int count1 = 1;
	int count2 = 1;

	// alef
	printf("Numbers from 1 -10 without 7: \n");
	while (count1 <= 10)
	{
		if (count1 != 7)
		{
			printf("%d \n", count1);
		}
		count1++;
	}

	// bet
	printf("\nNumbers divisible by three and seven without a remainder: \n");
	while (count2 <= 100)
	{
		if (count2 % 7 == 0 && count2 % 3 == 0)
		{
			printf("%d \n", count2);
		}
		count2++;
	}
	
}

/*
Numbers from 1 -10 without 7:
1
2
3
4
5
6
8
9
10

Numbers divisible by three and seven without a remainder:
21
42
63
84

C:\Users\tamer\source\repos\H.W 2.1\x64\Debug\H.W 2.1.exe (process 15308) exited with code 0.
Press any key to close this window . . .
*/
