// hw2-1.c

/*
Saleem Yousef	/ Adam Fraira
213523418		/ 212972897

hw02.docs , Question 1
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


void main() {
	int i;
	for ( i = 1; i <= 10; i++)
	{
		if (i == 7)		i++;
		printf("%-5d", i);
	}
	putchar('\n');

	for ( i = 1; i <= 100; i++)
	{
		if (i % 7 == 0 || i % 3 == 0)
		{
			printf("%-5d", i);
		}
	}
}

// Pelet/Output

/*

1    2    3    4    5    6    8    9    10
3    6    7    9    12   14   15   18   21   24   27   28   30   33   35   36   39   42   45   48   49   51   54   56
57   60   63   66   69   70   72   75   77   78   81   84   87   90   91   93   96   98   99
E:\C Language\C Class Project\saleem\class number 1\x64\Debug\class number 1.exe (process 14020) exited with code 0.
Press any key to close this window . . .

*/