/*
karam nashef
213444789
hw1.2
*/


#define _CRT_SECURE_NO_WARININGS
#include <stdio.h>

void main()
{
	int i,x;
	//�
	printf("A.1\n");

	for (i = 1; i <= 10;i++)
	{
		if (i != 7)
			
			printf("%d ", i);
	}
	printf("\n");

	//�
	printf("A.2\n");
	for (x = 1; x <= 100;x++)
	{
		if (x % 3 == 0 && x % 7 == 0)
			
			printf("%d ", x);
	}
}
/*
OUTPUT-PELET
A.1
1 2 3 4 5 6 8 9 10
A.2
21 42 63 84
C:\Users\WINDOWS 10 PRO\Desktop\karam C\Class Work\hw02\x64\Debug\hw02.exe (process 17240) exited with code 0.
Press any key to close this window . . .

*/