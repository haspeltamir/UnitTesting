// printing.c --> hw02\ first question
/* Walaa Mruwat
* 325224194
* Home Work 6 ( if , printf , for)
*/
 
#include<stdio.h>
void main6()
{
	int i;
	printf("Printing numbers between 0 and 10 without 7 :\n");
	for (i = 1; i < 11 ; i++)
	{
		if (i != 7)
			printf("%d \t", i);
	}
	printf("\nPrinting all the numbers between 1 and 100 that are divisible by 3 and 7. :\n");
	for (i = 1; i < 101; i++)
	{
		if ( ((i % 7)==0) && ((i % 3) == 0) )
			printf("%d \t", i);
	}

}
/*
Printing numbers between 0 and 10 without 7 :
1       2       3       4       5       6       8       9       10
Printing all the numbers between 1 and 100 that are divisible by 3 and 7. :
21      42      63      84
*/