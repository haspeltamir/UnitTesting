/*hw02.c
noor shama
325523751
for
*/

#include<stdio.h>

void main()
{
	int i = 1;
	printf("question A\n");
	for (i ; i <= 10 ; i ++)
	{
		if (i != 7)
		{
			printf("%d ", i);
		}
	}
	printf("\nquestion B\n");
	for (i=1 ; i <= 100 ; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
		{
			printf("%d ", i);
		}
	}
}
/*output
question A
1 2 3 4 5 6 8 9 10
question B
21 42 63 84
C:\Users\Tsofen4\Desktop\kinneret\sason\hw02\Debug\hw02.exe (process 12984) exited with code 0.
Press any key to close this window . . .
*/