﻿//                גולאן דעבוס   ת"ז מספר:207112137


#include <stdio.h>

void main() {
	for (int i = 1; i < 11; i++)
	{
		if (i != 7)
		{
			printf("%d\t", i);
		}
	}
	printf("\n\n");

	for (int j = 1; j < 101; j++) {
		if (j % 3 == 0 && j % 7 == 0) {
			printf("%d\t", j);
		}
	}
}
//1       2       3       4       5       6       8       9       10
//
//21      42      63      84
//C:\Users\Admin\source\repos\Practice.1\x64\Debug\Practice.1.exe(process 14540) exited with code 0.
//Press any key to close this window . . .
