/*   HW02 ���� ���� 1 .c
 
	��� ��� ����
	211477468

	���� ������
	325159804
*/

#include<stdio.h>

 void main(void)
{
	int i ;
	for (i = 0; i < 10; i++)
	{
		if (i == 6)
		{
			i + 1;
		}
		else
		{
			printf("%d\t", i+1);
		}

	} 
	printf("\n");
	for (int j = 1; j <= 100; j++)
	{
		if (j % 3 == 0 && j % 7 == 0)
		{
			printf("%d\t", j);
		}
	}
	
}
 /*output
    1       2       3       4       5       6       8       9       10
    21      42      63      84
C:\Users\a\source\repos\Project13\Debug\Project13.exe (process 13336) exited with code 0.
Press any key to close this window . . .

 */