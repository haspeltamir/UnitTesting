﻿/*
* homework-6.c
* mayasahoury 213600943
* for if 
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main() 
{
   int num1,num2 ;
 

  for (int num1 = 1;num1 <= 10;num1++) {
	  if (num1 == 7)num1++;
	  printf("%d\t", num1);
 }

  for (int num2 = 3;num2 < 101;num2 ++) {
	  if ((num2 % 3 == 0) || (num2 % 7 == 0)) {
		  printf("%d\t", num2);
 }
  }


}
/*
* 1       2       3       4       5       6       8       9       10    
3       6       7       9       12      14     15       18      21      24      27      28      30      33      35      36      39      42      45      48      49     51       54      56      57      60      63      66      69      70      72      75      77      78      81      84     87       90      91      93      96      98      99
*/
