//����� ��� 6//

/*
Chen Keynan Oren
322392622
HW02 Q1
������
*/

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>


void main()
{
	int i;
	printf("This is Aleph:\n"); //���� �
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
			printf("%d ", i);
	}
	printf("\nThis is Bet:\n"); //���� �
	for (i = 1; i <= 100; i++)
	{
		if ((i % 3 == 0) && (i % 7 == 0))
			printf("%d ", i);
	}
}

/*
Output:

This is Aleph:
1 2 3 4 5 6 8 9 10
This is Bet:
21 42 63 84
D:\Documents\Visual Studio 2022\repos\Project1\x64\Debug\Project1.exe (process 14008) exited with code 0.
Press any key to close this window . . .
*/