//HW.2.1.c

/*
Ariel Cohen :��
��: 212111405
Homework 6, question 1
*/

#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS

void main()
{
    for (int i = 1; i <= 10; i++)
        if (i != 7)
            printf("%d ", i);
    printf("\n");
    for (int j = 1; j <= 100; j++)
        if (j % 7 == 0 && j % 3 ==0)
            printf("%d ", j);
}
/*
1 2 3 4 5 6 8 9 10
21 42 63 84
E:\HW.2.1\x64\Debug\HW.2.1.exe (process 13272) exited with code 0.
Press any key to close this window . . .
*/