﻿/* חוסיין אמארה 213020670
211732961 מגד אגבאריה
מטלה 6
שאלה 1 מ hwo.2 
*/


#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
void main()
{
	int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7) printf("%d	", i);
	}
	printf("\n\nThe numbers that dividing by 3 and 7 is: ");
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
		{
			printf("%d ", i);
		}
	}

}
/*Pelet (output)
1       2       3       4       5       6       8       9       10
The numbers that dividing by 3 and 7 is:21 42 63 84
C:\Users\house\OneDrive\Desktop\SEM.2022\homework 6\x64\Debug\homework 6.exe (process 23716) exited with code 0.
Press any key to close this window . . .
*/