//hw6.c
/*
Hala Assadi
324830967
Taqwa Marwat
212804017
hw6.1
loops-for
*/
#include <stdio.h>
void main()
{
	//1
	int i;
	printf("The numbers from 1 to 10 without 7:\n");
	for (i = 1;i <11;i++)
	{
		if (i != 7)
		{
			printf(" % d",i);
		}
	}

	printf("\n the numbers that division on 7 and 3:\n");
	for (i = 1; i < 101; i++)
	{
		if (i % 7 == 0 && i % 3 == 0)
		{
			printf(" % d", i);
		}
	}
}
/*
The numbers from 1 to 10 without 7:
  1  2  3  4  5  6  8  9  10
 the numbers that division on 7 and 3:
  21  42  63  84
*/