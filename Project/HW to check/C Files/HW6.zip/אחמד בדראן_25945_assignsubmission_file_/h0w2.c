//question 1 hw02
/*
ahmad badran
324830447
????? 2 ???? 1 ?
*/
#include <stdio.h>

void main()
{
	int i, a;
	printf("question 1 a:\n");
	for (i = 1; i <= 10; i++)
	{
		if (i % 7 != 0)
			//if(!(i%7==0))   

			// if (i==7)
				//continue; 
			printf("%d ", i);
	}
	printf("\n");
	printf("question 1 b:\n");
	
	for (a = 1; a <= 100; a++)
	{
	
		if (a % 3 == 0 && a % 7 == 0) 
			printf("%d ", a);
	
	}


}

/*PELET/OUTPUT
question 1 a:
1 2 3 4 5 6 8 9 10
question 1 b:
21 42 63 84
C:\Users\97254\Desktop\ahmmad\PROJECT2\x64\Debug\PROJECT2.exe (process 7116) exited with code 0.
Press any key to close this window . . .
*/