﻿// hw2-1.c

/*
סלאמה עיאש
315869909
homework question 6:
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main()
{
	int i;
	printf("question 'A':\n");
	for (i = 1; i <= 10; i++)
	{
		if (i % 7 != 0)
		{
			printf("%d ", i);
		}
	}
	printf("\nquestion 'B':\n");
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
		{
			printf("%d ", i);
		}
	}
}
/*pelet/output
question 'A':
1 2 3 4 5 6 8 9 10
question 'B':
21 42 63 84
C:\Users\ASUS\source\repos\hw2-1\x64\Debug\hw2-1.exe (process 22176) exited with code 0.
To automatically close the console when debugging stops, enable Tools->Options->Debugging->Automatically close the console when debugging stops.
Press any key to close this window . . .
*/