//HW2.1.c
/*
DANIEL RAHAHMIM
315754499
HW2.1
*/
#define CRT_NO_SECURE_WARNINGS
#include<stdio.h>
void main()
{
	int i;

	for (i = 1; i <= 10; i++)
	{
		if (i != 7 && i != 0)

			printf("%d", i);
	}
	        printf("\n");

	for (i = 1; i <= 100; i++)
	{

		if (i % 3 == 0 && i % 7 == 0)

			printf("%d\t", i);

	}


}

//PELET OUTPOT
/*
1234568910
21      42      63      84
C:\Users\daniel\source\repos\?????? ???- ???? ?????\HW2.1\x64\Debug\HW2.1.exe (process 6664) exited with code 0.
Press any key to close this window . . .
*/
