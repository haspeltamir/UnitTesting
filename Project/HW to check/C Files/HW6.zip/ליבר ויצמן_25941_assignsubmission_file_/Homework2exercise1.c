/*
Name: Homework2,exercise 1
libar
Vizman
211711205
Homework 2, exercise 1
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
void main() {
	int i;
	for (i = 1; i <= 10; i++)
	{
		if (i != 7)
			printf("%-2d", i);
	}
	putchar('\n');
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 && i % 7 == 0)
			printf("%-5d", i);
	}
}
/*
Pelet/Output:
1 2 3 4 5 6 8 9 10
21   42   63   84
D:\���������\Homework 2 exercise 1\x64\Debug\Homework 2 exercise 1.exe (process 18472) exited with code 0.
Press any key to close this window . . .*/