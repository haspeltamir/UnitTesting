//hw02-1.c
/*
ori azuviv
208741009
home work 02-1
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	printf("the numbers between 1 and 10 without 7 : \n");
	for (int i = 1; i <= 10; i++)
	{
		if (i != 7)
			printf("\n%d",i);
	}
	printf("\nthe numbers between 1-100 divided by 3 and 7  : \n");
	for (int j = 1; j <= 100; j++)
	{
		if ((j % 7 == 0) && (j % 3 == 0))
			printf("\n%d", j);
	}


	return 0;
}

/*
output -
the numbers between 1 and 10 without 7 :

1
2
3
4
5
6
8
9
10
the numbers between 1-100 divided by 3 and 7  :

21
42
63
84
C:\Users\USER\source\repos\HOME WORK\hw02-1\x64\Debug\hw02-1.exe (process 17196) exited with code 0.
Press any key to close this window . . .

*/
	
















