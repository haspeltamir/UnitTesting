'''
#בריק חאלדון
#323991091
#מטלה 3

'''


q = int (input (" pls enter a num1 : " ))
w =float (input (" pls enter a num2 : " ))
e = float (input (" pls enter a num3 : " ))
r = int (input (" pls enter a num4 : " ))
t = float (input (" pls enter a num5 : " ))
y = float (input (" pls enter a num6 : " ))
u = int (input (" pls enter a num7 : " ))
h = float (input (" pls enter a num8 : " ))
i = float (input (" pls enter a num9 : " ))
print (f'{q:<1} {w:<1.2f} {e:<1.3f}' )
print (f'{r:<5} {t:<1.2f} {y:<1.3f}' )
print (f'{u:<5} {h:<1.2f} {i:<1.3f}' )

'''

 

pls enter a num1 : 12345
 pls enter a num2 : 56.56
 pls enter a num3 : 28.500
 pls enter a num4 : 43
 pls enter a num5 : 77.65
 pls enter a num6 : 30.242
 pls enter a num7 : 564
 pls enter a num8 : 84.90
 pls enter a num9 : 32.500
12345 56.56 28.500
43    77.65 30.242
564   84.90 32.500
'''
