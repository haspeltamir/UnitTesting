
#HW.3
'''
mohmd khateb
206770604
'''
a= eval(input('pls enter numper 1 מדגרה:'))
b= eval(input('pls enter numper 2 מדגרה:'))
c= eval(input('pls enter numper 3 מדגרה:'))
d= eval(input('pls enter numper 1 לחות:'))
f= eval(input('pls enter numper 2 לחות:'))
g= eval(input('pls enter numper 3 לחות:'))
x= eval(input('pls enter numper 1 חום:'))
y= eval(input('pls enter numper 2 חום:'))
z= eval(input('pls enter numper 3 חום:'))
print(f'{a:<15} {d:<10.2f} {x:<10.3f}')
print(f'{b:<15} {f:<10.2f} {y:<10.3f}')
print(f'{c:<15} {g:<10.2f} {z:<10.3f}')

