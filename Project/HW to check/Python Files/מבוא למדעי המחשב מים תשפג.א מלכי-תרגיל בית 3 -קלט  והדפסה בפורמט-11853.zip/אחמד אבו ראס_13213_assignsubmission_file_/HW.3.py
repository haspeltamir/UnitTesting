#HW.3
'''
ahnad abu ras
211708102
HW.3
'''
a = eval(input('pls enter numper מדגרה 1:'))
b = eval(input('pls enter numper מדגרה 2:'))
c = eval(input('pls enter numper מדגרה 3:'))
d = eval(input('pls enter numper לחות 1:'))
f = eval(input('pls enter numper לחות 2:'))
g = eval(input('pls enter numper לחות 3:'))
x = eval(input('pls enter numper חום 1:'))
y = eval(input('pls enter numper חום 2:'))
z = eval(input('pls enter numper חום 3:'))
print(f'{a:<15}{d:<10.2f}{x:<10.3f}')
print(f'{b:<15}{f:<10.2f}{y:<10.3f}')
print(f'{c:<15}{g:<10.2f}{z:<10.3f}')
'''

= RESTART: C:/Users/USER/OneDrive/שולחן העבודה/מדעי מחשב/HW.3.py
pls enter numper מדגרה 1:54321
pls enter numper מדגרה 2:23541
pls enter numper מדגרה 3:22553
pls enter numper לחות 1:35.6
pls enter numper לחות 2:34.524
pls enter numper לחות 3:36.12
pls enter numper חום 1:28.7
pls enter numper חום 2:27.96
pls enter numper חום 3:28.3
54321          35.60     28.700    
23541          34.52     27.960    
22553          36.12     28.300    
'''

