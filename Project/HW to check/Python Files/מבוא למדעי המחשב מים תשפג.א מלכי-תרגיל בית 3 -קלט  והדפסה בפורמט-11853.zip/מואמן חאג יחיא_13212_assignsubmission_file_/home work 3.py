#תרגיל מספר 1 שאלה שניה .py
'''
moamen haj yahya
211962352
Home Work 3
'''

x=int(input('pls enter number:'))
y=eval(input('pls enter number 0-100:'))
z=eval(input('pls enter number:'))
a=int(input('pls enter number:'))
b=eval(input('pls enter number 0-100:'))
c=eval(input('pls enter number:'))
d=int(input('pls enter number:'))
e=eval(input('pls enter number 0-100:'))
m=eval(input('pls enter number:'))
print(f'{x:<10.0f}{y:<10.2f}{z:<10.3f}')
print(f'{a:<10.0f}{b:<10.2f}{c:<10.3f}')
print(f'{d:<10.0f}{e:<10.2f}{m:<10.3f}')
'''pelet
pls enter number:12345
pls enter number 0-100:56.56
pls enter number:28.5
pls enter number:43
pls enter number 0-100:77.65
pls enter number:30.242
pls enter number:564
pls enter number 0-100:84.9
pls enter number:32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500 
'''


