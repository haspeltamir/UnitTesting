#hw01task2.py
'''
NITAYSOKO
318199718
HW01 TASK2
'''

a1 = float(input("enter madgera value: "))
a2 = float(input("enter temp: "))
a3 = float(input("enter humidity: "))

b1 = float(input("enter madgera value: "))
b2 = float(input("enter temp: "))
b3 = float(input("enter humidity: "))

c1 = float(input("enter madgera value: "))
c2 = float(input("enter temp: "))
c3 = float(input("enter humidity: "))



print(f"{a1:<10.0f}{a2:<10.2f}{a3:<10.3f}")
print(f"{b1:<10.0f}{b2:<10.2f}{b3:<10.3f}")
print(f"{c1:<10.0f}{c2:<10.2f}{c3:<10.3f}")

'''PELETOUTPUT
enter madgera value: 12345
enter temp: 56.56
enter humidity: 28.5
enter madgera value: 43
enter temp: 77.65
enter humidity: 30.242
enter madgera value: 564
enter temp: 84.9
enter humidity: 32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    
>>>
'''
