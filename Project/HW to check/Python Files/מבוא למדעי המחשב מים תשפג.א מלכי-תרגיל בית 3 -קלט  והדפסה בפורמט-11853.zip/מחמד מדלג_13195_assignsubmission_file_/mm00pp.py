#תרגיל בית שאלה 2
'''
mohamed medlij
213624596
 hw01 q02

 '''
a=eval (input ('plaese enter a number:'))
b=eval (input ('plaese enter a number:'))
c=eval (input ('plaese enter a number:'))
d=eval (input ('plaese enter a number:'))
e=eval (input ('plaese enter a number:'))
f=eval (input ('plaese enter a number:'))
g=eval (input ('plaese enter a number:'))
h=eval (input ('plaese enter a number:'))
i=eval (input ('plaese enter a number:'))

print(f'{a:<10.0f}{b:<10.2f}{c:<10.3f}')
print(f'{d:<10.0f}{e:<10.2f}{f:<10.3f}')
print(f'{g:<10.0f}{h:<10.2f}{i:<10.3f}')       

#פלט
>>> 
================== RESTART: C:\Users\מוחמד מדלג\Desktop\po2.py =================
plaese enter a number:12345
plaese enter a number:56.56
plaese enter a number:28.5
plaese enter a number:43
plaese enter a number:77.65
plaese enter a number:30.242
plaese enter a number:564
plaese enter a number:84.9
plaese enter a number:32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    
>>> 
