"""
lab 3
yazan mahamed
"""
x=int(input('please enter the number:'))
y=float(input('please enter the number:'))
z=float(input('please enter the number:'))
a=int(input('please enter the number:'))
b=float(input('please enter the number:'))
c=float(input('please enter the number:'))
e=int(input('please enter the number:'))
f=float(input('please enter the number:'))
g=float(input('please enter the number:'))
print(f'{x:<10} {y:<10.2f} {z:<10.3f}')
print(f'{a:<10} {b:<10.2f} {c:<10.3f}')
print(f'{e:<10} {f:<10.2f} {g:<10.3f}')

"""""""""""""""""""""""""""""""""""
========== RESTART: C:/Users/אבו קאסם/Downloads/פיתון עבודה 3.py ==========
please enter the number:12345
please enter the number:56.56
please enter the number:28.5
please enter the number:43
please enter the number:77.65
please enter the number:30.242
please enter the number:564
please enter the number:84.90
please enter the number:32.500
12345      56.56      28.500    
43         77.65      30.242    
564        84.90      32.500    
>>> 









      
