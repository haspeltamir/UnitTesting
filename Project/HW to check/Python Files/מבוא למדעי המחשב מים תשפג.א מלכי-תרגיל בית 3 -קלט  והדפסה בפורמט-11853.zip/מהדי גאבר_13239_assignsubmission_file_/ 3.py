#homework.3

'''
mahdi jaber
213184211
'''

a=int(input('pls enter number hatcheries :'))
b=eval(input('pls enter number humidity in the hatchery:'))
c=eval(input('pls enter number heat in the hatchery:'))
d=int(input('pls enter number hatcheries :'))
e=eval(input('pls enter number humidity in the hatchery:'))
f=eval(input('pls enter number heat in the hatchery:'))
g=int(input('pls enter number hatcheries :'))
h=eval(input('pls enter number humidity in the hatchery:'))
i=eval(input('pls enter number heat in the hatchery:'))

print(f'{a:<10}{b:<10.2f}{c:<10.3f}')
print(f'{d:<10}{e:<10.2f}{f:<10.3f}')
print(f'{g:<10}{h:<10.2f}{i:<10.3f}')      

'''
pelet

pls enter number hatcheries :12345
pls enter number humidity in the hatchery:56.56
pls enter number heat in the hatchery:28.5
pls enter number hatcheries :43
pls enter number humidity in the hatchery:77.65
pls enter number heat in the hatchery:30.242
pls enter number hatcheries :564
pls enter number humidity in the hatchery:84.9
pls enter number heat in the hatchery:32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    
'''
