#HW01.3
''' Bar Roitman
308399021 hw.05'''


a=eval( input("please enter haytchery number:"))
b=eval( input( "please enter humidity value:"))
c=eval( input("please enter temperature value:"))
d=eval( input("please enter haytchery number:"))
e=eval( input( "please enter humidity value:"))
f=eval( input("please enter temperature value:"))
g=eval( input("please enter haytchery number:"))
h=eval( input( "please enter humidity value:"))
i=eval( input("please enter temperature value:"))
if 0<b<100 and 0<e<100 and 0<h<100 :
    print (f"{a:<8} {b:<8.2f} {c:<8.3f}\n{d:<8} {e:<8.2f} {f:<8.3f}\n{g:<8} {h:<8.2f} {i:<8.3f}")
else:
    print ('error humidity')

        


'''output
please enter haytchery number:123
please enter humidity value:45.68
please enter temperature value:65.8789
please enter haytchery number:487
please enter humidity value:64.587
please enter temperature value:96.3256
please enter haytchery number:987
please enter humidity value:36.887
please enter temperature value:88.3545
123      45.68    65.879  
487      64.59    96.326  
987      36.89    88.355  '''
