#matala3 hw0.1 -2
'''
Ghalia Falah
324298314
'''
number=int(input('pls enter num :'))
high=float(input('pls inter high:'))
t=float(input('pls enter t:'))
number1=int(input('pls enter num :'))
high1=float(input('pls inter high:'))
t1=float(input('pls enter t:'))
number2=int(input('pls enter num :'))
high2=float(input('pls inter high:'))
t2=float(input('pls enter t:'))
print(f"{number :<10}{high :<10.2f}{t :<10.3f}")
print(f"{number1 :<10}{high1 :<10.2f}{t1 :<10.3f}")
print(f"{number2 :<10}{high2 :<10.2f}{t2 :<10.3f}")
'''
#paleet
Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/PC/OneDrive/שולחן העבודה/python/חשוב/‏‏תיקיה חדשה/matala3.py
pls enter num :5
pls inter high:4
pls enter t:4
pls enter num :4
pls inter high:7
pls enter t:9
pls enter num :2
pls inter high:6
pls enter t:4
5         4.00      4.000     
4         7.00      9.000     
2         6.00      4.000
'''



