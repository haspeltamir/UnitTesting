# תרגיל בית 1 שאלה 1
'''
idan moalem
208687038

homework 3
'''
m1 = eval (input('please enter number madgera1:'))
l1 = eval (input('please enter number lahut1:'))
h1 = eval (input('please enter number heat1:'))
         
m2 = eval (input('please enter number madgera2:'))
l2 = eval (input('please enter number lahut2:'))
h2 = eval (input('please enter number heat2:'))
           
m3 = eval (input('please enter number madgera3:'))
l3 = eval (input('please enter number lahut3:'))
h3 = eval (input('please enter number heat3:'))

print (f'{m1:<10}{l1:<10.2f}{h1:<10.3f}')
print (f'{m2:<10}{l2:<10.2f}{h2:<10.3f}')
print (f'{m2:<10}{l2:<10.2f}{h2:<10.3f}')

#פלט
'''
========= RESTART: C:/Users/user/Desktop/פייתון/עבודות/שיעורי בית 3.py =========
please enter number madgera1:100
please enter number lahut1:5
please enter number heat1:12
please enter number madgera2:12.11
please enter number lahut2:10.5
please enter number heat2:11
please enter number madgera3:1
please enter number lahut3:3.33
please enter number heat3:12.333
100       5.00      12.000    
12.11     10.50     11.000    
12.11     10.50     11.000    
>>> 
'''


