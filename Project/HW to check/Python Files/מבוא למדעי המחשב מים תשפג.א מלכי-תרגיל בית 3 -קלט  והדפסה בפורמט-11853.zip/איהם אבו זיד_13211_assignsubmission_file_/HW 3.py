# hw 3
'''
AIHAM ABOZED
211476304
'''
x = int (input( 'enter number:1' ))
y = float (input( 'enter humidity:1'))
z = float (input( 'enter heat:1'))


a = int (input( 'enter number:2'))
b = float (input( 'enter humidity:2'))
c = float (input( 'enter heat:2'))


e = int (input( 'enter number:3'))
f = float (input( 'enter humidity:3'))
g = float (input( 'enter heat:3'))

print(f'{x:<10.0f}{y:<10.2f}{z:<10.3f}')
print(f'{a:<10.0f}{b:<10.2f}{c:<10.3f}')
print(f'{e:<10.0f}{f:<10.2f}{g:<10.3f}')

'''
enter number:112345
enter humidity:156.56
enter heat:128.500
enter number:243
enter humidity:277.65
enter heat:230.242
enter number:3564
enter humidity:384.90
enter heat:332.500
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    
'''














