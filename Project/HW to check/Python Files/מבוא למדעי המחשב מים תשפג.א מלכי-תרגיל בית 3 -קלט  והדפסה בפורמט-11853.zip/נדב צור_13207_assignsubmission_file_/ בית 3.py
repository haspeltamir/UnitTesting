#HW3.py
'''
תרגיל 1 שאלה 2
Nadav Tsur
206057655
'''

a=eval(input('incubator number:'))
b=eval(input('incubator number:'))
c=eval(input('incubator number:'))
a1=eval(input('incubator humidity:'))
b1=eval(input('incubator humidity:'))
c1=eval(input('incubator humidity:'))
a2=eval(input('incubator heat:'))
b2=eval(input('incubator heat:'))
c2=eval(input('incubator heat:'))
if a1>100 or a1<0:
 print('error')
if b1>100 or b1<0:
 print('error')
if c1>100 or c1<0:
 print('error')
 
print(f" {a:<6.0f} {a1:<6.2f} {a2:<6.3f}\n {b:<6.0f} {b1:<6.2f} {b2:<6.3f}\n {c:<6.0f} {c1:<6.2f} {c2:<6.3f}")


'''
incubator number:12345
incubator number:43
incubator number:564
incubator humidity:56.56
incubator humidity:77.65
incubator humidity:84.90
incubator heat:28.500
incubator heat:30.242
incubator heat:32.500
 12345  56.56  28.500
 43     77.65  30.242
 564    84.90  32.500
'''
