'''
טלה מספר 3מ
גבארין אחמד 
308197896

שאלה שניה 
כתבו תוכנית המקבלת את הנתונים הבאים על 3 מדגרות
ומדפיסה אותם בטבלה, כך שכל עמודה מיושרת לשמאל
ואינה חורגת מתחומה (ראה תדפיס לדוגמא)

1.מספר מדגרה (מספר מקסימלי מכיל  5 ספרות)
2.לחות במדגרה (טווח בין 0 ל-100 מכיל לכל היותר 3 ספרות ו2 אחרי הנקודה)
3.חום במדגרה (דיוק של 3 אחרי הנקודה)

לדוגמא, עבור הקלט:
12345 56.56 28.5
43 77.65 30.242
564 84.9 32.5


יודפס:
12345 	56.56 	28.500
43      77.65 	30.242
564     84.90 	32.500 
'''

N1= eval(input('Please enter Mespar Madgera num1, (5 numbers limit): '))
W1= eval(input('Please enter Lahot bamdgera num1(0-100): '))    
H1= eval(input('Please enter the Temperature num1: '))
N2= eval(input('Please enter Mespar Madgera num2, (5 numbers limit): '))
W2= eval(input('Please enter Lahot bamdgera num2(0-100): '))    
H2= eval(input('Please enter the Temperature num2: '))
N3= eval(input('Please enter Mespar Madgera num3, (5 numbers limit): '))
W3= eval(input('Please enter Lahot bamdgera num3(0-100): '))    
H3= eval(input('Please enter the Temperature num3: '))
print(f'{N1:<10}{W1:<10.2f}{H1:<10.3f}')
print(f'{N2:<10}{W2:<10.2f}{H2:<10.3f}')
print(f'{N3:<10}{W3:<10.2f}{H3:<10.3f}')

'''
pelet:

Please enter Mespar Madgera num1, (5 numbers limit): 12345
Please enter Lahot bamdgera num1(0-100): 56
Please enter the Temperature num1: 20
Please enter Mespar Madgera num2, (5 numbers limit): 12378
Please enter Lahot bamdgera num2(0-100): 55
Please enter the Temperature num2: 10
Please enter Mespar Madgera num3, (5 numbers limit): 32165
Please enter Lahot bamdgera num3(0-100): 25.6
Please enter the Temperature num3: 10
12345     56.00     20.000    
12378     55.00     10.000    
32165     25.60     10.000    
'''

