#inputoutput.py

 

'''
evelyn shhadi
322729658 
שאלה 1

'''

##
##print (' pls enter number : ')
##number = input()

#בריכה 1 

number1 = int(input('pls enter Pool 1 number : ' ))
numberPH1 = float(input('pls enter PH 1 number : ' ))
numberh1 = float(input('pls enter Heat of water 1 number : ' ))
numbert1 = float(input('pls enter The height of the water 1 number : ' ))

 

# בריכה 2

number2 = int(input('pls enter Pool 2 number : ' ))
numberPH2 = float(input('pls enter PH 2 number : ' ))
numberh2 = float(input('pls enter Heat of water 2 number : ' ))
numbert2 = float(input('pls enter The height of the water 2 number : ' ))

 

# בריכה 3
number3 = int(input('pls enter Pool 3 number : ' ))
numberPH3 = float(input('pls enter PH 3 number : ' ))
numberh3 = float(input('pls enter Heat of waterv3 number : ' ))
numbert3 = float(input('pls enter The height of the water 3 number : ' ))

 

print (f'{number1:<10}{numberPH1:<10.1f}{numberh1:<10.2f}{numbert1:<10.3f}')
print (f'{number2:<10}{numberPH2:<10.1f}{numberh2:<10.2f}{numbert2:<10.3f}')
print (f'{number3:<10}{numberPH3:<10.1f}{numberh3:<10.2f}{numbert3:<10.3f}')

 

'''PELET/output
pls enter Pool 1 number : 12345
pls enter PH 1 number : 12.4
pls enter Heat of water 1 number : 45.77
pls enter The height of the water 1 number : 77.555
pls enter Pool 2 number : 456
pls enter PH 2 number : 1
pls enter Heat of water 2 number : 8.66
pls enter The height of the water 2 number : 7.888
pls enter Pool 3 number : 9638
pls enter PH 3 number : 75.1
pls enter Heat of waterv3 number : 5.69
pls enter The height of the water 3 number : 14.777
12345     12.4      45.77     77.555    
456       1.0       8.66      7.888     
9638      75.1      5.69      14.777   
'''


 
