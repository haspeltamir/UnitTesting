#HW01.Q2.PY

'''
Michell Halloun
212747729

HW01.Q2.PY
Print
'''
a = eval(input('enter a number mad1'))
b = eval(input('enter a number lmad1'))
c = eval(input('enter a number hmad1'))
d = eval(input('enter a number mad2'))
e = eval(input('enter a number lmad2'))
f = eval(input('enter a number hmad2'))
g = eval(input('enter a number mad3'))
h = eval(input('enter a number lmad3'))
i = eval(input('enter a number hmad3'))

print(f'{a:<7.0f} {b:<7.2f} {c:<7.3f}')
print(f'{d:<7.0f} {e:<7.2f} {f:<7.3f}')
print(f'{g:<7.0f} {h:<7.2f} {i:<7.3f}')

#פלט
= RESTART: C:/Users/Micheal/Documents/מישל סמסטר א/מישל מדעי מחשב/hw0.1 Q2 py.py
enter a number mad112345
enter a number lmad156.56
enter a number hmad128.5
enter a number mad243
enter a number lmad277.65
enter a number hmad230.242
enter a number mad3564
enter a number lmad384.9
enter a number hmad332.5
12345   56.56   28.500 
43      77.65   30.242 
564     84.90   32.500 
>>> 
