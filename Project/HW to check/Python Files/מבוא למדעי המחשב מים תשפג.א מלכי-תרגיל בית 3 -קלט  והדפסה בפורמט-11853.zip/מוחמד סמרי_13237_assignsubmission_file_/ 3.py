#H.W Q1.1

'''
MOHAMAD SOMRE
212773683
'''
x=eval(input('pls enter number מדרגה : '))
a=eval(input('pls enter number לחות :'))
b=eval(input('pls enter number חום :'))
w=eval(input('pls enter number מדרגה2 :'))
m=eval(input('pls enter number 2לחות :'))
h=eval(input('pls enter number 2חום :'))
y=eval(input('pls enter number 3מדרגה : '))
o=eval(input('pls enter number 3לחות :'))
p=eval(input('pls enter number 3חום :'))
print(f'{x:<15}{a:<10.2f}{b:<10.3f}') 
print(f'{w:<15}{m:<10.2f}{h:<10.3f}') 
print(f'{y:<15}{o:<10.2f}{p:<10.3f}') 

'''
pls enter number מדרגה : 12345
pls enter number לחות :22.5
pls enter number חום :32
pls enter number מדרגה2 :54321
pls enter number 2לחות :55
pls enter number 2חום :23
pls enter number 3מדרגה : 67896
pls enter number 3לחות :65
pls enter number 3חום :22
12345          22.50     32.000    
54321          55.00     23.000
'''







67896          65.00     22.000
