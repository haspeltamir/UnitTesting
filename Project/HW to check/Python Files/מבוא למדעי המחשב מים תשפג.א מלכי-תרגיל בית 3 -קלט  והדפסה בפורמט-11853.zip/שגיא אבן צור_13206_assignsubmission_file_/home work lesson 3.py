#תרגיל בית שיעור 3 שאלה 1
'''
Sagi Even Tsour
209082502
הדפסה בפורמט
'''
a=eval(input('enter a number mad1 here'))
b=eval(input('enter a number hom1 here'))
c=eval(input('enter a number lahut1 here'))
d=eval(input('enter a number mad2 here'))
e=eval(input('enter a number hom2 here'))
f=eval(input('enter a number lahut2 here'))
g=eval(input('enter a number mad3 here'))
h=eval(input('enter a number lahut3 here'))
i=eval(input('enter a number hom3 here'))
print(f"{a:<6} {c:<6.2f} {b:6.3f}")
print(f"{d:<6} {f:<6.2f} {e:6.3f}")
print(f"{g:<6} {i:<6.2f} {h:6.3f}")

#PELLET
'''
====== RESTART: C:\Users\Sagie\OneDrive\שולחן העבודה\home work lesson 3.py =====
enter a number mad1 here4
enter a number hom1 here5
enter a number lahut1 here6
enter a number mad2 here2
enter a number hom2 here3
enter a number lahut2 here4
enter a number mad3 here7
enter a number lahut3 here8
enter a number hom3 here3
4      6.00    5.000
2      4.00    3.000
7      3.00    8.000
'''

