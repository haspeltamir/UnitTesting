#HW.3
'''

ibrahem shahen
212687248
HW.3
'''

a = eval(input('pls enter number 1 מדרגה:'))
b = eval(input('pls enter number 2 מדרגה:'))
c = eval(input('pls enter number 3 מדרגה:'))
d = eval(input('pls enter number 1 לחות:'))
f = eval(input('pls enter number 2 לחות:'))
g = eval(input('pls enter number 3 לחות:'))
v = eval(input('pls enter number 1 חום:'))
s = eval(input('pls enter number 2 חום:'))
n = eval(input('pls enter number 3 חןם:'))
print(f'{a:<15}{d:<10.2f}{v:<10.3f}')
print(f'{b:<15}{f:<10.2f}{s:<10.3f}')
print(f'{c:<15}{g:<10.2f}{n:<10.3f}')
'''


===== RESTART: C:/Users/user/AppData/Local/Programs/Python/Python38/HW.3.py ====
pls enter number 1 מדרגה:12345
pls enter number 2 מדרגה:34567
pls enter number 3 מדרגה:45678
pls enter number 1 לחות:33.2
pls enter number 2 לחות:33.3
pls enter number 3 לחות:33.4
pls enter number 1 חום:34.2
pls enter number 2 חום:34.3
pls enter number 3 חןם:34.4
12345          33.20     34.200    
34567          33.30     34.300    
45678          33.40     34.400    
>>> 
'''
