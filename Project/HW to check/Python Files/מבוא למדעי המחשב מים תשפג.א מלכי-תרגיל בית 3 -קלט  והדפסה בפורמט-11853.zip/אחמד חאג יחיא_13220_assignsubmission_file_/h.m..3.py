'''
HW1
EXERCISE 1
ADHAM HASSOUN 314629429
AHMAD HAJ YHIA 211331129
'''
number=int(input('pls enter num :'))
high=float(input('pls inter high:'))
t=float(input('pls enter t:'))
number1=int(input('pls enter num :'))
high1=float(input('pls inter high:'))
t1=float(input('pls enter t:'))
number2=int(input('pls enter num :'))
high2=float(input('pls inter high:'))
t2=float(input('pls enter t:'))
print(f"{number :<10}{high :<10.2f}{t :<10.3f}")
print(f"{number1 :<10}{high1 :<10.2f}{t1 :<10.3f}")
print(f"{number2 :<10}{high2 :<10.2f}{t2 :<10.3f}")
'''
================== RESTART: C:/Users/97252/Downloads/h.m..3.py =================
pls enter num :12345
pls inter high:56.56
pls enter t:28.5
pls enter num :43
pls inter high:77.65
pls enter t:30.242
pls enter num :564
pls inter high:84.90
pls enter t:32.500
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    


'''
