#HOMEWORK 3.PY
'''
omri shally 
322703885
HW.3
'''
number=int(input("number number1:"))
humidity=float(input("humidity number1:"))
height=float(input("height number1:"))

numbera=int(input("number number2:"))
humiditya=float(input("humidity number2:"))
heighta=float(input("height number2:"))

numberb=int(input("number number3:"))
humidityb=float(input("humidity number3:"))
heightb=float(input("height number3:"))

print(f'{number:<7.0f}{humidity:<7.2f}{height:<7.3f}')
print(f'{numbera:<7.0f}{humiditya:<7.2f}{heighta:<7.3f}')
print(f'{numberb:<7.0f}{humidityb:<7.2f}{heightb:<7.3f}')

'''
pelet
5      4.00   58.000 
4      1.00   2.000  
3      5.00   6.000  
'''
