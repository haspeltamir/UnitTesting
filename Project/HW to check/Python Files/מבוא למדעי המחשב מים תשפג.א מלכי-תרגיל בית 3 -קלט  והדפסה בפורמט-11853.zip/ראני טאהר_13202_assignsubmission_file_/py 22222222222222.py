#תרגיל בית 3 שאלה 3
'''

home work 2
212499669
Rani Taher
'''

c=eval (input('pls enter num : '))
d=eval(input('pls enter num : '))
z=eval(input('pls enter num : '))
b=eval(input('pls enter num : '))
m=eval(input('pls enter num : '))
a=eval(input('pls enter num : '))
q=eval(input('pls enter num : '))
k=eval(input('pls enter num : '))
p=eval(input('pls enter num : '))

print(f"{c:<10}{d:<10.2f}{z:<10.3f}")
print(f"{b:<10}{m:<10.2f}{a:<10.3f}")
print(f"{q:<10}{k:<10.2f}{p:<10.3f}")
'''
= RESTART: C:/Users/MSI/AppData/Local/Programs/Python/Python38/py 22222222222222.py
pls enter num : 12345
pls enter num : 56.56
pls enter num : 28.500
pls enter num : 43
pls enter num : 77.65
pls enter num : 30.242
pls enter num : 54
pls enter num : 84.90
pls enter num : 32.500
12345     56.56     28.500    
43        77.65     30.242    
54        84.90     32.500
'''
