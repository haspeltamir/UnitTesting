#.תרגיל בית 1 שאלה 2
#מגישים:
# 208408559 יוסי דרך
#ניצן תפארת 209074764

mad = eval(input('please anter a madgera : '))
la = eval(input('please anter a lahut : '))
hot = eval(input('please anter a hot : '))

mad1 = eval(input('please anter a madgera1 : '))
la1 = eval(input('please anter a lahut1 : '))
hot1 = eval(input('please anter a hot1 : '))


mad2 = eval(input('please anter a madgera2 : '))
la2 = eval(input('please anter a lahut2 : '))
hot2 = eval(input('please anter a hot2 : '))



print( f'{mad : <6} {la : <6.2f} {hot : <6.3f} ')
print( f'{mad1 : <6} {la1 : <6.2f} {hot1 : <6.3f} ')
print( f'{mad2 : <6} {la2 : <6.2f} {hot2 : <6.3f} ')

#PELET
'''
= RESTART: C:/Users/nitza/OneDrive/שולחן העבודה/פייתון קבצים/שעורי בית 3 יוסי דרך וניצן תפארת.py
please anter a madgera : 1234
please anter a lahut : 54.6852
please anter a hot : 64.5874
please anter a madgera1 : 54123
please anter a lahut1 : 65.5874
please anter a hot1 : 64.55662
please anter a madgera2 : 5478
please anter a lahut2 : 67.28688
please anter a hot2 : 98.513
1234   54.69  64.587 
54123  65.59  64.557 
5478   67.29  98.513 
>>>
'''
