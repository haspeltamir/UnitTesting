'''
shalev nissan
211854013
hw01 q2
'''
n1=eval(input('enter the number 1(5 numbers):'))
l1=eval(input('enter the lahut 1(0-100):'))
t1=eval(input('enter the tamp 1:'))
n2=eval(input('enter the number 2:'))
l2=eval(input('enter the lahut 2(0-100):'))
t2=eval(input('enter the tamp 2:'))
n3=eval(input('enter the number 3:'))
l3=eval(input('enter the lahut 3(0-100):'))
t3=eval(input('enter the tamp 3:'))
print(f'{n1:<10}{l1:<10.2f}{t1:<10.3f}')
print(f'{n2:<10}{l2:<10.2f}{t2:<10.3f}')
print(f'{n3:<10}{l3:<10.2f}{t3:<10.3f}')
'''
pelet:
12345     50.00     25.000    
12323     50.00     32.000    
12343     45.00     28.000
'''










       


