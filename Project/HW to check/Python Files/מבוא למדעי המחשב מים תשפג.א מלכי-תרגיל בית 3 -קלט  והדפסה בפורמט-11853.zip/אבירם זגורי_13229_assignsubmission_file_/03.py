#HW01


'''
Aviram Zaguri
207775636
HW03
LAB2
'''

a= int(input('enter number of madgera 1:'))
b= float(input('enter temp of madgera 1:'))
c= float(input('enter humidity of madgera 1:'))
d= int(input('enter number of madgera 2:'))
e= float(input('enter temp of madgera 2:'))
f= float(input('enter humidity of madgera 2:'))
g= int(input('enter number of madgera 3:'))
h= float(input('enter temp of madgera 3:'))
i= float(input('enter humidity of madgera 3:'))
print(f'{a:<5} {b:<5.2f} {c:<5.3f}')
print(f'{d:<5} {e:<5.2f} {f:<5.3f}')
print(f'{g:<5} {h:<5.2f} {i:<5.3f}')

'''
PELET
enter number of madgera 1:1
enter temp of madgera 1:2
enter humidity of madgera 1:3
enter number of madgera 2:4
enter temp of madgera 2:5
enter humidity of madgera 2:6
enter number of madgera 3:7
enter temp of madgera 3:8
enter humidity of madgera 3:9
1     2.00  3.000
4     5.00  6.000
7     8.00  9.000

'''
