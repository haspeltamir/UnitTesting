#HW01.PY
'''
MAJD ASSAF
324229061
תרגיל בית 1 שאלה 2
'''
#מספר מדגרה ומספר מקסימלי מכיל 5 ספרות
#לחות במדגרה והטווח בין 0 ל-100 מכיל ךכל היותר 3 ספרות ו2 אחרי הנקודה
#חום במדגרה הדיוק של 3 אחרי הנקודה

z = eval(input('pls enter number 1 מדגרה:'))
x = eval(input('pls enter number 2 מדגרה:'))
c = eval(input('pls enter number 3 מדגרה:'))
v = eval(input('pls enter number 1 לחות:'))
b = eval(input('pls enter number 2 לחות:'))
n = eval(input('pls enter number 3 לחות:'))
m = eval(input('pls enter number 1 חום:'))
a = eval(input('pls enter number 2 חום:'))
s = eval(input('pls enter number 3 חום:'))
print(f'{z:<15}{v:<10.2f}{m:<10.3f}')
print(f'{x:<15}{b:<10.2f}{a:<10.3f}')
print(f'{c:<15}{n:<10.2f}{s:<10.3f}')

'''
======== RESTART: C:/Users/majdassaf/Desktop/HW01 שאלה מספר 2.py =======
pls enter number 1 מדגרה:5252
pls enter number 2 מדגרה:42825
pls enter number 3 מדגרה:545
pls enter number 1 לחות:84
pls enter number 2 לחות:72
pls enter number 3 לחות:55
pls enter number 1 חום:30
pls enter number 2 חום:35
pls enter number 3 חום:28
5252           84.00     30.000    
42825          72.00     35.000    
545            55.00     28.000    
'''




