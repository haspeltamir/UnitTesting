#question 1.py

'''
תרגיל בית 1 שאלה 1
mohamed ghanama
325475135
'''
a=eval(input('pls enter   מדגרה  1 :'))
b=eval(input('pls enter מדגרה לחות  0-100 1 :'))
c=eval(input('pls enter חום במדגרה1:'))
d=eval(input('pls enter מדגרה 2 :'))
e=eval(input('pls enter  לחות מדגרה2 0-100:'))
f=eval(input('pls enter חום במדגרה 2:'))
g=eval(input('pls enter מדגרה 3:'))
h=eval(input('pls enter לחות במדגרה 3  0-100:'))
i=eval(input('pls enter חום במדגרה 3:'))
print(f"{a:<10}{b:<10.2f}{c:<10.3f}")
print(f"{d:<10}{e:<10.2f}{f:<10.3f}")
print(f"{g:<10}{h:<10.2f}{i:<10.3f}")

'''
pls enter   מדגרה  1 :12345
pls enter מדגרה לחות  0-100 1 :56.56
pls enter חום במדגרה1:28.5
pls enter מדגרה 2 :43
pls enter  לחות מדגרה2 0-100:77.65
pls enter חום במדגרה 2:30.242
pls enter מדגרה 3:564
pls enter לחות במדגרה 3  0-100:84.9
pls enter חום במדגרה 3:32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500  
 
'''







