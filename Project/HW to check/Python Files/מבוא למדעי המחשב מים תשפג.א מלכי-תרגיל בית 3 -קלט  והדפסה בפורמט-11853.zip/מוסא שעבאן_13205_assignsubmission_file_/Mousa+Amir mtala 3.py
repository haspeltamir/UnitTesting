'''
Home work 3
Mousa shaaban 206459497
Amir sabra    211506696

'''
a = int (input (" pls enter a num1 : " ))
b = float (input (" pls enter a num2 : " ))
c = float (input (" pls enter a num3 : " ))
d = int (input (" pls enter a num4 : " ))
e = float (input (" pls enter a num5 : " ))
f = float (input (" pls enter a num6 : " ))
g = int (input (" pls enter a num7 : " ))
h = float (input (" pls enter a num8 : " ))
i = float (input (" pls enter a num9 : " ))
print (f'{a:<1} {b:<1.2f} {c:<1.3f}' )
print (f'{d:<5} {e:<1.2f} {f:<1.3f}' )
print (f'{g:<5} {h:<1.2f} {i:<1.3f}' )

'''
 pls enter a num1 : 12345
 pls enter a num2 : 56.56
 pls enter a num3 : 28.500
 pls enter a num4 : 43
 pls enter a num5 : 77.65
 pls enter a num6 : 30.242
 pls enter a num7 : 564
 pls enter a num8 : 84.90
 pls enter a num9 : 32.500
12345 56.56 28.500
43    77.65 30.242
564   84.90 32.500
'''

