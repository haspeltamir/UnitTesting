#HW.3
'''
ayh mnsour
214253502
HW.3
'''
a = eval(input('pls enter number 1 מדגרה:'))
b = eval(input('pls enter number 2 מדגרה:'))
c = eval(input('pls enter number 3 מדגרה:'))
d = eval(input('pls enter number 1 לחות:'))
f = eval(input('pls enter number 2 לחות:'))
g = eval(input('pls enter number 3 לחות:'))
x = eval(input('pls enter number 1 חום:'))
y = eval(input('pls enter number 2 חום:'))
z = eval(input('pls enter number 3 חום:'))
print(f'{a:<15}{d:<10.2f}{x:<10.3f}')
print(f'{b:<15}{f:<10.2f}{y:<10.3f}')
print(f'{c:<15}{g:<10.2f}{z:<10.3f}')

#PELET
'''
========================= RESTART: C:/מדעי מחשב/HW.3.py ========================
pls enter number 1 מדגרה:54321
pls enter number 2 מדגרה:23541
pls enter number 3 מדגרה:22553
pls enter number 1 לחות:35.6
pls enter number 2 לחות:34.524
pls enter number 3 לחות:36.12
pls enter number 1 חום:28.7
pls enter number 2 חום:32.6
pls enter number 3 חום:99.99
54321          35.60     28.700    
23541          34.52     32.600    
22553          36.12     99.990
>>>
'''

