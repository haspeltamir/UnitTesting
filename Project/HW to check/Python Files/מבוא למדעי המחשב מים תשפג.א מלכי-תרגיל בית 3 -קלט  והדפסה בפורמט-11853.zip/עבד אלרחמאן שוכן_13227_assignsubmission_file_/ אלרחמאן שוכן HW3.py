#תרגיל בית 3
'''

עבד אלרחמאן שוכן
318429701

'''
a=int(input('please enter the first hatchery number '))
if a>99999 or a<1:
    print('error')
b=float(input('please enter the first hatchery humidity 0-100: '))
if b>100 or b<0:
    print('error')
c=float(input('please enter the first hatchery temp '))

d=int(input('please enter the second hatchery number '))
if d>99999 or d<1:
    print('error')
e=float(input('please enter the second hatchery humidity 0-100: '))
if e>100 or e<0:
    print('error')
f=float(input('please enter the second hatchery temp '))

g=int(input('please enter the third hatchery number '))
if g>99999 or g<1:
    print('error')
h=float(input('please enter the third hatchery humidity 0-100: '))
if h>100 or h<0:
    print('error')
i=float(input('please enter the third hatchery temp '))




print(f'{a:<6.0f}',end=' ')
print(f'{b:<6.2f}',end=' ')
print(f'{c:<6.3f}',end=' ')
print()
print(f'{d:<6.0f}',end=' ')
print(f'{e:<6.2f}',end=' ')
print(f'{f:<6.3f}',end=' ')

print()
print(f'{g:<6.0f}',end=' ')
print(f'{h:<6.2f}',end=' ')
print(f'{i:<6.3f}',end=' ')

'''
please enter the first hatchery number 12345
please enter the first hatchery humidity 0-100: 56.56
please enter the first hatchery temp 28.5
please enter the second hatchery number 43
please enter the second hatchery humidity 0-100: 77.65
please enter the second hatchery temp 30.242
please enter the third hatchery number 564
please enter the third hatchery humidity 0-100: 84.9
please enter the third hatchery temp 32.5
12345  56.56  28.500 
43     77.65  30.242 
564    84.90  32.500
'''
