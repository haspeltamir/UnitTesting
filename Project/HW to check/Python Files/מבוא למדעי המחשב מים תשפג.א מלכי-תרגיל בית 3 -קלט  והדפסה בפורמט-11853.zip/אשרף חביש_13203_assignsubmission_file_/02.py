'''
NAME: ASHRAF HBEISH
ID: 314703943
HOME WORK 3
קלט והדפסה בפורמט
'''



a = eval(input("pls enter float number :"))
b = eval(input("pls enter float number :"))
c = eval(input("pls enter float number :"))
d = eval(input("pls enter float number :"))
e = eval(input("pls enter float number :"))
f = eval(input("pls enter float number :"))
g = eval(input("pls enter float number :"))
h = eval(input("pls enter float number :"))
l = eval(input("pls enter float number :"))

print(f"{a:<10.0f}{b:<10.2f}{c:<10.3f}")
print(f"{d:<10.0f}{e:<10.2f}{f:<10.3f}")
print(f"{g:<10.0f}{h:<10.2f}{l:<10.3f}")

'''PELET'''

pls enter float number :56789
pls enter float number :65.56
pls enter float number :14.567
pls enter float number :89
pls enter float number :99.77
pls enter float number :20.123
pls enter float number :789
pls enter float number :77.60
pls enter float number :32.400
56789     65.56     14.567    
89        99.77     20.123    
789       77.60     32.400    

'''PELET'''

