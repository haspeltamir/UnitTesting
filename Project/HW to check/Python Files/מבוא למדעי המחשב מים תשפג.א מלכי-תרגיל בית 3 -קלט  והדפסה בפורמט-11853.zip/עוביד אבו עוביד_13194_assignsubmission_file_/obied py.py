'''
HW1Q3
עביד אבו עביד
212970487
'''
number=int(input('pls enter num:'))
high=float(input('pls enter high:'))
h=float(input('pls enter h:'))
number1=int(input('pls enter num:'))
high1=float(input('pls enter high:'))
h1=float(input('pls enter h:'))
number2=int(input('pls enter num:'))
high2=float(input('pls enter high:'))
h2=float(input('pls enter h:'))
print(f'{number :<10}{high :<10.2f}{h :<10.3f}')
print(f'{number1 :<10}{high1 :<10.2f}{h1 :<10.3f}')
print(f'{number :<10}{high2 :<10.2f}{h2 :<10.3f}')

'''
= RESTART: C:/Users/My/AppData/Local/Programs/Python/Python39/hw1q3.py
pls enter num:5231
pls enter high:70.11
pls enter h:32.5
pls enter num:44
pls enter high:88.54
pls enter h:20.36
pls enter num:89
pls enter high:77
pls enter h:54
5231      70.11     32.500    
44        88.54     20.360    
5231      77.00     54.000


'''
