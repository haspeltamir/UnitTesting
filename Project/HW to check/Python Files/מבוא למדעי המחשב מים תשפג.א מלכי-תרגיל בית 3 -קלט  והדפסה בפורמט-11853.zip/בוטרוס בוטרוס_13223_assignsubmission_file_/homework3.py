#home work 3
'''
botros botros
324057603

'''
c=eval(input('pls enter num : '))
d=eval(input('pls enter num : '))
z=eval(input('pls enter num : '))
b=eval(input('pls enter num : '))
m=eval(input('pls enter num : '))
a=eval(input('pls enter num : '))
q=eval(input('pls enter num : '))
k=eval(input('pls enter num : '))
p=eval(input('pls enter num : '))

print(f"{c:<10}{d:<10.2f}{z:<10.3f}")
print(f'{b:<10}{m:<10.2f}{a:<10.3f}')
print(f'{q:<10}{k:<10.2f}{p:<10.3f}')

#פלט
pls enter num : 12345
pls enter num : 56.56
pls enter num : 28.5
pls enter num : 43
pls enter num : 77.65
pls enter num : 30.242
pls enter num : 564
pls enter num : 84.9
pls enter num : 32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500    
