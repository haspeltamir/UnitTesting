#HW03.py

'''
HW01 תרגיל 2
DAVID POLLAK
314781378
'''
print ("please enter the following data:")
a1 = eval(input("Hatchery number:"))
b1 = eval(input("Homidity (0-100):"))
c1 = eval(input("Temperature:"))

print ("please enter the following data for the next Hatchery:")
a2 = eval(input("Hatchery number:"))
b2 = eval(input("Homidity (0-100):"))
c2 = eval(input("Temperature:"))

print ("please enter the following data for the next Hatchery:")
a3 = eval(input("Hatchery number:"))
b3 = eval(input("Homidity (0-100):"))
c3 = eval(input("Temperature:"))

print (f"{a1:<6.0f}{b1:<6.2f}{c1:<6.3f}")
print (f"{a2:<6.0f}{b2:<6.2f}{c2:<6.3f}")
print (f"{a3:<6.0f}{b3:<6.2f}{c3:<6.3f}")
    
'''
PELET:

please enter the following data:
Hatchery number:12345
Homidity (0-100):56.56
Temperature:28.5
please enter the following data for the next Hatchery:
Hatchery number:43
Homidity (0-100):77.65
Temperature:30.242
please enter the following data for the next Hatchery:
Hatchery number:564
Homidity (0-100):84.9
Temperature:32.5
12345 56.56 28.500
43    77.65 30.242
564   84.90 32.500
'''
