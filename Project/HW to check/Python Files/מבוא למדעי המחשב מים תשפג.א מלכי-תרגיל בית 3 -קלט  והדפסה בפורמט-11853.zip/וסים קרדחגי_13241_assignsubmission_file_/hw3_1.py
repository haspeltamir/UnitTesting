'''
וסים קורדחגי
211706999
HW03
LAB3
'''

a= int(input('enter number of madgera 1:'))
b= float(input('enter temp of madgera 1:'))
c= float(input('enter lachot of madgera 1:'))
d= int(input('enter number of madgera 2:'))
e= float(input('enter temp of madgera 2:'))
f= float(input('enter lachot of madgera 2:'))
g= int(input('enter number of madgera 3:'))
h= float(input('enter temp of madgera 3:'))
i= float(input('enter lachot of madgera 3:'))
print(f'{a:<10} {b:<10.2f} {c:<10.3f}')
print(f'{d:<10} {e:<10.2f} {f:<10.3f}')
print(f'{g:<10} {h:<10.2f} {i:<10.3f}')

'''
pelet
enter number of madgera 1:2 
enter temp of madgera 1:23.2
enter lachot of madgera 1:32.56
enter number of madgera 2:3
enter temp of madgera 2:12.4
enter lachot of madgera 2:56.675
enter number of madgera 3:5
enter temp of madgera 3:56.9
enter lachot of madgera 3:100
2          23.20      32.560    
3          12.40      56.675    
5          56.90      100.000 
'''
