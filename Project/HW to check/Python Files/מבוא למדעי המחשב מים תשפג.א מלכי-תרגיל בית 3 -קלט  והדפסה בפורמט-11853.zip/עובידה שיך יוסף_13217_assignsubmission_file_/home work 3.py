#תרגיל מםפר 1 שאלה שניה .py
'''
obaida shek yosef
213133721
home work 3
'''
a = int(input('pls enter number'))
b = eval(input('pls enter number'))
c = eval(input('pls enter number'))
d = int(input('pls enter number'))
e = eval(input('pls enter number'))
f = eval(input('pls enter number'))
g = int(input('pls enter number'))
h = eval(input('pls enter number'))
k = eval(input('pls enter number'))
print(f'{a:<10.0f}{b:<10.2f}{c:<10.3f}')
print(f'{d:<10.0f}{e:<10.2f}{f:<10.3f}')
print(f'{g:<10.0f}{h:<10.2f}{k:<10.3f}')

'''
pelet
pls enter number12345
pls enter number56.56
pls enter number28.5
pls enter number43
pls enter number77.65
pls enter number30.242
pls enter number564
pls enter number84.9
pls enter number32.5
12345     56.56     28.500    
43        77.65     30.242    
564       84.90     32.500
'''
