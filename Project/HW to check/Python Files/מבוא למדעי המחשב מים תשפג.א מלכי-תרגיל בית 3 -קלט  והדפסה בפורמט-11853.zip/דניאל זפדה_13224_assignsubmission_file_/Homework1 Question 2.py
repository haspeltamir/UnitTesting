'''
homework 2
Daniel Zepeda
341072585
'''

a=eval(input('Please enter number:'))
print(f"{a+0.23:<9.2f}{a+0.43:<9.2f}{a+0.63:<9.2f}{a+0.83:<9.2f}{a+1.03:<9.2f}\n{a+1.235:<9.3f}{a+1.435:<9.3f}{a+1.635:<9.3f}{a+1.835:<9.3f}{a+2.035:<9.3f}")

  
=================== RESTART: /Users/ricardo/Documents/hw2.py ===================
Please enter number:12
12.23    12.43    12.63    12.83    13.03    
13.235   13.435   13.635   13.835   14.035   
