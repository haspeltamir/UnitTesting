
# Avraham Koplovich
# 315687905
# H.W3 



a = eval(input('Number of lul'))
b = eval(input('Number of lul'))
c = eval(input('Number of lul'))
d = eval(input('number of לחות'))
e = eval(input('number of לחות'))
f = eval(input('number of לחות'))
g = eval(input('number of hit'))
h = eval(input('number of hit'))
i = eval(input('number of hit'))

print(f"{a:<8.0f}{d:<8.2f}{g:<8.3f}\n{b:<8.0f}{e:<8.2f}{h:<8.3f}\n{c:<8.0f}{f:<8.2f}{i:<8.3f}")

'''
output
Number of lul12345
Number of lul43
Number of lul564
number of לחות56.56
number of לחות77.65
number of לחות84.9
number of hit28.5
number of hit30.242
number of hit32.5

12345   56.56   28.500  
43      77.65   30.242  
564     84.90   32.500  
'''
