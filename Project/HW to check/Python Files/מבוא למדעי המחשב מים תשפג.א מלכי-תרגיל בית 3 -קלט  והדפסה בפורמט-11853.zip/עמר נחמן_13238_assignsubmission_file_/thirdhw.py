#תרגיל בית 1 שאלה 2
'''
עמר נחמן
207178724

homework3
'''
m1=eval(input('please enter number madgera1:'))
l1=eval(input('please enter number lahut1:'))
h1=eval(input('please enter number heat1:'))

m2=eval(input('please enter number madgera2:'))
l2=eval(input('please enter number lahut2:'))
h2=eval(input('please enter number heat2:'))

m3=eval(input('please enter number madgera3:'))
l3=eval(input('please enter number lahut3:'))
h3=eval(input('please enter number heat3:'))

print(f'{m1:<10} {l1:<10.2f} {h1:<10.3f}')
print(f'{m2:<10} {l2:<10.2f} {h2:<10.3f}')
print(f'{m3:<10} {l3:<10.2f} {h3:<10.3f}')

#pellet
'''
============== RESTART: C:/Users/USER001/Downloads/omer/thirdhw.py =============
please enter number madgera1:55
please enter number lahut1:45
please enter number heat1:35
please enter number madgera2:65
please enter number lahut2:55
please enter number heat2:45
please enter number madgera3:75
please enter number lahut3:65
please enter number heat3:55
55         45.00      35.000    
65         55.00      45.000    
75         65.00      55.000    
'''    

