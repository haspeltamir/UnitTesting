//Akram shehadeh 211917554
    public class Matrix
    {
        double[][] matrix;
        int size;

        public Matrix(int n)
        {
            this.matrix = new double[n][n];
            int i,j;
            this.size = n;

            for (i=0; i<this.size;i++)
            {
                for(j=0;j<this.size;j++)
                {
                    matrix[i][j] = 0;
                }
            }
        }

        public int getN()
        {
            return this.size;
        }

        public double getIJ(int i, int j)
        {
            return this.matrix[i][j];
        }

        public void setIJ(int i, int j, double value)
        {
            if ( i >= this.size || j >= this.size )
            {
                System.out.println("Error!!! The index out of range");
                return;
            }
            this.matrix[i][j] = value;
        }

        public String toString()
        {
            String str = "\n";
            int i,j;

            for (i=0; i<this.getN(); i++){
                for (j=0; j<this.getN(); j++){
                    str += String.format("%7.02f",getIJ(i,j)) + " ";
                }
                str += "\n";
            }
            return str;
        }

        public static Matrix matrixAdd(Matrix m1, Matrix m2)
        {
            if ( m1.getN() != m2.getN() )
            {
                System.out.println("Error!!! The lenght of both matrixes must be identical");
                return null;
            }

            Matrix m3 = new Matrix(m1.getN());
            int i,j;

            for (i=0; i<m1.getN(); i++)
            {
                for(j=0; j<m1.getN(); j++)
                {
                    m3.setIJ(i,j, (m1.getIJ(i,j)+ m2.getIJ(i,j)));
                }
            }
            return m3;
        }

        public static Matrix matrixSub(Matrix m1, Matrix m2)
        {
            if ( m1.getN() != m2.getN() )
            {
                System.out.println("Error!!! The lenght of both matrixes must be identical");
                return null;
            }

            Matrix m3 = new Matrix(m1.getN());
            int i,j;

            for (i=0; i<m1.getN(); i++){
                for(j=0; j<m1.getN(); j++){
                    m3.setIJ(i,j, (m1.getIJ(i,j) - m2.getIJ(i,j)));
                }
            }
            return m3;
        }

        public static Matrix matrixFill(Matrix m1, int size, int i_index, int j_index)
        {
            int i1,j1, i2,j2;
            Matrix new_matrix = new Matrix(m1.getN()/2);

            for (i1=0, i2=i_index; i1<new_matrix.getN(); i1++, i2++)
            {
                for(j1=0, j2=j_index; j1<new_matrix.getN(); j1++, j2++)
                {
                    new_matrix.setIJ(i1, j1, m1.getIJ(i2,j2));
                }
            }
            return new_matrix;
        }

        public static Matrix matrixEnlarge(Matrix m1, int new_size)
        {
            int i,j;
            Matrix new_matrix = new Matrix(new_size);

            for (i=0; i<m1.getN(); i++)
            {
                for (j=0; j<m1.getN(); j++)
                {
                    new_matrix.setIJ(i,j, m1.getIJ(i,j));
                }
            }
            return new_matrix;
        }

        public static void joinResult(Matrix sub_matrix, Matrix result_matrix, int i_start_sub_matrix, int j_start_sub_matrix)
        {
            int i_result_matrix, j_result_matrix;
            int i_sub_matrix_index, j_sub_matrix_index;

            for (i_sub_matrix_index=0, i_result_matrix=i_start_sub_matrix; i_sub_matrix_index < sub_matrix.getN() ; i_sub_matrix_index++, i_result_matrix++)
            {
                for(j_sub_matrix_index=0, j_result_matrix=j_start_sub_matrix; j_sub_matrix_index < sub_matrix.getN(); j_sub_matrix_index++, j_result_matrix++ )
                {
                    result_matrix.setIJ(i_result_matrix,j_result_matrix, sub_matrix.getIJ(i_sub_matrix_index, j_sub_matrix_index));
                }
            }
        }

        public static void MatrixCopy(Matrix src, Matrix dest)
        {
            int i,j;
            for (i=0; i<dest.getN(); i++)
            {
                for (j=0; j<dest.getN(); j++)
                {
                    dest.setIJ(i,j, src.getIJ(i,j));
                }
            }
        }

        public static Matrix matrixMult(Matrix m1, Matrix m2)
        {
            if ( m1.getN() != m2.getN() )
            {
                System.out.println("Error!!! The lenght of both matrixes must be identical");
                return null;
            }

            Matrix result_matrix = new Matrix(m1.getN());
            int n = m1.getN();
            int original_n = n;

            if ( n != 1 && n!= 2 && Math.sqrt(n) %2 != 0)
            {
                n = (int) Math.pow((int)(Math.sqrt(n))+1, 2);
                m1 = matrixEnlarge(m1, n);
                m2 = matrixEnlarge(m2, n);
            }
            result_matrix = new Matrix(n);

            if ( m1.getN() == 1 ){
                result_matrix.setIJ(0,0, m1.getIJ(0,0) * m2.getIJ(0,0));
            }
            else
            {
                Matrix A11 = matrixFill(m1, n / 2, 0, 0);
                Matrix A12 = matrixFill(m1, n / 2, 0, n / 2);
                Matrix A21 = matrixFill(m1, n / 2, n / 2, 0);
                Matrix A22 = matrixFill(m1, n / 2, n / 2, n / 2);


                Matrix B11 = matrixFill(m2, n / 2, 0, 0);
                Matrix B12 = matrixFill(m2, n / 2, 0, n /2);
                Matrix B21 = matrixFill(m2, n / 2, n / 2, 0);
                Matrix B22 = matrixFill(m2, n / 2, n / 2,  n / 2);


                // M1 = (A11 + A22)*(B11 + B22)
                Matrix M1 = Matrix.matrixMult(Matrix.matrixAdd(A11, A22), Matrix.matrixAdd(B11, B22));
                // M2 = (A21 + A22)*B11
                Matrix M2 = Matrix.matrixMult(Matrix.matrixAdd(A21, A22), B11);
                // M3 = A11*(B12 - B22)
                Matrix M3 = Matrix.matrixMult(A11, Matrix.matrixSub(B12, B22));
                // M4 = A22*(B21 – B11)
                Matrix M4 = Matrix.matrixMult(A22, Matrix.matrixSub(B21, B11));
                // M5 = (A11 + A12)*B22
                Matrix M5 = Matrix.matrixMult(Matrix.matrixAdd(A11, A12), B22);
                // M6 = (A21 – A11)*(B11 + B12)
                Matrix M6 = Matrix.matrixMult(Matrix.matrixSub(A21, A11), Matrix.matrixAdd(B11, B12));
                // M7 = (A12 – A22)*(B21 + B22)
                Matrix M7 = Matrix.matrixMult(Matrix.matrixSub(A12, A22), Matrix.matrixAdd(B21, B22));


                // C11 = M1 + M4 - M5 + M7;
                Matrix C11 = Matrix.matrixAdd(Matrix.matrixSub(Matrix.matrixAdd(M1,M4) ,M5),M7);
                // C12 = M3 + M5;
                Matrix C12 = Matrix.matrixAdd(M3, M5);
                // C21 = M2 + M4;
                Matrix C21 = Matrix.matrixAdd(M2, M4);
                // C22 = M1 - M2 + M3 + M6;
                Matrix C22 = Matrix.matrixAdd(Matrix.matrixAdd(Matrix.matrixSub(M1, M2), M3), M6);

                joinResult(C11, result_matrix, 0, 0);
                joinResult(C12, result_matrix, 0, n/2);
                joinResult(C21, result_matrix, n/2, 0);
                joinResult(C22, result_matrix, n/2, n/2);
            }

            if ( n != original_n )
            {
                Matrix new_matrix = new Matrix(original_n);
                MatrixCopy(result_matrix, new_matrix);
                return new_matrix;
            }
            return result_matrix;
            // }
            // double M1 = (m1.getIJ(0,0) + m1.getIJ(1,1)) * (m2.getIJ(0,0) + m2.getIJ(1,1));
            // double M2 = (m1.getIJ(1,0) + m1.getIJ(1,1)) * (m2.getIJ(0,0));
            // double M3 = (m1.getIJ(0,0)) * (m2.getIJ(0,1) - m2.getIJ(1,1));
            // double M4 = (m1.getIJ(1,1)) * (m2.getIJ(1,0) - m2.getIJ(0,0));
            // double M5 = (m1.getIJ(0,0) + m1.getIJ(0,1)) * (m2.getIJ(1,1));
            // double M6 = (m1.getIJ(1,0) - m1.getIJ(0,0)) * (m2.getIJ(0,0) + m2.getIJ(0,1));
            // double M7 = (m1.getIJ(0,1) - m1.getIJ(1,1)) * (m2.getIJ(1,0) + m2.getIJ(1,1));

            // System.out.println("M1 ==> " + M1 + " M2 ==> " + M2 + " M3 ==> " + M3 + " M4 ==> " + M4 + " M5 ==> " + M5 + " M6 ==> " + M6 + " M7 ==>" + M7);

            // m3.setIJ(0,0, (M1 + M4 - M5 + M7) );
            // m3.setIJ(0,1, (M3 + M5) );
            // m3.setIJ(1,0, (M2 + M4) );
            // m3.setIJ(1,1, (M1 - M2 + M3 + M6) );

            // return m3;

        }
    }

    class Main{
        public static void main(String[] args) {
            Matrix m1 = new Matrix(4);

            m1.setIJ(0,0,1);
            m1.setIJ(0,1,2);
            m1.setIJ(0,2,3);
            m1.setIJ(0,3,4);

            m1.setIJ(1,0,4);
            m1.setIJ(1,1,3);
            m1.setIJ(1,2,0);
            m1.setIJ(1,3,1);

            m1.setIJ(2,0,5);
            m1.setIJ(2,1,6);
            m1.setIJ(2,2,1);
            m1.setIJ(2,3,1);

            m1.setIJ(3,0,0);
            m1.setIJ(3,1,2);
            m1.setIJ(3,2,5);
            m1.setIJ(3,3,6);

            Matrix m2 = new Matrix(4);

            m2.setIJ(0,0,1);
            m2.setIJ(0,1,0);
            m2.setIJ(0,2,5);
            m2.setIJ(0,3,1);

            m2.setIJ(1,0,1);
            m2.setIJ(1,1,2);
            m2.setIJ(1,2,0);
            m2.setIJ(1,3,2);

            m2.setIJ(2,0,0);
            m2.setIJ(2,1,3);
            m2.setIJ(2,2,2);
            m2.setIJ(2,3,3);

            m2.setIJ(3,0,1);
            m2.setIJ(3,1,2);
            m2.setIJ(3,2,1);
            m2.setIJ(3,3,2);

            System.out.println("M1 ==> " + m1.toString());

            System.out.println("M2 ==> " + m2.toString());

            Matrix m3 = Matrix.matrixAdd(m1,m2);

            System.out.println("M3 ==> " + m3.toString());

            Matrix m4 = Matrix.matrixSub(m1,m2);
            System.out.println("M4 ==> " + m4.toString());

            Matrix m5 = Matrix.matrixMult(m1,m2);
            System.out.println("M5 ==> " + m5.toString());


        }
    }




