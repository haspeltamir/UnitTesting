public class Matrix {
    private double[][] matrix;


    // פעולה בונה
    public int getN() {
        return this.matrix.length;
    }

    //מתודה המחזירה את מימד המטריצה
    public Matrix(int n) {
        this.matrix = new double[n][n];

        for (int i = 0; i < this.getN(); i++) {
            for (int j = 0; j < this.getN(); j++)
                matrix[i][j] = 0;
        }
    }

    public double getIJ(int i, int j) {
        return this.matrix[i][j];
    }
    // מתודה המחזירה את האיבר בתא(j,i)

    public double setIJ(int i, int j, double value) {
        return this.matrix[i][j] = value;
    }

    //מתודה המציבה את הערך value
    //בתא )j,i )במטריצה
    public String toString() {
        String S = "";
        for (int i = 0; i < this.getN(); i++) {
            for (int j = 0; j < this.getN(); j++)
                S += matrix[i][j] + " ";
            S += "\n";
        }
        return S;
    }

    public static Matrix matrixAdd(Matrix m1, Matrix m2) {
        int N = m1.getN();
        Matrix M3 = new Matrix(N);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++) {
                double M1, M2;
                M1 = m1.getIJ(i, j);
                M2 = m2.getIJ(i, j);
                M3.setIJ(i, j, M1 + M2);
            }
        return M3;
    }

    public static Matrix matrixSub(Matrix m1, Matrix m2) {
        int N = m1.getN();
        Matrix M3 = new Matrix(N);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++) {
                double M1, M2;
                M1 = m1.getIJ(i, j);
                M2 = m2.getIJ(i, j);
                M3.setIJ(i, j, M1 - M2);
            }
        return M3;
    }

    public static Matrix Add(Matrix A, Matrix B) {
        int N = A.getN();
        Matrix C = new Matrix(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                double a, b;
                a = A.getIJ(i, j);
                b = B.getIJ(i, j);
                C.setIJ(i, j, a + b);
            }
        }
        return C;
    }
    //פונקציה שעושה חיבור בין מצריצות שבניהם כפל
    public static Matrix Sub(Matrix A, Matrix B) {
        int N = A.getN();
        Matrix C = new Matrix(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                double a, b;
                a = A.getIJ(i, j);
                b = B.getIJ(i, j);
                C.setIJ(i, j, a - b);
            }
        }
        return C;
    }
    //פונקציה שעושה חיסור בין מצריצות שבניהם כפל


    private static int nextPowerOf(int n) {
        int count = 0;
        if (n > 0 && (n & n - 1) == 0) {
            return n;
        } else {
            while (n != 0) {
                n >>= 1;
                ++count;
            }

            return 1 << count;
        }
    }

    public static Matrix matrixMult(Matrix m1, Matrix m2) {
        int n = m1.getN();
        int n2 = nextPowerOf(n);
        Matrix matMult = new Matrix(n2);
        if (n2 <= n) {
            return matKafool(m1, m2, n, matMult);
        } else {
            Matrix m111 = new Matrix(n2);
            Matrix m222 = new Matrix(n2);

            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    m111.setIJ(i, j, m1.getIJ(i, j));
                    m222.setIJ(i, j, m2.getIJ(i, j));
                }
            }

            Matrix matResult = matKafool(m111, m222, n2, matMult);
            Matrix result = new Matrix(n);

            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    result.setIJ(i, j, matResult.getIJ(i, j));
                }
            }

            return result;
        }
    }


    public static Matrix matKafool(Matrix m1, Matrix m2, int n, Matrix matMult) {
        if (n == 1)
            matMult.setIJ(0, 0, m1.getIJ(0, 0) * m2.getIJ(0, 0));
        else {
            Matrix A11 = new Matrix(n / 2);
            Matrix A12 = new Matrix(n / 2);
            Matrix A21 = new Matrix(n / 2);
            Matrix A22 = new Matrix(n / 2);
            Matrix B11 = new Matrix(n / 2);
            Matrix B12 = new Matrix(n / 2);
            Matrix B21 = new Matrix(n / 2);
            Matrix B22 = new Matrix(n / 2);
            divide(m1, A11, 0, 0);
            divide(m2, B11, 0, 0);
            divide(m1, A12, 0, n / 2);
            divide(m2, B12, 0, n / 2);
            divide(m1, A21, n / 2, 0);
            divide(m2, B21, n / 2, 0);
            divide(m1, A22, n / 2, n / 2);
            divide(m2, B22, n / 2, n / 2);
            //פולות חישוב של כפל שת מטריצות לפי הנתון
            Matrix M1 = matrixMult(Add(A11, A22), Add(B11, B22));
            Matrix M2 = matrixMult(Add(A21, A22), B11);
            Matrix M3 = matrixMult(A11, Sub(B12, B22));
            Matrix M4 = matrixMult(A22, Sub(B21, B11));
            Matrix M5 = matrixMult(Add(A11, A12), B22);
            Matrix M6 = matrixMult(Sub(A21, A11), Add(B11, B12));
            Matrix M7 = matrixMult(Sub(A12, A22), Add(B21, B22));

            Matrix C11 = Add(Sub(Add(M1,M4),M5),M7);
            Matrix C12 = Add(M3, M5);
            Matrix C21 = Add(M2, M4);
            Matrix C22 = Add(Sub(Add(M1,M3),M2),M6);
            // מסדרים המטריצה לפי האיבארים
            arrange(C11, matMult, 0, 0);
            arrange(C12, matMult, 0, n / 2);
            arrange(C21, matMult, n / 2, 0);
            arrange(C22, matMult, n / 2, n / 2);
        }
        return matMult;
    }

    public static void divide(Matrix A, Matrix B, int iB, int jB) {
        int i1,i2,j1,j2;
        for (i1 = 0, i2=iB ;i1< B.getN(); i1++,i2++)
            for (j1 = 0,j2=jB; j1 < B.getN(); j1++,j2++)
                B.setIJ(i1, j1, A.getIJ(i2, j2));
    }

    //הפולה זאת מחלקת את המטריצה
    public static void arrange(Matrix X, Matrix Y, int iB, int jB) {
        int i1, j1, i2, j2;
        for (i1 = 0,i2=iB; i1< X.getN(); i1++,i2++)
            for (j1 = 0,j2=jB; j1 < X.getN(); j1++,j2++)
                Y.setIJ(i2, j2, X.getIJ(i1, j1));
    }
}
//הפולה זאת מסדרת את המטרצה

//    Enter Matrix size:
//        2
//        Enter the n,n entries of  matrix 1 now:
//        2 3
//        4 5
//        Enter the n,n entries of  matrix 2 now:
//        11 2
//        3 4
//        M1:
//        2.0 3.0
//        4.0 5.0
//
//        M2:
//        11.0 2.0
//        3.0 4.0
//
//        M1 + M2:
//        13.0 5.0
//        7.0 9.0
//
//        M1 - M2:
//        -9.0 1.0
//        1.0 1.0
//
//        M1 * M2:
//        31.0 16.0
//        59.0 28.0
//
//
//        Process finished with exit code 0

//Enter Matrix size:
//        4
//        Enter the n,n entries of  matrix 1 now:
//        1 2 3 4
//        2 3 4 5
//        3 4 5 6
//        Enter the n,n entries of  matrix 2 now:
//        6 7 8 9
//        3 4 5 6
//        2 3 4 5
//        1 2 3 4
//        M1:
//        1.0 2.0 3.0 4.0
//        1.0 2.0 3.0 4.0
//        2.0 3.0 4.0 5.0
//        3.0 4.0 5.0 6.0
//
//        M2:
//        6.0 7.0 8.0 9.0
//        3.0 4.0 5.0 6.0
//        2.0 3.0 4.0 5.0
//        1.0 2.0 3.0 4.0
//
//        M1 + M2:
//        7.0 9.0 11.0 13.0
//        4.0 6.0 8.0 10.0
//        4.0 6.0 8.0 10.0
//        4.0 6.0 8.0 10.0
//
//        M1 - M2:
//        -5.0 -5.0 -5.0 -5.0
//        -2.0 -2.0 -2.0 -2.0
//        0.0 0.0 0.0 0.0
//        2.0 2.0 2.0 2.0
//
//        M1 * M2:
//        22.0 32.0 42.0 52.0
//        22.0 32.0 42.0 52.0
//        34.0 48.0 62.0 76.0
//        46.0 64.0 82.0 100.0
//
//
//        Process finished with exit code 0
