/*
khaleel azaizy 212511927
 alaa nwesre 323937052
 */
import java.util.Scanner;
import static java.lang.Math.log;

/* Department for checking the Matrix class: Defining class instances (metrixes)
   and operations of addition, subtraction and multiplication. */
public class Matrix {
    static Scanner input = new Scanner(System.in);

    public int size, n,dim;
    public double[][] matrix;
    public Matrix(int n) {
        size = n;
        matrix = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = 0; }
        }
    }
    public int getN() {
        dim = size * size;
        return dim;
    }//מיתודה מחשבת את גודל המטריצה
    public double getIJ(int i, int j) {
        return matrix[i][j];
    }//מיתודה שמחזירה הערך במקום מסוים
    public void setIJ(int i, int j, double value) {
        matrix[i][j] = value;
    }//מיתודה שמחליפה הערך במקום מסוים ל value
    public String toString() {
        String ch = "";
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                ch =ch + String.format("%-9.3f",matrix[i][j]);
            }
            ch = ch + "\n";
        }
        return ch;
    }//  מיתודה שמעבירה את הערכים במערך לתוך מחרוזת
    public static Matrix matrixAdd(Matrix m1, Matrix m2) {
        Matrix sum = new Matrix(m1.size);
        for (int i = 0; i < m1.size; i++) {
            for (int j = 0; j < m1.size; j++) {
                sum.matrix[i][j] = m1.matrix[i][j] + m2.matrix[i][j];
            }
        }
        return sum;
    }//מיתודה שעושה חיבור בן שני מטריצות
    public static Matrix matrixSub(Matrix m1, Matrix m2) {
        {
            Matrix sum = new Matrix(m1.size);
            for (int i = 0; i < m1.size; i++) {
                for (int j = 0; j < m1.size; j++) {
                    sum.matrix[i][j] = m1.matrix[i][j] - m2.matrix[i][j];
                }
            }
            return sum;
        }
    }//מיתודה שעושה חיסור בן שני מטריצות
    public static Matrix matrixMult(Matrix m1 , Matrix m2){
        int n= m1.size;
        Matrix sum = new Matrix(n);
        int op = n/2;
        double dim = (log(m1.size) / log(2));
        if ((dim % 1) != 0) {
            n = (int) Math.pow(2, Math.ceil(dim));
            op = n/2;
        }
        Matrix mat1 = m1.same(n);
        Matrix mat2 = m2.same(n);
        Matrix M = new Matrix(n);

        if (n==1){
            M.matrix[0][0]+=m1.matrix[0][0]*m2.matrix[0][0];
            return M;
        }
        else{
            Matrix A11 = new Matrix (op);
            Matrix A12 = new Matrix (op);
            Matrix A21 = new Matrix (op);
            Matrix A22 = new Matrix (op);

            Matrix B11 = new Matrix (op);
            Matrix B12 = new Matrix (op);
            Matrix B21 = new Matrix (op);
            Matrix B22 = new Matrix (op);

            sp(mat1,A11,0,0);
            sp(mat1,A12,0,op);
            sp(mat1,A21,op,0);
            sp(mat1,A22,op,op);

            sp(mat2,B11,0,0);
            sp(mat2,B12,0,op);
            sp(mat2,B21,op,0);
            sp(mat2,B22,op,op);

            Matrix M1 = matrixMult(matrixAdd(A11,A22),matrixAdd(B11,B22));
            Matrix M2 = matrixMult(matrixAdd(A21,A22),B11);
            Matrix M3 = matrixMult(A11,matrixSub(B12,B22));
            Matrix M4 = matrixMult(A22,matrixSub(B21,B11));
            Matrix M5 = matrixMult(matrixAdd(A11,A12),B22);
            Matrix M6 = matrixMult(matrixSub(A21, A11), matrixAdd(B11, B12));
            Matrix M7 = matrixMult(matrixSub(A12, A22), matrixAdd(B21, B22));

            Matrix C11 = matrixAdd(matrixSub(matrixAdd(M1,M4),M5),M7);
            Matrix C12 = matrixAdd(M3, M5);
            Matrix C21 = matrixAdd(M2, M4);
            Matrix C22 = matrixAdd(matrixAdd(matrixSub(M1,M2),M3),M6);

            setup(C11,M,0,0);
            setup(C12,M,0,op);
            setup(C21,M,op,0);
            setup(C22,M,op,op);
            sp(M,sum,0,0);
        }
        return sum;
    }//מיתודה שעושה כפל בן שני מטריצות

    public Matrix same(int exp) {
        Matrix same = new Matrix(exp);
        for (int i = 0; i < size; i++) {
            System.arraycopy(matrix[i],0, same.matrix[i], 0, size);
        }
        return same;
    }

    public static void setup(Matrix m1, Matrix m2, int im2, int jm2){

        for (int i1 = 0, i2 = im2; i1 < m1.size; i1++, i2++) {
            for (int j1 = 0, j2 = jm2; j1 < m1.size; j1++, j2++) {
                m2.matrix[i2][j2] = m1.matrix[i1][j1];
            }
        }
    }

    public static void sp(Matrix m1,Matrix m2, int im2, int jm2) {
        for (int i1 = 0, i2 = im2; i1 < m2.size; i1++, i2++) {
            for (int j1 = 0, j2 = jm2; j1 < m2.size; j1++, j2++) {
                m2.matrix[i1][j1] = m1.matrix[i2][j2];
            }
        }
    }


    public static void main( String[] args )
    {
        System.out.println("Enter Matrix size: ");
        int n = input.nextInt();

        Matrix M1= generateMatrix(n,1);
        Matrix M2= generateMatrix(n,2);
        Matrix M3 = new Matrix(n);
        System.out.println("M1:");
        System.out.println(M1);
        System.out.println("M2:");
        System.out.println(M2);

        System.out.println("M1 + M2:");
        M3 = Matrix.matrixAdd(M1,M2);
        System.out.println(M3);
        System.out.println("M1 - M2:");
        M3 = Matrix.matrixSub(M1,M2);
        System.out.println(M3);
        System.out.println("M1 * M2:");
        M3 = Matrix.matrixMult(M1,M2);
        System.out.println(M3);


    } // main

    // Static method for receiving matrix data
    static Matrix generateMatrix(int n,int k)
    {


        Matrix mat = new Matrix(n);

        System.out.printf("Enter the n,n entries of  matrix %d now:\n",k);

        for (int i = 0 ; i < n; i++ ) {
            for(int j=0 ; j < n; j++){
                mat.setIJ(i,j, input.nextDouble());
            }
        }
        return mat;
    } // generateMatrix



} // MatrixTest
/*Enter Matrix size:
5
Enter the n,n entries of  matrix 1 now:
0 1 2 3 4
1 2 3 4 5
2 3 4 5 6
3 4 5 6 7
4 5 6 7 8
Enter the n,n entries of  matrix 2 now:
0 10 20 30 40
10 20 30 40 50
20 30 40 50 60
30 40 50 60 70
40 50 60 70 80
M1:
0.000    1.000    2.000    3.000    4.000
1.000    2.000    3.000    4.000    5.000
2.000    3.000    4.000    5.000    6.000
3.000    4.000    5.000    6.000    7.000
4.000    5.000    6.000    7.000    8.000

M2:
0.000    10.000   20.000   30.000   40.000
10.000   20.000   30.000   40.000   50.000
20.000   30.000   40.000   50.000   60.000
30.000   40.000   50.000   60.000   70.000
40.000   50.000   60.000   70.000   80.000

M1 + M2:
0.000    11.000   22.000   33.000   44.000
11.000   22.000   33.000   44.000   55.000
22.000   33.000   44.000   55.000   66.000
33.000   44.000   55.000   66.000   77.000
44.000   55.000   66.000   77.000   88.000

M1 - M2:
0.000    -11.000   -22.000   -33.000   -44.000
-11.000   -22.000   -33.000   -44.000   -55.000
-22.000   -33.000   -44.000   -55.000   -66.000
-33.000   -44.000   -55.000   -66.000   -77.000
-44.000   -55.000   -66.000   -77.000   -88.000

M1 * M2:
300.000  400.000  500.000  600.000  700.000
400.000  550.000  700.000  850.000  1000.000
500.000  700.000  900.000  1100.000 1300.000
600.000  850.000  1100.000 1350.000 1600.000
700.000  1000.000 1300.000 1600.000 1900.000*/
