//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public class Matrix {
    private double[][] matrix;
    private int number = 0;

    public Matrix(int n) {//פונקציה אשר קולטת מערך דו-ממדי ומשווה את הערכים שלו לאפס
        this.matrix = new double[n][n];
        this.number = n;

        for(int i = 0; i < this.getN(); ++i) {
            for(int j = 0; j < this.getN(); ++j) {
                this.matrix[i][j] = 0.0D;
            }
        }

    }

    public int getN() {
        return this.number;
    }//מחזירה את ערך המימד או גודל המטריצה

    public double getIJ(int i, int j) {
        return this.matrix[i][j];
    }//מחזירה את המיקום של האיבר במטריצה

    public void setIJ(int i, int j, double value) {
        this.matrix[i][j] = value;
    }// מחזירה את הערך של האיבר במיקום ששיך אליו

    public String toString() {
        String string = "";

        for(int i = 0; i < this.getN(); ++i) {
            string = string + "\n";

            for(int j = 0; j < this.getN(); ++j) {
                string = string + this.matrix[i][j] + " ";
                string = string + "\t";
            }
        }

        return string;

    }

    public static Matrix matrixAdd(Matrix m1, Matrix m2) {//פונקציה אשר עובדת על חיבור בין שתי מטריציות ומחזירה את הערך
        int n = m1.getN();
        Matrix temp = new Matrix(n);

        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                temp.setIJ(i, j, m1.getIJ(i, j) + m2.getIJ(i, j));
            }
        }

        return temp;
    }

    public static Matrix matrixSub(Matrix m1, Matrix m2) {//פונקציה אשר עובדת על חיסור בין שתי מטריציות ומחזירה את הערך
        int n = m1.getN();
        Matrix M3 = new Matrix(n);

        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                M3.setIJ(i, j, m1.getIJ(i, j) - m2.getIJ(i, j));
            }
        }

        return M3;
    }

    public static Matrix matrixMult(Matrix m1, Matrix m2) {/* פונקציה אשר עובדת על פעולת הכפל בין שתי מטריציות ומחזירה את הערך*/
        int n = m1.getN();
        Matrix Lmatrix = new Matrix(n);
        double e = Math.log((double)m1.getN()) / Math.log(2.0D);
        if (e % 2.0D != 0.0D) {//אם התנאי מתקיים אז משלימים את הגודל של המטריצה לערך של חזקה של 2 
            n = (int)Math.pow(2.0D, Math.ceil(e));
        }//jfodkld

        Matrix A = m1.zeromatrix(n);//מגדירים מטריצה 1 ומציבים את הערכים שלה לאפסים 
        Matrix B = m2.zeromatrix(n);//מגדירים מטריצה 2 ומציבים את הערכים שלה לאפסים 
        Matrix R = new Matrix(n);//המטריצה הסופית שלנו
        if (n == 1) {//אם גודל המטריצה הוא 1 אז המתאני הזה עובד
            R.setIJ(0, 0, A.getIJ(0, 0) * B.getIJ(0, 0));
            return R;
        } else {//אחרת אנחנו חייבים לעבור את כל הפעוליות לפי האלגורטתם כמו שמוסבר בדף העבודה
            Matrix A11 = new Matrix(n / 2);
            Matrix A12 = new Matrix(n / 2);
            Matrix A21 = new Matrix(n / 2);
            Matrix A22 = new Matrix(n / 2);
            Matrix B11 = new Matrix(n / 2);
            Matrix B12 = new Matrix(n / 2);
            Matrix B21 = new Matrix(n / 2);
            Matrix B22 = new Matrix(n / 2);
            split(A, A11, 0, 0);
            split(A, A12, 0, n / 2);
            split(A, A21, n / 2, 0);
            split(A, A22, n / 2, n / 2);
            split(B, B11, 0, 0);
            split(B, B12, 0, n / 2);
            split(B, B21, n / 2, 0);
            split(B, B22, n / 2, n / 2);
            Matrix M1 = matrixMult(matrixAdd(A11, A22), matrixAdd(B11, B22));
            Matrix M2 = matrixMult(matrixAdd(A21, A22), B11);
            Matrix M3 = matrixMult(A11, matrixSub(B12, B22));
            Matrix M4 = matrixMult(A22, matrixSub(B21, B11));
            Matrix M5 = matrixMult(matrixAdd(A11, A12), B22);
            Matrix M6 = matrixMult(matrixSub(A21, A11), matrixAdd(B11, B12));
            Matrix M7 = matrixMult(matrixSub(A12, A22), matrixAdd(B21, B22));
            Matrix C11 = matrixAdd(matrixSub(matrixAdd(M1, M4), M5), M7);
            Matrix C12 = matrixAdd(M3, M5);
            Matrix C21 = matrixAdd(M2, M4);
            Matrix C22 = matrixAdd(matrixSub(matrixAdd(M1, M3), M2), M6);
            matrixc(C11, R, 0, 0);
            matrixc(C12, R, 0, n / 2);
            matrixc(C21, R, n / 2, 0);
            matrixc(C22, R, n / 2, n / 2);
            split(R, Lmatrix, 0, 0);
            return Lmatrix;// מחזיר את המטריצה שהתקבלה מפעולת הכפל
        }
    }

    public static void split(Matrix P, Matrix C, int iB, int jB) {//פונקציה אשר מחלקת המטריצה למטריצה קטנה ממנה
        int i1 = 0;

        for(int i2 = iB; i1 < C.getN(); ++i2) {
            int j1 = 0;

            for(int j2 = jB; j1 < C.getN(); ++j2) {
                C.setIJ(i1, j1, P.getIJ(i2, j2));
                ++j1;
            }

            ++i1;
        }

    }

    public static void matrixc(Matrix m1, Matrix m2, int im2, int jm2) {//מכניסה מטריציות אחת בתוך השניה (קטנה בתוך הגדולה)
        int i1 = 0;

        for(int i2 = im2; i1 < m1.getN(); ++i2) {
            int j1 = 0;

            for(int j2 = jm2; j1 < m1.getN(); ++j2) {
                m2.setIJ(i2, j2, m1.getIJ(i1, j1));
                ++j1;
            }

            ++i1;
        }

    }

    public Matrix zeromatrix(int e) {//מכניסה את כל ערכי המטריצה לאפסים
        Matrix zero = new Matrix(e);

        for(int i = 0; i < this.number; ++i) {
            System.arraycopy(this.matrix[i], 0, zero.matrix[i], 0, this.number);
        }

        return zero;
    }
}
/*
C:\Users\Lenovo\.jdks\openjdk-17.0.2\bin\java.exe -Dfile.encoding=windows-1255 -jar C:\Users\Lenovo\IdeaProjects\rawad315281964_saed323965921\out\artifacts\rawad315281964_saed323965921_jar\rawad315281964_saed323965921.jar
Enter Matrix size:
2
Enter the n,n entries of  matrix 1 now:
1
2
3
4
Enter the n,n entries of  matrix 2 now:
1
2
3
4
M1:

1.0 	2.0
3.0 	4.0
M2:

1.0 	2.0
3.0 	4.0
M1 + M2:

2.0 	4.0
6.0 	8.0
M1 - M2:

0.0 	0.0
0.0 	0.0
M1 * M2:

7.0 	10.0
15.0 	22.0

Process finished with exit code 0
 test 2:
C:\Users\Lenovo\.jdks\openjdk-17.0.2\bin\java.exe -Dfile.encoding=windows-1255 -jar C:\Users\Lenovo\IdeaProjects\rawad315281964_saed323965921\out\artifacts\rawad315281964_saed323965921_jar\rawad315281964_saed323965921.jar
Enter Matrix size:
5
Enter the n,n entries of  matrix 1 now:

1 2 3 4 5
2 3 4 5 6
3 4 5 6 7
4 5 6 7 8
5 6 7 8 9
Enter the n,n entries of  matrix 2 now:


10 20 30 40 50
20 30 40 50 60
30 40 50 60 70
40 50 60 70 80
50 60 70 80 90
M1:

1.0 	2.0 	3.0 	4.0 	5.0
2.0 	3.0 	4.0 	5.0 	6.0
3.0 	4.0 	5.0 	6.0 	7.0
4.0 	5.0 	6.0 	7.0 	8.0
5.0 	6.0 	7.0 	8.0 	9.0
M2:

10.0 	20.0 	30.0 	40.0 	50.0
20.0 	30.0 	40.0 	50.0 	60.0
30.0 	40.0 	50.0 	60.0 	70.0
40.0 	50.0 	60.0 	70.0 	80.0
50.0 	60.0 	70.0 	80.0 	90.0
M1 + M2:

11.0 	22.0 	33.0 	44.0 	55.0
22.0 	33.0 	44.0 	55.0 	66.0
33.0 	44.0 	55.0 	66.0 	77.0
44.0 	55.0 	66.0 	77.0 	88.0
55.0 	66.0 	77.0 	88.0 	99.0
M1 - M2:

-9.0 	-18.0 	-27.0 	-36.0 	-45.0
-18.0 	-27.0 	-36.0 	-45.0 	-54.0
-27.0 	-36.0 	-45.0 	-54.0 	-63.0
-36.0 	-45.0 	-54.0 	-63.0 	-72.0
-45.0 	-54.0 	-63.0 	-72.0 	-81.0
M1 * M2:

550.0 	700.0 	850.0 	1000.0 	1150.0
700.0 	900.0 	1100.0 	1300.0 	1500.0
850.0 	1100.0 	1350.0 	1600.0 	1850.0
1000.0 	1300.0 	1600.0 	1900.0 	2200.0
1150.0 	1500.0 	1850.0 	2200.0 	2550.0

Process finished with exit code 0

 */