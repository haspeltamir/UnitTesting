// yasmena farhat 322929605
//nagham mosa 208260018
import java.util.Scanner;
import static java.lang.Math.log;

public class Matrix
{
    static Scanner input = new Scanner(System.in);
    public double [][] matrix;
    private int n,leng;
    public Matrix(int n) {
        int i, j;
        leng = n;
        matrix = new double[n][n];
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    public int getN()
    {
        return leng * leng;

    }


    public void setIJ(int i, int j, double value)
    {
        matrix[i][j] = value;
    }

    public String toString()
    {
        String matrixstring = "";
        int i, j;
        for (i = 0; i < leng; i++)
        {
            for(j=0;j<leng;j++)
            {
                matrixstring += matrix[i][j]+"\t";
            }
            matrixstring+="\n";
        }
        return matrixstring;
    }
    // מתודה מחזירה את סכום שתי המטריצות
    public static Matrix matrixAdd(Matrix m1, Matrix m2)
    {
        int i, j;
        Matrix arrAdd = new Matrix(m1.leng);
        for (i = 0; i < m1.leng; i++) {
            for (j = 0; j < m1.leng; j++) {
                arrAdd.matrix[i][j] = m1.matrix[i][j] + m2.matrix[i][j];
            }
        }
        return arrAdd;
    }
    // מתודה מחזירה את הפרש שתי המטריצות

    public static Matrix matrixSub(Matrix m1,Matrix m2)
    {
        int i, j;
        Matrix arrSub = new Matrix(m1.leng);
        for (i = 0; i < m1.leng ; i++) {
            for (j = 0; j < m1.leng; j++) {
                arrSub.matrix[i][j] = m1.matrix[i][j] - m2.matrix[i][j];
            }
        }
        return arrSub;
    }
    public Matrix padMatrix(int exp)
    {
        Matrix pad = new Matrix(exp);
        for (int i = 0; i < leng; i++) {
            System.arraycopy(matrix[i], 0, pad.matrix[i], 0, leng);
        }
        return pad;
    }
    // מכפלת מטריצות
    public static Matrix matrixMult(Matrix m1, Matrix m2) {
        int n = m1.leng;
        Matrix end = new Matrix(n);
        double exp = log(m1.leng) / log(2);

        if ((exp % 1) != 0)// בודקים אם n הוא לא חזקה של 2
        {
            n = (int) Math.pow(2, Math.ceil(exp));//מגדיל את n לחזקה של 2
        }
        Matrix arrMult = new Matrix(n);
        Matrix matrix1 = m1.padMatrix(n);
        Matrix matrix2 = m2.padMatrix(n);

        if (n == 1){
            arrMult.matrix[0][0] = matrix1.matrix[0][0] * matrix2.matrix[0][0];
            return arrMult;
        }
        else {

            Matrix A11 = new Matrix(n/2);
            Matrix A12 = new Matrix(n/2);
            Matrix A21 = new Matrix(n/2);
            Matrix A22 = new Matrix(n/2);
            Matrix B11 = new Matrix(n/2);
            Matrix B12 = new Matrix(n/2);
            Matrix B21 = new Matrix(n/2);
            Matrix B22 = new Matrix(n/2);

            part(matrix1, A11, 0, 0);
            part(matrix1, A12, 0, n / 2);
            part(matrix1, A21, n / 2, 0);
            part(matrix1, A22, n / 2, n / 2);

            part(matrix2, B11, 0, 0);
            part(matrix2, B12, 0, n / 2);
            part(matrix2, B21, n / 2, 0);
            part(matrix2, B22, n / 2, n / 2);

            Matrix M1 = matrixMult(matrixAdd(A11, A22), matrixAdd(B11, B22));
            Matrix M2 = matrixMult(matrixAdd(A21, A22), B11);
            Matrix M3 = matrixMult(A11, matrixSub(B12, B22));
            Matrix M4 = matrixMult(A22, matrixSub(B21, B11));
            Matrix M5 = matrixMult(matrixAdd(A11, A12), B22);
            Matrix M6 = matrixMult(matrixSub(A21, A11), matrixAdd(B11, B12));
            Matrix M7 = matrixMult(matrixSub(A12, A22), matrixAdd(B21, B22));

            Matrix C11 = matrixAdd(matrixSub(matrixAdd(M1, M4), M5), M7);
            Matrix C12 = matrixAdd(M3, M5);
            Matrix C21 = matrixAdd(M2, M4);
            Matrix C22 = matrixAdd(matrixSub(matrixAdd(M1, M3), M2), M6);

            join(C11,  arrMult, 0, 0);
            join(C12,  arrMult, 0, n / 2);
            join(C21,  arrMult, n / 2, 0);
            join(C22,  arrMult, n / 2, n / 2);
            part(arrMult,end,0,0);
        }
        return end;
    }

    public static void part(Matrix P, Matrix C, int iB, int jB)
    {
// עשינו המתודה הזאת כדי לחלק את המטריצה לחלקים
        for (int i1 = 0, i2 = iB; i1 < C.leng; i1++, i2++)

            for (int j1 = 0, j2 = jB; j1 < C.leng; j1++, j2++)

                C.matrix[i1][j1] = P.matrix[i2][j2];
    }


    public static void join(Matrix C, Matrix P, int iB, int jB)
    {
        // מתודה מסדרת אותם אחרי הפעולות
        for (int i1 = 0, i2 = iB; i1 < C.leng; i1++, i2++)

            for (int j1 = 0, j2 = jB; j1 < C.leng; j1++, j2++)

                P.matrix[i2][j2] = C.matrix[i1][j1];
    }



    public static void main( String[] args )
    {
        System.out.println("Enter Matrix size: ");
        int n = input.nextInt();

        Matrix M1= generateMatrix(n,1);
        Matrix M2= generateMatrix(n,2);
        Matrix M3 = new Matrix(n);
        System.out.println("M1:");
        System.out.println(M1);
        System.out.println("M2:");
        System.out.println(M2);

        System.out.println("M1 + M2:");
        M3 = Matrix.matrixAdd(M1,M2);
        System.out.println(M3);
        System.out.println("M1 - M2:");
        M3 = Matrix.matrixSub(M1,M2);
        System.out.println(M3);
        System.out.println("M1 * M2:");
        M3 = Matrix.matrixMult(M1,M2);
        System.out.println(M3);


    } // main

    // Static method for receiving matrix data
    static Matrix generateMatrix(int n,int k)
    {


        Matrix mat = new Matrix(n);

        System.out.printf("Enter the n,n entries of  matrix %d now:\n",k);

        for (int i = 0 ; i < n; i++ ) {
            for(int j=0 ; j < n; j++){
                mat.setIJ(i,j, input.nextDouble());
            }
        }
        return mat;
    } // generateMatrix

}