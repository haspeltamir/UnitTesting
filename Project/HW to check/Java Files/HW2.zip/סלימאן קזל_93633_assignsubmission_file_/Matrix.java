

public class Matrix {
    private double[][] matr;
    private int NUM = 0;

    public Matrix(int n) {
        this.matr = new double[n][n];
        this.NUM = n;

        for(int i = 0; i < this.getN(); ++i) {
            for(int j = 0; j < this.getN(); ++j) {
                this.matr[i][j] = 0.0D;
            }
        }

    }

    public int getN() {
        return this.NUM;
    }

    public double getIJ(int i, int j) {
        return this.matr[i][j];
    }

    public void setIJ(int i, int j, double value) {
        this.matr[i][j] = value;
    }

    public String toString() {
        String string = "";

        for(int i = 0; i < this.getN(); ++i) {
            string = string + "\n";

            for(int j = 0; j < this.getN(); ++j) {
                string = string + this.matr[i][j] + " ";
                string = string + "\t";
            }
        }

        return string;
    }

    public static Matrix matrixAdd(Matrix m1, Matrix m2) {
        int n = m1.getN();
        Matrix Madd = new Matrix(n);

        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                Madd.setIJ(i, j, m1.getIJ(i, j) + m2.getIJ(i, j));
            }
        }

        return Madd;
    }

    public static Matrix matrixSub(Matrix m1, Matrix m2) {
        int n = m1.getN();
        Matrix Msub = new Matrix(n);

        for(int i = 0; i < n; ++i) {
            for(int j = 0; j < n; ++j) {
                Msub.setIJ(i, j, m1.getIJ(i, j) - m2.getIJ(i, j));
            }
        }

        return Msub;
    }

    public static Matrix matrixMult(Matrix m1, Matrix m2) {
        int n = m1.getN();
        Matrix lastMatrix = new Matrix(n);
        double Ep = Math.log((double)m1.getN()) / Math.log(2.0D);
        if (Ep % 2.0D != 0.0D) {
            n = (int)Math.pow(2.0D, Math.ceil(Ep));
        }

        Matrix A = m1.matroxcop(n);
        Matrix B = m2.matroxcop(n);
        Matrix R = new Matrix(n);
        if (n == 1) {
            R.setIJ(0, 0, A.getIJ(0, 0) * B.getIJ(0, 0));
            return R;
        } else {
            Matrix A11 = new Matrix(n / 2);
            Matrix A12 = new Matrix(n / 2);
            Matrix A21 = new Matrix(n / 2);
            Matrix A22 = new Matrix(n / 2);
            Matrix B11 = new Matrix(n / 2);
            Matrix B12 = new Matrix(n / 2);
            Matrix B21 = new Matrix(n / 2);
            Matrix B22 = new Matrix(n / 2);
            split(A, A11, 0, 0);
            split(A, A12, 0, n / 2);
            split(A, A21, n / 2, 0);
            split(A, A22, n / 2, n / 2);
            split(B, B11, 0, 0);
            split(B, B12, 0, n / 2);
            split(B, B21, n / 2, 0);
            split(B, B22, n / 2, n / 2);
            Matrix M1 = matrixMult(matrixAdd(A11, A22), matrixAdd(B11, B22));
            Matrix M2 = matrixMult(matrixAdd(A21, A22), B11);
            Matrix M3 = matrixMult(A11, matrixSub(B12, B22));
            Matrix M4 = matrixMult(A22, matrixSub(B21, B11));
            Matrix M5 = matrixMult(matrixAdd(A11, A12), B22);
            Matrix M6 = matrixMult(matrixSub(A21, A11), matrixAdd(B11, B12));
            Matrix M7 = matrixMult(matrixSub(A12, A22), matrixAdd(B21, B22));
            Matrix C11 = matrixAdd(matrixSub(matrixAdd(M1, M4), M5), M7);
            Matrix C12 = matrixAdd(M3, M5);
            Matrix C21 = matrixAdd(M2, M4);
            Matrix C22 = matrixAdd(matrixSub(matrixAdd(M1, M3), M2), M6);
            matr(C11, R, 0, 0);
            matr(C12, R, 0, n / 2);
            matr(C21, R, n / 2, 0);
            matr(C22, R, n / 2, n / 2);
            split(R, lastMatrix, 0, 0);
            return lastMatrix;
        }
    }

    public static void split(Matrix P, Matrix C, int iB, int jB) {
        int i1 = 0;

        for(int i2 = iB; i1 < C.getN(); ++i2) {
            int j1 = 0;

            for(int j2 = jB; j1 < C.getN(); ++j2) {
                C.setIJ(i1, j1, P.getIJ(i2, j2));
                ++j1;
            }

            ++i1;
        }

    }

    public static void matr(Matrix m1, Matrix m2, int im2, int jm2) {
        int i1 = 0;

        for(int i2 = im2; i1 < m1.getN(); ++i2) {
            int j1 = 0;

            for(int j2 = jm2; j1 < m1.getN(); ++j2) {
                m2.setIJ(i2, j2, m1.getIJ(i1, j1));
                ++j1;
            }

            ++i1;
        }

    }

    public Matrix matroxcop(int e) {
        Matrix Copy = new Matrix(e);

        for(int i = 0; i < this.NUM; ++i) {
            System.arraycopy(this.matr[i], 0, Copy.matr[i], 0, this.NUM);
        }

        return Copy;
    }
}
