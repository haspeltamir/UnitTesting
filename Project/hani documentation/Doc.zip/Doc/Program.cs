﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

// This is a personal academic project. Dear PVS-Studio, please check it.

// PVS-Studio Static Code Analyzer for C, C++, C#, and Java: https://pvs-studio.com

namespace Doc
{
    class Program
    {
        static void Main(string[] args)
        {
            // Test the function with a sample file

            //double documentationRatio = CheckFunctionDocumentationRatio("C:\Users\Win10\Downloads\qad\HW6\אדם חוגיראת_25986_assignsubmission_file_\ADAMATHEER6.c");
            //Console.WriteLine(documentationRatio);

            //float documentationRatio = (float)CheckFunctionDocumentationRatio("C:\Users\Win10\Downloads\qad\HW6\אדם חוגיראת_25986_assignsubmission_file_\ADAMATHEER6.c.c");
            //Console.WriteLine(documentationRatio);
            List<Student> studentList = new List<Student>();
            Student student1 = new Student();
            Student student2 = new Student();
            student1.Id[0] = "312456798";
            student1.Id[1] = "311111111";
            student1.Path = "C:\\Users\\Win10\\Downloads\\qad\\HW6\\אדם חוגיראת_25986_assignsubmission_file_\\ADAMATHEER6.c";
            student1.correctOutput = new int[2];
            student1.correctOutput[0] = 1;
            student1.correctOutput[1] = 0;
            student1.documentedFile = 0;
            student1.structuredFile = 0;
            student1.finalGrade = 95;
            //student 2 info
            student2.Id[0] = "322222222";
            student2.Id[1] = "378945987";
            student2.Path = "C:\\Users\\Win10\\Downloads\\qad\\HW6\\אדם חוגיראת_25986_assignsubmission_file_\\ADAMATHEER6.c";
            student2.correctOutput = new int[3];
            student2.correctOutput[0] = 1;
            student2.correctOutput[1] = 1;
            student2.correctOutput[2] = 1;
            student2.documentedFile = 0;
            student2.structuredFile = 0;
            student2.finalGrade = 100;
            //init student list
            studentList.Add(student1);
            studentList.Add(student2);

            var DOC1 = new Documentation();

            DOC1.CheckDocOfAllClass(ref studentList);
            Console.WriteLine("student 1 doc grade:" + student1.getDocumentedFile());
            Console.WriteLine("student 2 doc grade:" + student2.getDocumentedFile());
        }

        public static double CheckFunctionDocumentationRatio(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("The specified file does not exist.");
            }

            string[] lines = File.ReadAllLines(filePath);
            string extension = Path.GetExtension(filePath).ToLower();
            string pattern = @"\d{9}";
            bool isComment = false;
            bool isMain = false;

            // Keep track of the number of functions and the number of documented functions
            int functionCount = 0;
            int documentedFunctionCount = 0;
            int documents = 0;
            double grade = 0;
            

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                bool isFunction = line.Contains("(") && line.Contains(")") && (!(line.Contains(";"))) && (!(line.TrimStart().StartsWith("//"))) && (!(line.Contains("while"))) && (!(line.Contains("if"))) && (!(line.Contains("main")));
                

                //match student ID
                Match match = Regex.Match(line, pattern);
                if (match.Success)
                {
                    string id = match.Value;
                    Console.WriteLine($"ID :{id}");
                }
                if (line.TrimStart().StartsWith("/*") && (!(line.Trim().EndsWith("*/"))))
                {
                    isComment = true;
                    documents++;
                }
                if ((!(line.Contains("/*"))) && (line.Trim().EndsWith("*/")))
                {
                    isComment = false;
                }
                if(line.Contains("main"))
                {
                    isMain = true;
                }
                if (isFunction)
                {
                    isMain = false;
                }
                

                if (extension == ".py")
                {
                    if ((line.TrimStart().StartsWith("def ")) && (line.Trim().EndsWith(":")))
                    {
                        
                        functionCount++;
                        
                        // Check if the previous line is a documentation string
                        if (i > 0 && lines[i - 1].TrimStart().StartsWith("#") || lines[i - 1].TrimStart().StartsWith("\"\"\"") || line.Contains("'''"))
                        {
                            
                            documentedFunctionCount++;
                        }
                    }
                    else
                    {
                        if(line.TrimStart().StartsWith("#") || line.Contains("\"\"\"") || line.Contains("'''"))
                        {
                            
                            documents++;
                        }
                        
                    }
                }
                
                if (extension == ".c" || extension == ".java")
                {
                    if (isFunction && !isComment)
                    {
                        functionCount++;
                        // Check if the previous line is a documentation string
                        if (i > 0 && (lines[i - 1].TrimStart().StartsWith("//") || lines[i - 1].TrimStart().StartsWith("/*")))
                        {
                            //functionIsDocumented = true;
                            documentedFunctionCount++;
                        }
                    }
                    else
                    {
                        if (line.TrimStart().StartsWith("//") || (line.Contains("/*") && line.Contains("*/")))
                        {
                            documents++;
                        }
                    }
                }
            }

            grade = ((double)documentedFunctionCount / functionCount) * 100;
            bool res = Double.IsNaN(grade);

            if (res)
            {
                grade = ((double)documents / (lines.Length / 3)) * 100;
            }
            return  grade  ;
        }
    }   
}

