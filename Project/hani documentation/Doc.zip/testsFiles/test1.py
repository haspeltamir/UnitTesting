# This is a documentation string"
def properlyDocumentedFunction():
    # This function does something
    return 0