﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Doc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Doc.Tests
{
    [TestClass()]
    public class DocumentationTests
    {
      



        [TestMethod]
        public void CheckFunctionDocumentationRatio_CAndJavaFileExistsAndContainsProperDocumentation_Returns100Percent()
        {
            // Arrange
            var doc = new Documentation();
            string filePath = @"C:\Users\Win10\Downloads\qad\HW6\אדם חוגיראת_25986_assignsubmission_file_\ADAMATHEER6.c";
           

            // Act
            int grade = doc.CheckFunctionDocumentationRatio(filePath);

            // Assert
            Assert.AreEqual(100, grade);

           
        }


        [TestMethod]
        public void CheckFunctionDocumentationRatio_FileExistsButContainsIncompleteDocumentation_Returns100Percent()
        {
            // Arrange
            var doc = new Documentation();
            string filePath = @"C:\Users\Win10\Downloads\qad\HW6\אדם חוגיראת_25986_assignsubmission_file_\ADAMATHEER6.c";
        
            // Act
            int grade = doc.CheckFunctionDocumentationRatio(filePath);

            // Assert
            Assert.AreEqual(100, grade);

            
        }

        [TestMethod]
        public void CheckFunctionDocumentationRatio_FileDoesNotExist_ThrowsFileNotFoundException()
        {
            // Arrange
            string filePath = @"C:\example\nonExistentFile.py";
            var doc = new Documentation();
            // Act and Assert
            Assert.ThrowsException<FileNotFoundException>(() => doc.CheckFunctionDocumentationRatio(filePath));
        }


        [TestMethod]
        public void CheckFunctionDocumentationRatio_FileExistsAndContainsProperDocumentationNoFunc_ReturnsGradeGraterThan50()
        {
            // Arrange
            var doc = new Documentation();
            string filePath = @"C:\Users\Win10\Downloads\qad\HW6\אדם חוגיראת_25986_assignsubmission_file_\ADAMATHEER6.c";


            // Act
            int grade = doc.CheckFunctionDocumentationRatio(filePath);

            // Assert
            Assert.IsTrue(grade > 50);
        }
    }
}